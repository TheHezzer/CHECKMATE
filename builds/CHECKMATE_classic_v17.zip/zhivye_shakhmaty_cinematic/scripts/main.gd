extends Node3D

const GOLD := Color(0.72, 0.55, 0.30)
const PALE_GOLD := Color(0.92, 0.82, 0.63)
const DARK := Color(0.025, 0.020, 0.016, 0.94)
const PIECES := ["Пешка", "Ладья", "Конь", "Слон", "Ферзь", "Король"]
const UI_FONT: Font = preload("res://assets/fonts/RoyalDisplay-Bold.ttf")
const UI_LABEL_FONT: Font = preload("res://assets/fonts/RoyalDisplay-Medium.ttf")

var camera: Camera3D
var world_root: Node3D
var ui: CanvasLayer
var menu_panel: Control
var game_panel: Control
var preview_container: SubViewportContainer
var preview_pawn: Node3D
var selected_piece := 0
var selected_mode := "Классика"
var dragging_preview := false
var last_pointer_x := 0.0
var last_pointer_y := 0.0
var status_label: Label
var preparation_panel: Control
var mode_selection_panel: Control
var mode_choice_buttons: Array[Button] = []
var mode_description_label: Label
var game_piece_nodes: Array[Node3D] = []
var selected_game_piece: Node3D
var current_team := "white"
var active_teammate := 1
var team_turn_label: Label
var prep_status: Label
var prep_piece_buttons: Array[Button] = []
var selected_prep_piece := 0
var balances := {"zloty": 12750, "xp": 850, "chessmatites": 620}
var unlocked_pieces := ["Пешка"]
var owned_skins := ["Дерево"]
var match_piece_costs := {"Пешка": 0, "Конь": 180, "Слон": 220, "Ладья": 260, "Ферзь": 520, "Король": 0}
var piece_unlock_xp := {"Пешка": 0, "Конь": 300, "Слон": 400, "Ладья": 500, "Ферзь": 1200, "Король": 0}

func _ready() -> void:
	_load_economy()
	_build_world()
	_build_ui()

func _build_world() -> void:
	world_root = Node3D.new()
	world_root.name = "ChessGameWorld"
	add_child(world_root)
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.035, 0.03, 0.025)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.58, 0.52, 0.43)
	env.ambient_light_energy = 0.8
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env_node.environment = env
	world_root.add_child(env_node)
	camera = Camera3D.new()
	camera.position = Vector3(0, 9.5, 13.0)
	camera.fov = 48
	world_root.add_child(camera)
	camera.look_at(Vector3(0, 1.0, 0), Vector3.UP)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_color = Color(1.0, 0.84, 0.66)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	world_root.add_child(sun)
	_add_game_box(Vector3(0, -0.45, 0), Vector3(24, 0.8, 24), Color(0.12, 0.105, 0.09))
	_add_game_box(Vector3(0, 5.5, -8.5), Vector3(24, 12, 0.8), Color(0.16, 0.145, 0.125))
	for x in [-9.0, -5.8, 5.8, 9.0]:
		for z in [-6.8, 1.0]:
			_add_game_cylinder(Vector3(x, 3.0, z), 0.62, 6.0, Color(0.25, 0.23, 0.20), 20)
	_add_game_box(Vector3(0, 0.05, -0.4), Vector3(9.4, 0.5, 8.0), Color(0.20, 0.13, 0.075))
	_add_game_box(Vector3(0, 0.31, -0.4), Vector3(9.15, 0.08, 7.75), GOLD)
	_add_game_box(Vector3(0, 0.43, -0.4), Vector3(8.75, 0.22, 7.35), Color(0.075, 0.055, 0.04))
	for row in range(8):
		for col in range(8):
			var square_color := Color(0.72, 0.60, 0.43) if (row + col) % 2 == 0 else Color(0.13, 0.095, 0.065)
			_add_game_box(Vector3((col - 3.5) * 1.05, 0.56, (row - 3.5) * 0.88 - 0.4), Vector3(1.03, 0.055, 0.86), square_color)
	_build_game_pieces()
	world_root.visible = false

func _build_game_pieces() -> void:
	game_piece_nodes.clear()
	var back_rank := ["R", "N", "B", "Q", "K", "B", "N", "R"]
	for col in range(8):
		var x := (col - 3.5) * 1.05
		_create_game_piece(x, (0 - 3.5) * 0.88 - 0.4, back_rank[col], Color(0.12, 0.095, 0.07))
		_create_game_piece(x, (1 - 3.5) * 0.88 - 0.4, "P", Color(0.12, 0.095, 0.07))
		_create_game_piece(x, (6 - 3.5) * 0.88 - 0.4, "P", Color(0.88, 0.80, 0.66))
		_create_game_piece(x, (7 - 3.5) * 0.88 - 0.4, back_rank[col], Color(0.88, 0.80, 0.66))

func _create_game_piece(x: float, z: float, kind: String, color: Color) -> void:
	var root := Node3D.new()
	root.position = Vector3(x, 0.64, z)
	var col: int = roundi(x / 1.05 + 3.5)
	var row: int = roundi((z + 0.4) / 0.88 + 3.5)
	root.set_meta("col", col)
	root.set_meta("row", row)
	root.set_meta("kind", kind)
	root.set_meta("team", "black" if color.r < 0.5 else "white")
	world_root.add_child(root)
	game_piece_nodes.append(root)
	var mat := _material(color, 0.34, 0.15)
	_add_piece_cylinder(root, 0.27, 0.12, 0.0, mat)
	_add_piece_cylinder(root, 0.18, 0.48, 0.18, mat)
	_add_piece_cylinder(root, 0.24, 0.10, 0.43, mat)
	match kind:
		"P": _add_piece_sphere(root, 0.17, 0.68, mat)
		"R":
			_add_piece_cylinder(root, 0.23, 0.28, 0.61, mat)
			_add_piece_cylinder(root, 0.28, 0.12, 0.79, mat)
		"N":
			_add_piece_sphere(root, 0.22, 0.70, mat)
			_add_piece_box(root, Vector3(0, 0.82, 0.04), Vector3(0.17, 0.32, 0.25), mat)
		"B":
			_add_piece_sphere(root, 0.18, 0.72, mat)
			_add_piece_cylinder(root, 0.06, 0.24, 0.91, mat)
		"Q":
			_add_piece_sphere(root, 0.22, 0.78, mat)
			_add_piece_cylinder(root, 0.27, 0.10, 0.98, mat)
		"K":
			_add_piece_sphere(root, 0.22, 0.78, mat)
			_add_piece_box(root, Vector3(0, 1.03, 0), Vector3(0.10, 0.35, 0.10), mat)

func _add_game_box(pos: Vector3, size: Vector3, color: Color) -> void:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position = pos
	node.material_override = _material(color, 0.78)
	world_root.add_child(node)

func _add_game_cylinder(pos: Vector3, radius: float, height: float, color: Color, sides: int) -> void:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius * 1.08
	mesh.height = height
	mesh.radial_segments = sides
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position = pos
	node.material_override = _material(color, 0.72)
	world_root.add_child(node)

func _add_piece_cylinder(parent: Node3D, radius: float, height: float, y: float, mat: Material) -> void:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius * 0.78
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 32
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position.y = y + height * 0.5
	node.material_override = mat
	parent.add_child(node)

func _add_piece_sphere(parent: Node3D, radius: float, y: float, mat: Material) -> void:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 32
	mesh.rings = 16
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position.y = y
	node.material_override = mat
	parent.add_child(node)

func _add_piece_box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> void:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position = pos
	node.material_override = mat
	parent.add_child(node)

func _material(color: Color, roughness: float = 0.6, metallic: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	menu_panel = Control.new()
	menu_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(menu_panel)

	var bg := TextureRect.new()
	bg.texture = load("res://assets/castle_hall.png")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_panel.add_child(bg)

	var shade := ColorRect.new()
	shade.color = Color(0.008, 0.006, 0.005, 0.12)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_panel.add_child(shade)

	# Player portrait and progress, matching the reference layout.
	var profile := _panel(menu_panel, 0.015, 0.025, 0.225, 0.155)
	var portrait := TextureRect.new()
	portrait.texture = load("res://assets/profile_portrait.png")
	portrait.position = Vector2(7, 5)
	portrait.size = Vector2(78, 92)
	portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
	portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
	profile.add_child(portrait)
	_add_label(profile, "ChessMaster", Vector2(92, 10), Vector2(175, 25), 18, PALE_GOLD)
	_add_label(profile, "Уровень 12", Vector2(92, 39), Vector2(150, 20), 14, Color(0.9, 0.85, 0.76))
	var xp := ProgressBar.new()
	xp.position = Vector2(92, 65)
	xp.size = Vector2(150, 10)
	xp.max_value = 1000
	xp.value = int(balances["xp"])
	xp.show_percentage = false
	profile.add_child(xp)
	_add_label(profile, "850 / 2000", Vector2(92, 77), Vector2(145, 18), 10, PALE_GOLD)

	# Separate, button-like resource counters: gambits, premium currency and XP.
	var gambits := _ornate_button(menu_panel, "◈  ЗЛОТЫЕ\n%d" % int(balances["zloty"]), 0.285, 0.035, 0.425, 0.125, 14, "nav")
	gambits.name = "ZlotyCounter"
	gambits.pressed.connect(_show_notice.bind("Злотые — игровая валюта. Фигуры покупаются перед каждой партией."))
	var chessmatites := _ornate_button(menu_panel, "◆  ШАХМАТИТЫ\n%d   +" % int(balances["chessmatites"]), 0.432, 0.035, 0.572, 0.125, 14, "nav")
	chessmatites.name = "ChessmatitesCounter"
	chessmatites.pressed.connect(_show_notice.bind("Шахматиты — премиальная валюта"))
	var experience := _ornate_button(menu_panel, "★  XP\n%d" % int(balances["xp"]), 0.579, 0.035, 0.715, 0.125, 14, "nav")
	experience.name = "XPCounter"
	experience.pressed.connect(_show_notice.bind("XP — расходуемый ресурс для открытия фигур и покупки постоянных скинов."))

	# Top-right quick access buttons.
	var quick_names := ["Уведомления", "Рейтинг", "Кланы", "Настройки"]
	var quick_icons := ["♟", "🏆", "♟", "⚙"]
	for i in range(quick_names.size()):
		var x := 0.775 + float(i) * 0.052
		var q := _ornate_button(menu_panel, quick_icons[i] + "\n" + quick_names[i], x, 0.018, x + 0.050, 0.115, 9, "nav")
		q.pressed.connect(_show_notice.bind(quick_names[i] + " — раздел в разработке"))

	# Left-side feature panels from the reference screen.
	var tasks := _panel(menu_panel, 0.015, 0.215, 0.185, 0.365)
	_add_label(tasks, "♜", Vector2(12, 12), Vector2(48, 54), 34, PALE_GOLD)
	_add_label(tasks, "Ежедневные\nзадачи", Vector2(67, 12), Vector2(175, 42), 16, PALE_GOLD)
	_add_label(tasks, "Награды за победы и испытания", Vector2(67, 57), Vector2(175, 32), 10, Color(0.79, 0.72, 0.61))
	var pass_panel := _panel(menu_panel, 0.015, 0.385, 0.185, 0.535)
	_add_label(pass_panel, "♜", Vector2(12, 12), Vector2(48, 54), 34, PALE_GOLD)
	_add_label(pass_panel, "Боевой\nпропуск", Vector2(67, 12), Vector2(175, 42), 16, PALE_GOLD)
	_add_label(pass_panel, "Уровень 12  •  Награды сезона", Vector2(67, 57), Vector2(175, 32), 10, Color(0.79, 0.72, 0.61))
	var event_panel := _panel(menu_panel, 0.015, 0.555, 0.185, 0.705)
	_add_label(event_panel, "⚜", Vector2(12, 12), Vector2(48, 54), 34, PALE_GOLD)
	_add_label(event_panel, "Событие\n«Осенний турнир»", Vector2(67, 10), Vector2(180, 44), 15, PALE_GOLD)
	_add_label(event_panel, "До конца: 7 д. 14 ч.", Vector2(67, 59), Vector2(170, 24), 10, Color(0.79, 0.72, 0.61))

	# Featured collectible card on the right.
	var featured := TextureRect.new()
	featured.texture = load("res://assets/featured_king.png")
	featured.anchor_left = 0.835
	featured.anchor_top = 0.205
	featured.anchor_right = 0.985
	featured.anchor_bottom = 0.525
	featured.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	featured.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
	featured.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_panel.add_child(featured)
	var featured_hit := Button.new()
	featured_hit.anchor_left = 0.835
	featured_hit.anchor_top = 0.205
	featured_hit.anchor_right = 0.985
	featured_hit.anchor_bottom = 0.525
	featured_hit.flat = true
	featured_hit.focus_mode = Control.FOCUS_NONE
	featured_hit.modulate = Color(1, 1, 1, 0.01)
	featured_hit.pressed.connect(_show_notice.bind("Королевский скин — скоро в магазине"))
	menu_panel.add_child(featured_hit)

	# Rotatable 3D collectible preview: pawn owned, other chess pieces locked.
	_build_piece_preview()
	var left_arrow := _ornate_button(menu_panel, "❮", 0.335, 0.445, 0.405, 0.565, 38, "arrow")
	left_arrow.pressed.connect(func(): _change_piece(-1))
	var right_arrow := _ornate_button(menu_panel, "❯", 0.595, 0.445, 0.665, 0.565, 38, "arrow")
	right_arrow.pressed.connect(func(): _change_piece(1))

	var piece_name := _add_label(menu_panel, "ПЕШКА  •  ДОСТУПНА", Vector2.ZERO, Vector2(360, 30), 17, PALE_GOLD)
	piece_name.name = "PieceName"
	piece_name.anchor_left = 0.5
	piece_name.anchor_right = 0.5
	piece_name.anchor_top = 0.665
	piece_name.anchor_bottom = 0.665
	piece_name.offset_left = -180
	piece_name.offset_right = 180
	piece_name.offset_top = 0
	piece_name.offset_bottom = 30
	piece_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var lock_hint := _add_label(menu_panel, "ПРОВЕДИ ВЛЕВО ИЛИ ВПРАВО, ЧТОБЫ СМЕНИТЬ ФИГУРУ", Vector2.ZERO, Vector2(500, 22), 10, Color(0.82, 0.75, 0.63))
	lock_hint.name = "PieceLockHint"
	lock_hint.anchor_left = 0.5
	lock_hint.anchor_right = 0.5
	lock_hint.anchor_top = 0.700
	lock_hint.anchor_bottom = 0.700
	lock_hint.offset_left = -250
	lock_hint.offset_right = 250
	lock_hint.offset_top = 0
	lock_hint.offset_bottom = 22
	lock_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# Large ornamental "PARTY" plaque.
	var party := _ornate_button(menu_panel, "⚔   П А Р Т И Я", 0.365, 0.145, 0.635, 0.255, 23, "party")
	party.pressed.connect(_open_mode_selection)

	# Four large mode cards, each using the same ornate frame as the reference.
	var modes := ["Классика", "Командное голосование", "Несколько фигур"]
	var subtitles := ["Командная партия", "Голосование за ход", "Несколько фигур на игрока"]
	var symbols := ["♞", "♟", "♛"]
	for i in range(modes.size()):
		var x := 0.235 + float(i) * 0.185
		var b := _ornate_button(menu_panel, symbols[i] + "\n" + modes[i] + "\n" + subtitles[i], x, 0.735, x + 0.175, 0.885, 15, "card")
		b.pressed.connect(_on_mode_pressed.bind(modes[i]))

	# Bottom navigation: six engraved sections in one continuous row.
	var nav_names := ["Магазин", "Рейтинг", "Кланы", "Шахматный город", "Коллекция", "Пропуск"]
	var nav_icons := ["♜", "▥", "⚑", "♜", "♛", "▣"]
	for i in range(nav_names.size()):
		var x := 0.012 + float(i) * 0.163
		var b := _ornate_button(menu_panel, nav_icons[i] + "\n" + nav_names[i], x, 0.900, x + 0.158, 0.998, 13, "nav")
		if nav_names[i] == "Шахматный город":
			b.pressed.connect(func(): _show_notice("ШАХМАТНЫЙ ГОРОД — отдельный режим. Открытые фигуры доступны постоянно, без расхода злотых за вход."))
		else:
			b.pressed.connect(_show_notice.bind(nav_names[i] + " — раздел в разработке"))

	# Gameplay screen and return button.
	game_panel = Control.new()
	game_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	game_panel.visible = false
	ui.add_child(game_panel)
	var header := _panel(game_panel, 0.02, 0.025, 0.43, 0.11)
	_add_label(header, "ПАРТИЯ  •  " + selected_mode, Vector2(12, 8), Vector2(480, 28), 18, PALE_GOLD)
	var back := _ornate_button(game_panel, "←  В МЕНЮ", 0.82, 0.025, 0.98, 0.11, 15, "card")
	back.pressed.connect(_return_to_menu)
	status_label = _add_label(game_panel, "Выберите фигуру на доске", Vector2.ZERO, Vector2(500, 34), 16, PALE_GOLD)
	status_label.anchor_left = 0.5
	status_label.anchor_right = 0.5
	status_label.anchor_top = 1.0
	status_label.anchor_bottom = 1.0
	status_label.offset_left = -250
	status_label.offset_right = 250
	status_label.offset_top = -48
	status_label.offset_bottom = -8
	team_turn_label = _add_label(game_panel, "ХОД: БЕЛЫЕ • ИГРОК 1/4", Vector2.ZERO, Vector2(420, 30), 16, PALE_GOLD)
	team_turn_label.anchor_left = 0.5
	team_turn_label.anchor_right = 0.5
	team_turn_label.anchor_top = 0.12
	team_turn_label.anchor_bottom = 0.12
	team_turn_label.offset_left = -210
	team_turn_label.offset_right = 210
	team_turn_label.offset_top = 0
	team_turn_label.offset_bottom = 30
	var pass_turn := _ornate_button(game_panel, "ПЕРЕДАТЬ ХОД СОЮЗНИКУ", 0.27, 0.88, 0.49, 0.98, 13, "nav")
	pass_turn.pressed.connect(_pass_to_teammate)
	var end_turn := _ornate_button(game_panel, "ЗАВЕРШИТЬ ХОД", 0.51, 0.88, 0.73, 0.98, 13, "party")
	end_turn.pressed.connect(_advance_team_turn)
	_build_preparation_screen()

func _build_preparation_screen() -> void:
	preparation_panel = Control.new()
	preparation_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	preparation_panel.visible = false
	ui.add_child(preparation_panel)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.012, 0.010, 0.96)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	preparation_panel.add_child(shade)
	var frame := _panel(preparation_panel, 0.06, 0.07, 0.94, 0.93)
	_add_label(frame, "ПОДГОТОВКА К ПАРТИИ", Vector2(24, 16), Vector2(650, 42), 27, PALE_GOLD)
	var mode_label := _add_label(frame, "РЕЖИМ: " + selected_mode.to_upper(), Vector2(26, 67), Vector2(500, 28), 16, Color(0.83, 0.77, 0.67))
	mode_label.name = "PrepModeLabel"
	var close := _ornate_button(frame, "← НАЗАД", 0.77, 0.035, 0.97, 0.14, 14, "nav")
	close.pressed.connect(_close_preparation)
	_add_label(frame, "ВЫБЕРИ ФИГУРУ ДЛЯ ЭТОЙ ПАРТИИ", Vector2(26, 112), Vector2(600, 28), 17, PALE_GOLD)
	var pieces := ["Пешка", "Конь", "Слон", "Ладья", "Ферзь"]
	for i in range(pieces.size()):
		var y := 0.245 + float(i) * 0.112
		var piece: String = pieces[i]
		var btn := _ornate_button(frame, piece.to_upper(), 0.035, y, 0.30, y + 0.095, 15, "card")
		btn.pressed.connect(_select_preparation_piece.bind(piece))
		prep_piece_buttons.append(btn)
	var info := _panel(frame, 0.35, 0.24, 0.96, 0.72)
	_add_label(info, "ПРАВИЛА ПОКУПКИ", Vector2(18, 14), Vector2(400, 28), 17, PALE_GOLD)
	_add_label(info, "Открытие фигуры: XP списывается один раз.\nПокупка перед матчем: злотые списываются за каждую партию.\nВ Шахматном городе открытые фигуры не расходуются.", Vector2(18, 54), Vector2(540, 100), 13, Color(0.84, 0.79, 0.70))
	var selected_label := _add_label(info, "ВЫБРАНА: ПЕШКА", Vector2(18, 170), Vector2(500, 30), 18, PALE_GOLD)
	selected_label.name = "PrepSelectedLabel"
	prep_status = _add_label(info, "Пешка доступна бесплатно.", Vector2(18, 210), Vector2(540, 55), 13, Color(0.86, 0.81, 0.72))
	var action := _ornate_button(info, "ВЫБРАТЬ ФИГУРУ", 0.06, 0.74, 0.92, 0.94, 17, "party")
	action.name = "PrepActionButton"
	action.pressed.connect(_purchase_or_unlock_selected)
	_refresh_preparation_ui()

func _open_preparation() -> void:
	menu_panel.visible = false
	preparation_panel.visible = true
	var mode_label := preparation_panel.find_child("PrepModeLabel", true, false) as Label
	if mode_label:
		mode_label.text = "РЕЖИМ: " + selected_mode.to_upper()
	_refresh_preparation_ui()

func _close_preparation() -> void:
	preparation_panel.visible = false
	menu_panel.visible = true

func _select_preparation_piece(piece_name: String) -> void:
	selected_prep_piece = PIECES.find(piece_name)
	_refresh_preparation_ui()

func _refresh_preparation_ui() -> void:
	if preparation_panel == null:
		return
	for i in range(prep_piece_buttons.size()):
		var piece: String = ["Пешка", "Конь", "Слон", "Ладья", "Ферзь"][i]
		var unlocked := unlocked_pieces.has(piece)
		prep_piece_buttons[i].text = ("✓  " if unlocked else "🔒  ") + piece.to_upper()
	var piece_name: String = PIECES[selected_prep_piece]
	var info := preparation_panel.find_child("PrepSelectedLabel", true, false) as Label
	var action := preparation_panel.find_child("PrepActionButton", true, false) as Button
	if info:
		info.text = "ВЫБРАНА: " + piece_name.to_upper()
	if action:
		if not unlocked_pieces.has(piece_name):
			action.text = "ОТКРЫТЬ ЗА %d XP" % int(piece_unlock_xp.get(piece_name, 0))
		elif int(match_piece_costs.get(piece_name, 0)) > 0:
			action.text = "КУПИТЬ НА ПАРТИЮ — %d ЗЛОТЫХ" % int(match_piece_costs[piece_name])
		else:
			action.text = "ВЫБРАТЬ ФИГУРУ"
	if prep_status:
		if not unlocked_pieces.has(piece_name):
			prep_status.text = "Для открытия нужно %d XP. Сейчас: %d XP." % [int(piece_unlock_xp.get(piece_name, 0)), int(balances["xp"])]
		elif int(match_piece_costs.get(piece_name, 0)) > 0:
			prep_status.text = "Фигура открыта. Покупка на одну партию стоит %d злотых." % int(match_piece_costs[piece_name])
		else:
			prep_status.text = "Фигура доступна. Стоимость на эту партию: бесплатно."
	_save_economy()

func _purchase_or_unlock_selected() -> void:
	var piece_name: String = PIECES[selected_prep_piece]
	if not unlocked_pieces.has(piece_name):
		var xp_cost := int(piece_unlock_xp.get(piece_name, 0))
		if int(balances["xp"]) < xp_cost:
			prep_status.text = "Недостаточно XP. Нужно ещё %d." % (xp_cost - int(balances["xp"]))
			return
		balances["xp"] = int(balances["xp"]) - xp_cost
		unlocked_pieces.append(piece_name)
		prep_status.text = piece_name + " открыта навсегда. XP списан."
		_save_economy()
		_refresh_preparation_ui()
		return
	var cost := int(match_piece_costs.get(piece_name, 0))
	if int(balances["zloty"]) < cost:
		prep_status.text = "Недостаточно злотых. Нужно ещё %d." % (cost - int(balances["zloty"]))
		return
	balances["zloty"] = int(balances["zloty"]) - cost
	_save_economy()
	prep_status.text = piece_name + " выбрана. Списано %d злотых. Запускаем партию." % cost
	_confirm_preparation()

func _confirm_preparation() -> void:
	preparation_panel.visible = false
	_start_game(selected_mode)

func _load_economy() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("user://checkmate_economy.cfg") == OK:
		balances["zloty"] = int(cfg.get_value("wallet", "zloty", balances["zloty"]))
		balances["xp"] = int(cfg.get_value("wallet", "xp", balances["xp"]))
		balances["chessmatites"] = int(cfg.get_value("wallet", "chessmatites", balances["chessmatites"]))
		unlocked_pieces = cfg.get_value("progress", "unlocked_pieces", unlocked_pieces)
		owned_skins = cfg.get_value("progress", "owned_skins", owned_skins)

func _save_economy() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("wallet", "zloty", balances["zloty"])
	cfg.set_value("wallet", "xp", balances["xp"])
	cfg.set_value("wallet", "chessmatites", balances["chessmatites"])
	cfg.set_value("progress", "unlocked_pieces", unlocked_pieces)
	cfg.set_value("progress", "owned_skins", owned_skins)
	cfg.save("user://checkmate_economy.cfg")

func _build_piece_preview() -> void:
	preview_container = SubViewportContainer.new()
	preview_container.anchor_left = 0.375
	preview_container.anchor_top = 0.275
	preview_container.anchor_right = 0.625
	preview_container.anchor_bottom = 0.705
	preview_container.mouse_filter = Control.MOUSE_FILTER_STOP
	preview_container.stretch = true
	menu_panel.add_child(preview_container)
	var sub := SubViewport.new()
	sub.size = Vector2i(640, 640)
	sub.transparent_bg = true
	sub.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	preview_container.add_child(sub)
	var scene := Node3D.new()
	sub.add_child(scene)
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0, 0, 0, 0)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.58, 0.52, 0.44)
	env.ambient_light_energy = 0.78
	env_node.environment = env
	scene.add_child(env_node)
	var cam := Camera3D.new()
	cam.position = Vector3(0, 1.55, 6.6)
	cam.fov = 32
	scene.add_child(cam)
	cam.look_at(Vector3(0, 1.05, 0), Vector3.UP)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-35, -25, 0)
	key.light_color = Color(1.0, 0.88, 0.70)
	key.light_energy = 1.15
	key.shadow_enabled = true
	scene.add_child(key)
	var fill := OmniLight3D.new()
	fill.position = Vector3(-2.2, 2.8, 2.5)
	fill.light_color = Color(1.0, 0.72, 0.42)
	fill.light_energy = 0.85
	fill.omni_range = 9
	scene.add_child(fill)
	var rim_light := OmniLight3D.new()
	rim_light.position = Vector3(2.0, 2.0, -1.8)
	rim_light.light_color = Color(0.72, 0.82, 1.0)
	rim_light.light_energy = 0.45
	rim_light.omni_range = 7
	scene.add_child(rim_light)

	# A restrained, dark carved-stone plinth: no gold trim or bright metallic shine.
	var stone := _material(Color(0.035, 0.032, 0.030), 0.88, 0.02)
	var stone_edge := _material(Color(0.075, 0.067, 0.060), 0.82, 0.04)
	var pedestal := MeshInstance3D.new()
	var ped_mesh := CylinderMesh.new()
	ped_mesh.top_radius = 0.90
	ped_mesh.bottom_radius = 1.04
	ped_mesh.height = 0.28
	ped_mesh.radial_segments = 96
	pedestal.mesh = ped_mesh
	pedestal.position.y = 0.14
	pedestal.material_override = stone
	scene.add_child(pedestal)
	var lower_band := MeshInstance3D.new()
	var lower_mesh := CylinderMesh.new()
	lower_mesh.top_radius = 1.07
	lower_mesh.bottom_radius = 1.07
	lower_mesh.height = 0.065
	lower_mesh.radial_segments = 96
	lower_band.mesh = lower_mesh
	lower_band.position.y = 0.045
	lower_band.material_override = stone_edge
	scene.add_child(lower_band)
	var upper_band := MeshInstance3D.new()
	var upper_mesh := CylinderMesh.new()
	upper_mesh.top_radius = 0.94
	upper_mesh.bottom_radius = 0.94
	upper_mesh.height = 0.045
	upper_mesh.radial_segments = 96
	upper_band.mesh = upper_mesh
	upper_band.position.y = 0.285
	upper_band.material_override = stone_edge
	scene.add_child(upper_band)
	_add_preview_torus(scene, 0.99, 0.018, 0.315, stone_edge)
	_add_preview_torus(scene, 1.025, 0.012, 0.075, stone_edge)

	preview_pawn = Node3D.new()
	preview_pawn.position.y = 0.32
	scene.add_child(preview_pawn)
	_build_preview_piece("Пешка")

func _build_preview_piece(piece_name: String) -> void:
	for child in preview_pawn.get_children():
		child.queue_free()
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.62, 0.43, 0.27)
	wood.albedo_texture = load("res://assets/dark_walnut.jpg")
	wood.roughness = 0.84
	wood.metallic = 0.0
	wood.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
	var ivory := wood
	var gold := _material(Color(0.12, 0.085, 0.055), 0.88, 0.0)
	var dark_gold := _material(Color(0.075, 0.055, 0.04), 0.92, 0.0)

	# Shared sculpted base and tapered body, with a classic Staunton silhouette.
	var profile := [
		Vector2(0.02, 0.00), Vector2(0.37, 0.00), Vector2(0.44, 0.045),
		Vector2(0.46, 0.10), Vector2(0.43, 0.16), Vector2(0.35, 0.205),
		Vector2(0.29, 0.25), Vector2(0.25, 0.31), Vector2(0.22, 0.39),
		Vector2(0.19, 0.48), Vector2(0.155, 0.58), Vector2(0.145, 0.68),
		Vector2(0.17, 0.75), Vector2(0.25, 0.79), Vector2(0.28, 0.84),
		Vector2(0.24, 0.89), Vector2(0.16, 0.92)
	]
	_add_preview_lathe(preview_pawn, profile, ivory, 64)
	_add_preview_torus(preview_pawn, 0.395, 0.026, 0.145, gold)
	_add_preview_torus(preview_pawn, 0.205, 0.018, 0.535, dark_gold)
	_add_preview_torus(preview_pawn, 0.255, 0.022, 0.825, gold)

	match piece_name:
		"Пешка":
			_add_preview_sphere(0.205, 1.12, ivory)
		"Ладья":
			_add_preview_cylinder(0.205, 0.30, 0.90, ivory)
			_add_preview_cylinder(0.275, 0.10, 1.17, gold)
			for j in range(6):
				var angle := TAU * float(j) / 6.0
				_add_preview_box(Vector3(cos(angle) * 0.19, 1.31, sin(angle) * 0.19), Vector3(0.105, 0.20, 0.105), ivory)
		"Конь":
			_add_preview_sphere(0.20, 1.10, ivory)
			_add_preview_box(Vector3(0, 1.30, -0.02), Vector3(0.29, 0.43, 0.22), ivory)
			_add_preview_box(Vector3(0.0, 1.49, 0.015), Vector3(0.23, 0.10, 0.20), gold)
		"Слон":
			_add_preview_sphere(0.19, 1.12, ivory)
			_add_preview_cylinder(0.055, 0.34, 1.23, gold)
			_add_preview_sphere(0.075, 1.58, gold)
		"Ферзь":
			_add_preview_sphere(0.19, 1.12, ivory)
			_add_preview_cylinder(0.26, 0.10, 1.22, gold)
			for j in range(5):
				var angle := TAU * float(j) / 5.0
				var crown_point := _add_preview_sphere(0.055, 1.39, gold)
				crown_point.position.x = cos(angle) * 0.19
				crown_point.position.z = sin(angle) * 0.19
		"Король":
			_add_preview_sphere(0.19, 1.12, ivory)
			_add_preview_cylinder(0.25, 0.10, 1.22, gold)
			_add_preview_box(Vector3(0, 1.48, 0), Vector3(0.10, 0.43, 0.10), gold)
			_add_preview_box(Vector3(0, 1.54, 0), Vector3(0.32, 0.10, 0.10), gold)

func _add_preview_lathe(parent: Node3D, profile: Array, mat: Material, segments: int = 48) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for ring in range(profile.size() - 1):
		var a: Vector2 = profile[ring]
		var b: Vector2 = profile[ring + 1]
		for i in range(segments):
			var a0 := TAU * float(i) / float(segments)
			var a1 := TAU * float(i + 1) / float(segments)
			var p00 := Vector3(cos(a0) * a.x, a.y, sin(a0) * a.x)
			var p01 := Vector3(cos(a1) * a.x, a.y, sin(a1) * a.x)
			var p10 := Vector3(cos(a0) * b.x, b.y, sin(a0) * b.x)
			var p11 := Vector3(cos(a1) * b.x, b.y, sin(a1) * b.x)
			var u0 := float(i) / float(segments)
			var u1 := float(i + 1) / float(segments)
			var v0 := float(ring) / float(profile.size() - 1)
			var v1 := float(ring + 1) / float(profile.size() - 1)
			st.set_uv(Vector2(u0, v0))
			st.add_vertex(p00)
			st.set_uv(Vector2(u0, v1))
			st.add_vertex(p10)
			st.set_uv(Vector2(u1, v1))
			st.add_vertex(p11)
			st.set_uv(Vector2(u0, v0))
			st.add_vertex(p00)
			st.set_uv(Vector2(u1, v1))
			st.add_vertex(p11)
			st.set_uv(Vector2(u1, v0))
			st.add_vertex(p01)
	st.generate_normals()
	var mesh := st.commit()
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.material_override = mat
	parent.add_child(node)

func _add_preview_torus(parent: Node3D, radius: float, tube_radius: float, y: float, mat: Material) -> void:
	var mesh := TorusMesh.new()
	mesh.inner_radius = maxf(0.01, radius - tube_radius)
	mesh.outer_radius = radius + tube_radius
	mesh.rings = 64
	mesh.ring_segments = 12
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position.y = y
	node.material_override = mat
	parent.add_child(node)

func _add_preview_cylinder(radius: float, height: float, y: float, mat: Material) -> void:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius * 0.78
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 48
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position.y = y + height * 0.5
	node.material_override = mat
	preview_pawn.add_child(node)

func _add_preview_sphere(radius: float, y: float, mat: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 48
	mesh.rings = 24
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position.y = y
	node.material_override = mat
	preview_pawn.add_child(node)
	return node

func _add_preview_box(pos: Vector3, size: Vector3, mat: Material) -> void:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position = pos
	node.material_override = mat
	preview_pawn.add_child(node)

func _input(event: InputEvent) -> void:
	if game_panel != null and game_panel.visible and world_root.visible:
		if event is InputEventScreenTouch and event.pressed:
			_handle_game_board_click(event.position)
			return
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			_handle_game_board_click(event.position)
			return
	if menu_panel == null or not menu_panel.visible or preview_container == null:
		return
	if event is InputEventScreenTouch:
		if event.pressed and preview_container.get_global_rect().has_point(event.position):
			dragging_preview = true
			last_pointer_x = event.position.x
			last_pointer_y = event.position.y
		elif not event.pressed:
			dragging_preview = false
	elif event is InputEventScreenDrag and dragging_preview:
		_rotate_preview_from_drag(event.position.x, event.position.y)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and preview_container.get_global_rect().has_point(event.position):
			dragging_preview = true
			last_pointer_x = event.position.x
			last_pointer_y = event.position.y
		else:
			dragging_preview = false
	elif event is InputEventMouseMotion and dragging_preview:
		_rotate_preview_from_drag(event.position.x, event.position.y)

func _rotate_preview_from_drag(pointer_x: float, pointer_y: float) -> void:
	var delta_x := pointer_x - last_pointer_x
	var delta_y := pointer_y - last_pointer_y
	# Horizontal movement turns the piece around; vertical movement tilts it.
	preview_pawn.rotate_y(deg_to_rad(delta_x * 0.85))
	preview_pawn.rotate_x(deg_to_rad(delta_y * 0.75))
	last_pointer_x = pointer_x
	last_pointer_y = pointer_y

func _change_piece(direction: int) -> void:
	selected_piece = posmod(selected_piece + direction, PIECES.size())
	var piece_name: String = PIECES[selected_piece]
	_build_preview_piece(piece_name)
	var label := menu_panel.find_child("PieceName", true, false) as Label
	if label:
		label.text = piece_name.to_upper() + ("   •   ДОСТУПНА" if selected_piece == 0 else "   •   🔒 ЗАБЛОКИРОВАНА")
	var hint := menu_panel.find_child("PieceLockHint", true, false) as Label
	if hint:
		hint.text = "🔒 ОТКРОЙ ФИГУРУ В КОЛЛЕКЦИИ" if selected_piece != 0 else "ВОДИ ПАЛЬЦЕМ ВЛЕВО/ВПРАВО И ВВЕРХ/ВНИЗ — ВРАЩЕНИЕ НА 360°"
	if selected_piece != 0:
		_show_notice("🔒 " + piece_name + " пока заблокирована. Открой её в магазине.")

func _panel(parent: Control, l: float, t: float, r: float, b: float) -> Panel:
	var p := Panel.new()
	p.anchor_left = l
	p.anchor_top = t
	p.anchor_right = r
	p.anchor_bottom = b
	var style := StyleBoxFlat.new()
	style.bg_color = DARK
	style.border_color = Color(0.62, 0.47, 0.27, 0.98)
	style.set_border_width_all(2)
	style.set_corner_radius_all(2)
	style.shadow_color = Color(0, 0, 0, 0.7)
	style.shadow_size = 10
	style.shadow_offset = Vector2(0, 4)
	p.add_theme_stylebox_override("panel", style)
	parent.add_child(p)
	return p

func _ornate_button(parent: Control, text_value: String, l: float, t: float, r: float, b: float, font_size: int, style_kind: String = "card") -> Button:
	var button := Button.new()
	button.text = text_value
	button.anchor_left = l
	button.anchor_top = t
	button.anchor_right = r
	button.anchor_bottom = b
	button.add_theme_font_size_override("font_size", font_size)
	button.add_theme_font_override("font", UI_FONT)
	button.add_theme_color_override("font_color", Color(0.91, 0.83, 0.70))
	button.add_theme_color_override("font_hover_color", Color(1.0, 0.95, 0.82))
	button.add_theme_color_override("font_pressed_color", Color(0.78, 0.60, 0.36))
	button.add_theme_color_override("font_disabled_color", Color(0.48, 0.42, 0.34))
	button.add_theme_color_override("font_outline_color", Color(0.02, 0.015, 0.01, 0.98))
	button.add_theme_constant_override("outline_size", 3)
	button.alignment = HORIZONTAL_ALIGNMENT_CENTER
	button.focus_mode = Control.FOCUS_NONE
	button.clip_text = true

	var texture_path := "res://assets/ornate_button.png"
	var ml := 42.0
	var mt := 34.0
	if style_kind == "party":
		texture_path = "res://assets/ornate_party_button.png"
		ml = 58.0
		mt = 24.0
	elif style_kind == "nav":
		texture_path = "res://assets/ornate_nav_button.png"
		ml = 30.0
		mt = 25.0
	elif style_kind == "arrow":
		texture_path = "res://assets/ornate_button.png"
		ml = 18.0
		mt = 16.0

	var normal := StyleBoxTexture.new()
	normal.texture = load(texture_path)
	normal.texture_margin_left = ml
	normal.texture_margin_right = ml
	normal.texture_margin_top = mt
	normal.texture_margin_bottom = mt
	normal.draw_center = true
	normal.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	normal.axis_stretch_vertical = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	normal.content_margin_left = 28
	normal.content_margin_right = 28
	normal.content_margin_top = 17
	normal.content_margin_bottom = 17

	var hover := normal.duplicate()
	hover.modulate_color = Color(1.42, 1.29, 1.06, 1.0)
	var pressed := normal.duplicate()
	pressed.modulate_color = Color(0.78, 0.62, 0.39, 1.0)
	var disabled := normal.duplicate()
	disabled.modulate_color = Color(0.48, 0.43, 0.35, 0.8)
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("disabled", disabled)
	button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	parent.add_child(button)
	return button

func _add_label(parent: Control, text_value: String, pos: Vector2, size: Vector2, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text_value
	label.position = pos
	label.size = size
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_font_override("font", UI_LABEL_FONT)
	label.add_theme_color_override("font_color", color)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(label)
	return label

func _show_notice(message: String) -> void:
	if status_label != null:
		status_label.text = message

func _on_mode_pressed(mode_name: String) -> void:
	selected_mode = mode_name
	_show_notice("Выбран режим: " + selected_mode + ". Нажми ПАРТИЯ для подготовки.")

func _start_game(mode_name: String) -> void:
	current_team = "white"
	active_teammate = 1
	selected_game_piece = null
	_refresh_team_turn_label()
	menu_panel.visible = false
	game_panel.visible = true
	world_root.visible = true
	for child in game_panel.get_children():
		if child is Panel:
			for sub in child.get_children():
				if sub is Label and sub.text.begins_with("ПАРТИЯ"):
					sub.text = "ПАРТИЯ  •  " + mode_name
	status_label.text = "Режим: " + mode_name + "  |  Партия началась"
	camera.position = Vector3(0, 10.5, 12.0)
	camera.look_at(Vector3(0, 0.5, -0.4), Vector3.UP)

func _return_to_menu() -> void:
	selected_game_piece = null
	game_panel.visible = false
	menu_panel.visible = true
	_refresh_wallet_labels()
	world_root.visible = false
	camera.position = Vector3(0, 9.5, 13.0)
	camera.look_at(Vector3(0, 1.0, 0), Vector3.UP)

func _refresh_wallet_labels() -> void:
	var zloty := menu_panel.find_child("ZlotyCounter", true, false) as Button
	var chessmatites := menu_panel.find_child("ChessmatitesCounter", true, false) as Button
	var xp := menu_panel.find_child("XPCounter", true, false) as Button
	if zloty:
		zloty.text = "◈  ЗЛОТЫЕ\n%d" % int(balances["zloty"])
	if chessmatites:
		chessmatites.text = "◆  ШАХМАТИТЫ\n%d   +" % int(balances["chessmatites"])
	if xp:
		xp.text = "★  XP\n%d" % int(balances["xp"])



func _open_mode_selection() -> void:
	if mode_selection_panel == null:
		_build_mode_selection_screen()
	menu_panel.visible = false
	preparation_panel.visible = false
	mode_selection_panel.visible = true
	_refresh_mode_selection()

func _build_mode_selection_screen() -> void:
	mode_selection_panel = Control.new()
	mode_selection_panel.name = "ModeSelectionScreen"
	mode_selection_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mode_selection_panel.visible = false
	ui.add_child(mode_selection_panel)

	var shade := ColorRect.new()
	shade.color = Color(0.012, 0.010, 0.009, 0.97)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mode_selection_panel.add_child(shade)

	var frame := _panel(mode_selection_panel, 0.045, 0.055, 0.955, 0.945)
	_add_label(frame, "ВЫБОР ИГРОВОГО РЕЖИМА", Vector2(24, 18), Vector2(680, 42), 27, PALE_GOLD)
	_add_label(frame, "Выбери правила командной партии", Vector2(26, 62), Vector2(580, 26), 15, Color(0.78, 0.72, 0.63))

	var back := _ornate_button(frame, "← НАЗАД", 0.80, 0.035, 0.97, 0.135, 14, "nav")
	back.pressed.connect(_close_mode_selection)

	var names := ["Классика", "Командное голосование", "Несколько фигур"]
	var symbols := ["01", "02", "03"]
	var captions := [
		"Свободная командная игра",
		"Решение всей команды",
		"Несколько фигур у игрока"
	]
	for i in range(names.size()):
		var left := 0.035 + float(i) * 0.315
		var card_text: String = symbols[i] + "  |  " + names[i] + "  |  " + captions[i]
		var card := _ornate_button(frame, card_text, left, 0.235, left + 0.285, 0.57, 16, "card")
		card.pressed.connect(_select_mode_card.bind(names[i]))
		mode_choice_buttons.append(card)

	var details := _panel(frame, 0.035, 0.625, 0.965, 0.835)
	_add_label(details, "КАК ПРОХОДИТ РЕЖИМ", Vector2(18, 12), Vector2(500, 26), 16, PALE_GOLD)
	mode_description_label = _add_label(details, "", Vector2(18, 47), Vector2(760, 66), 14, Color(0.86, 0.81, 0.72))
	var next_button := _ornate_button(frame, "ПРОДОЛЖИТЬ  →", 0.67, 0.865, 0.965, 0.975, 17, "party")
	next_button.pressed.connect(_continue_to_preparation)

	_refresh_mode_selection()

func _select_mode_card(mode_name: String) -> void:
	selected_mode = mode_name
	_refresh_mode_selection()

func _refresh_mode_selection() -> void:
	var names := ["Классика", "Командное голосование", "Несколько фигур"]
	var captions := [
		"Каждый участник управляет своей фигурой. В свой ход игрок может сделать допустимый ход или передать очередь союзнику. Команда играет против другой команды.",
		"Игрок предлагает ход, а союзники обсуждают и голосуют. За правильное командное решение предусмотрен бонус к наградам. Голосование ограничено временем.",
		"У каждого участника может быть несколько фигур. Игрок выбирает, какой фигурой ходить, или передаёт очередь союзнику. Система подсказывает, кому лучше передать ход."
	]
	for i in range(min(mode_choice_buttons.size(), names.size())):
		var marker := "◆  " if selected_mode == names[i] else ""
		mode_choice_buttons[i].text = marker + "%02d" % (i + 1) + "  |  " + names[i] + "  |  " + ["Свободная командная игра", "Решение всей команды", "Несколько фигур у игрока"][i]
	if mode_description_label:
		var index := names.find(selected_mode)
		if index < 0:
			index = 0
			selected_mode = names[0]
		mode_description_label.text = captions[index]

func _continue_to_preparation() -> void:
	mode_selection_panel.visible = false
	_open_preparation()

func _close_mode_selection() -> void:
	if mode_selection_panel:
		mode_selection_panel.visible = false
	menu_panel.visible = true

func _handle_game_board_click(screen_position: Vector2) -> void:
	if selected_mode != "Классика":
		status_label.text = "Этот режим пока в разработке. Сейчас тестируем механику классической партии."
		return
	if team_turn_label and team_turn_label.get_global_rect().has_point(screen_position):
		return
	var ray_origin: Vector3 = camera.project_ray_origin(screen_position)
	var ray_direction: Vector3 = camera.project_ray_normal(screen_position)
	var board_plane := Plane(Vector3.UP, 0.59)
	var hit = board_plane.intersects_ray(ray_origin, ray_direction)
	if hit == null:
		return
	var col: int = roundi(hit.x / 1.05 + 3.5)
	var row: int = roundi((hit.z + 0.4) / 0.88 + 3.5)
	if col < 0 or col > 7 or row < 0 or row > 7:
		return
	var target_piece: Node3D = _get_game_piece_at(col, row)
	if selected_game_piece == null:
		if target_piece != null and str(target_piece.get_meta("team")) == current_team:
			selected_game_piece = target_piece
			status_label.text = "Выбрана фигура: " + str(selected_game_piece.get_meta("kind")) + ". Выбери клетку для хода."
		else:
			status_label.text = "Сейчас ходят " + ("белые" if current_team == "white" else "чёрные") + ". Выбери свою фигуру."
		return
	if target_piece == selected_game_piece:
		selected_game_piece = null
		status_label.text = "Выбор отменён."
		return
	if target_piece != null:
		if str(target_piece.get_meta("team")) == current_team:
			selected_game_piece = target_piece
			status_label.text = "Выбрана фигура: " + str(target_piece.get_meta("kind")) + "."
		else:
			status_label.text = "На этой клетке противник. Боевой вызов добавим следующим этапом."
		return
	var from_col: int = int(selected_game_piece.get_meta("col"))
	var from_row: int = int(selected_game_piece.get_meta("row"))
	var kind: String = str(selected_game_piece.get_meta("kind"))
	if not _is_valid_classic_move(kind, current_team, from_col, from_row, col, row):
		status_label.text = "Недопустимый ход для этой фигуры."
		return
	selected_game_piece.position = Vector3((col - 3.5) * 1.05, 0.64, (row - 3.5) * 0.88 - 0.4)
	selected_game_piece.set_meta("col", col)
	selected_game_piece.set_meta("row", row)
	selected_game_piece = null
	status_label.text = "Ход выполнен. Очередь перешла другой команде."
	_advance_team_turn()

func _get_game_piece_at(col: int, row: int) -> Node3D:
	for piece in game_piece_nodes:
		if is_instance_valid(piece) and int(piece.get_meta("col")) == col and int(piece.get_meta("row")) == row:
			return piece
	return null

func _is_valid_classic_move(kind: String, team: String, from_col: int, from_row: int, to_col: int, to_row: int) -> bool:
	var dc: int = to_col - from_col
	var dr: int = to_row - from_row
	if dc == 0 and dr == 0:
		return false
	var valid_shape := false
	match kind:
		"P":
			var forward: int = -1 if team == "white" else 1
			var start_row: int = 6 if team == "white" else 1
			valid_shape = (dc == 0 and dr == forward) or (dc == 0 and from_row == start_row and dr == forward * 2)
		"N":
			valid_shape = (abs(dc) == 1 and abs(dr) == 2) or (abs(dc) == 2 and abs(dr) == 1)
		"R":
			valid_shape = dc == 0 or dr == 0
		"B":
			valid_shape = abs(dc) == abs(dr)
		"Q":
			valid_shape = dc == 0 or dr == 0 or abs(dc) == abs(dr)
		"K":
			valid_shape = max(abs(dc), abs(dr)) == 1
	if not valid_shape:
		return false
	if kind in ["R", "B", "Q"]:
		return _is_classic_path_clear(from_col, from_row, to_col, to_row)
	return true

func _is_classic_path_clear(from_col: int, from_row: int, to_col: int, to_row: int) -> bool:
	var step_col: int = int(sign(to_col - from_col))
	var step_row: int = int(sign(to_row - from_row))
	var col: int = from_col + step_col
	var row: int = from_row + step_row
	while col != to_col or row != to_row:
		if _get_game_piece_at(col, row) != null:
			return false
		col += step_col
		row += step_row
	return true

func _pass_to_teammate() -> void:
	if selected_mode != "Классика":
		status_label.text = "Передача хода будет доступна после подключения правил этого режима."
		return
	active_teammate = (active_teammate % 4) + 1
	selected_game_piece = null
	_refresh_team_turn_label()
	status_label.text = "Очередь передана союзнику. Ход всё ещё за вашей командой."

func _advance_team_turn() -> void:
	current_team = "black" if current_team == "white" else "white"
	active_teammate = 1
	selected_game_piece = null
	_refresh_team_turn_label()

func _refresh_team_turn_label() -> void:
	if team_turn_label:
		var team_name := "БЕЛЫЕ" if current_team == "white" else "ЧЁРНЫЕ"
		team_turn_label.text = "ХОД: " + team_name + " • ИГРОК " + str(active_teammate) + "/4"