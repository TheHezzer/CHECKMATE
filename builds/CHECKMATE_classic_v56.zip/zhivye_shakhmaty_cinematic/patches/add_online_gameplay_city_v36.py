from pathlib import Path
p=Path(__file__).resolve().parent.parent/'scripts'/'main.gd'
s=p.read_text(encoding='utf-8')

def rep(old,new,label):
    global s
    if old not in s:
        raise SystemExit('Missing anchor: '+label)
    s=s.replace(old,new,1)

# Online authoritative-session state and authenticated account/city state.
rep('const MATCHMAKING_SERVER_URL := "https://YOUR-MATCHMAKING-SERVER"', 'var matchmaking_server_url := "https://YOUR-MATCHMAKING-SERVER"', 'server url config')
rep('var online_player_id := ""\n', '''var online_player_id := ""
var online_match_id := ""
var online_session_token := ""
var online_active_player_id := ""
var game_state_poll_timer: Timer
var last_game_state_update := -1
var team_chat_label: Label
var team_chat_input: LineEdit
var account_token := ""
var account_player_id := ""
var city_panel: Control
var city_username_input: LineEdit
var city_password_input: LineEdit
var city_status_label: Label
var city_piece_buttons: Array[Button] = []
var city_skin_buttons: Array[Button] = []
var city_profile_data: Dictionary = {}
var city_owned_pieces := ["Пешка"]
''', 'online/city variables')
# Persist server endpoint and authenticated account token locally.
rep('        onboarding_completed = bool(cfg.get_value("onboarding", "completed", false))', '''        onboarding_completed = bool(cfg.get_value("onboarding", "completed", false))
        matchmaking_server_url = str(cfg.get_value("network", "server_url", matchmaking_server_url))
        account_token = str(cfg.get_value("account", "token", ""))
        account_player_id = str(cfg.get_value("account", "player_id", ""))''', 'load network/account')
rep('    cfg.set_value("onboarding", "completed", onboarding_completed)', '''    cfg.set_value("onboarding", "completed", onboarding_completed)
    cfg.set_value("network", "server_url", matchmaking_server_url)
    cfg.set_value("account", "token", account_token)
    cfg.set_value("account", "player_id", account_player_id)''', 'save network/account')
# Open the real Chess City screen from the navigation strip.
rep('''        if nav_names[i] == "Шахматный город":
            b.pressed.connect(func(): _show_notice("ШАХМАТНЫЙ ГОРОД: фигуры открываются за XP и покупаются отдельно внутри режима. Все фигуры классической партии доступны сразу. Скины и косметика пока закрыты."))''', '''        if nav_names[i] == "Шахматный город":
            b.pressed.connect(_open_city_screen)''', 'city navigation')
# Add team chat and create city screen once the HTTP client exists.
rep('''    end_turn.pressed.connect(_manual_end_turn)
    _build_preparation_screen()
    _build_online_panel_screen()
    _build_onboarding_screen()''', '''    end_turn.pressed.connect(_manual_end_turn)
    team_chat_label = _add_label(game_panel, "КОМАНДНЫЙ ЧАТ\\nСообщения появятся после подключения.", Vector2(18, 118), Vector2(250, 210), 12, Color(0.90,0.84,0.72))
    team_chat_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    team_chat_input = LineEdit.new()
    team_chat_input.placeholder_text = "Сообщение команде…"
    team_chat_input.position = Vector2(18, 330)
    team_chat_input.size = Vector2(205, 38)
    game_panel.add_child(team_chat_input)
    var chat_send := _ornate_button(game_panel, "ОТПРАВИТЬ", 0.015, 0.53, 0.19, 0.60, 11, "nav")
    chat_send.pressed.connect(_send_team_chat)
    _build_preparation_screen()
    _build_online_panel_screen()
    _build_city_screen()
    _build_onboarding_screen()''', 'chat and city screen build')
# Server URL field in the queue room and game-state polling timer.
rep('''    queue_rating_label = _add_label(frame, "ВАШ РЕЙТИНГ: %d  •  %s" % [competitive_rating, _rating_division()], Vector2(22, 92), Vector2(420, 30), 17, PALE_GOLD)
    queue_timer_label = _add_label(frame, "ВРЕМЯ ПОИСКА  00:00", Vector2(500, 92), Vector2(300, 30), 19, PALE_GOLD)''', '''    queue_rating_label = _add_label(frame, "ВАШ РЕЙТИНГ: %d  •  %s" % [competitive_rating, _rating_division()], Vector2(22, 92), Vector2(420, 30), 17, PALE_GOLD)
    queue_timer_label = _add_label(frame, "ВРЕМЯ ПОИСКА  00:00", Vector2(500, 92), Vector2(300, 30), 19, PALE_GOLD)
    var server_url_label := _add_label(frame, "АДРЕС ОНЛАЙН-СЕРВЕРА", Vector2(22, 132), Vector2(260, 20), 11, PALE_GOLD)
    var server_url_input := LineEdit.new()
    server_url_input.text = matchmaking_server_url
    server_url_input.placeholder_text = "https://ваш-сервер.onrender.com"
    server_url_input.position = Vector2(22, 154)
    server_url_input.size = Vector2(540, 34)
    server_url_input.add_theme_font_size_override("font_size", 13)
    server_url_input.text_changed.connect(func(value: String): matchmaking_server_url = value.strip_edges())
    frame.add_child(server_url_input)''', 'server URL field')
rep('''        online_poll_timer.timeout.connect(_poll_matchmaking_ticket)''', '''        online_poll_timer.timeout.connect(_poll_matchmaking_ticket)
    if game_state_poll_timer == null:
        game_state_poll_timer = Timer.new()
        game_state_poll_timer.wait_time = 1.0
        game_state_poll_timer.one_shot = false
        add_child(game_state_poll_timer)
        game_state_poll_timer.timeout.connect(_poll_online_game_state)''', 'game state timer')
# Replace request sender to attach per-match and account credentials.
start=s.find('func _send_matchmaking_request(')
end=s.find('\nfunc _on_online_http_completed(',start)
if start<0 or end<0: raise SystemExit('Could not replace request sender')
s=s[:start]+'''func _send_matchmaking_request(action: String, path: String, method: int, payload: Dictionary = {}) -> void:
    if online_http == null:
        if queue_status_label: queue_status_label.text = "HTTP-клиент не создан."
        if city_status_label: city_status_label.text = "HTTP-клиент не создан."
        return
    var base_url := matchmaking_server_url.strip_edges().trim_suffix("/")
    if base_url.contains("YOUR-MATCHMAKING-SERVER") or (not base_url.begins_with("https://") and not base_url.begins_with("http://")):
        var message := "Укажи адрес опубликованного сервера (https://...)."
        if city_status_label and (action.begins_with("city_") or action.begins_with("account_")): city_status_label.text = message
        elif queue_status_label: queue_status_label.text = message
        return
    if online_http.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
        return
    online_http_action = action
    var headers := PackedStringArray(["Content-Type: application/json"])
    if not account_token.is_empty(): headers.append("Authorization: Bearer " + account_token)
    if not online_session_token.is_empty(): headers.append("X-Player-Session: " + online_session_token)
    var result := online_http.request(base_url + path, headers, method, JSON.stringify(payload))
    if result != OK:
        if city_status_label and (action.begins_with("city_") or action.begins_with("account_")): city_status_label.text = "Не удалось отправить запрос: " + str(result)
        elif queue_status_label: queue_status_label.text = "Не удалось отправить запрос: " + str(result)
''' + s[end:]
# Replace response handler with queue, gameplay, auth and city dispatch.
start=s.find('func _on_online_http_completed(')
end=s.find('\nfunc _poll_matchmaking_ticket(',start)
if start<0 or end<0: raise SystemExit('Could not replace HTTP response handler')
s=s[:start]+'''func _on_online_http_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
    var payload: Variant = JSON.parse_string(body.get_string_from_utf8())
    var action := online_http_action
    online_http_action = ""
    if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300 or not (payload is Dictionary):
        var error_text := "Ошибка сервера: " + str(response_code)
        if payload is Dictionary and payload.has("error"): error_text += " • " + str(payload["error"])
        if action.begins_with("city_") or action.begins_with("account_"):
            if city_status_label: city_status_label.text = error_text
        else:
            if status_label and action.begins_with("game_"): status_label.text = error_text
            elif queue_status_label: queue_status_label.text = error_text
        if action == "game_state" and game_state_poll_timer: game_state_poll_timer.start()
        return
    match action:
        "queue_start":
            online_ticket = str(payload.get("ticket", ""))
            _update_queue_roster(payload.get("players", []))
            if str(payload.get("status", "")) == "matched":
                online_poll_timer.stop()
                _handle_matchmaking_result(payload)
            elif not online_ticket.is_empty():
                if queue_status_label: queue_status_label.text = "Ищем 16 игроков. Не закрывай экран."
                online_poll_timer.start()
        "queue_poll":
            _update_queue_roster(payload.get("players", []))
            if str(payload.get("status", "")) == "matched":
                online_poll_timer.stop()
                _handle_matchmaking_result(payload)
            elif str(payload.get("status", "")) == "waiting_piece_slot":
                if queue_status_label: queue_status_label.text = "МЕСТО ДЛЯ ФИГУРЫ ЗАНЯТО. Подожди или смени фигуру."
            elif str(payload.get("status", "")) == "cancelled":
                online_poll_timer.stop()
                if queue_status_label: queue_status_label.text = "Поиск отменён."
        "queue_cancel":
            if queue_status_label: queue_status_label.text = "Поиск отменён."
        "queue_change_piece":
            online_ticket = ""
            if online_poll_timer: online_poll_timer.stop()
            online_panel.visible = false
            preparation_panel.visible = true
            _refresh_preparation_ui()
        "game_state", "game_move", "game_pass":
            _apply_server_game_state(payload)
            if game_state_poll_timer and online_match_id: game_state_poll_timer.start()
        "game_chat":
            if status_label: status_label.text = "Сообщение отправлено команде."
        "account_register", "account_login":
            account_token = str(payload.get("token", ""))
            var account: Dictionary = payload.get("account", {})
            account_player_id = str(account.get("playerId", ""))
            if account_token.is_empty() or account_player_id.is_empty():
                if city_status_label: city_status_label.text = "Сервер не вернул профиль."
            else:
                _save_economy()
                if city_status_label: city_status_label.text = "Вход выполнен: " + str(account.get("username", "Игрок"))
                _send_matchmaking_request("city_profile", "/city/profile", HTTPClient.METHOD_GET)
        "city_profile", "city_unlock_piece", "city_purchase_piece", "city_purchase_skin":
            _apply_city_profile(payload.get("city", {}))
            if city_status_label: city_status_label.text = "Прогресс Шахматного города сохранён на сервере."
        _:
            if queue_status_label: queue_status_label.text = "Ответ сервера получен."
''' + s[end:]
# Match result now enters the server-authoritative 16-player game, not a 2-player ENet host.
start=s.find('func _handle_matchmaking_result(')
end=s.find('\nfunc _change_queued_piece(',start)
if start<0 or end<0: raise SystemExit('Could not replace match result handler')
s=s[:start]+'''func _handle_matchmaking_result(payload: Dictionary) -> void:
    _update_queue_roster(payload.get("players", []))
    pending_match_purchase = false
    pending_match_purchase_cost = 0
    pending_match_purchase_piece = ""
    _save_economy()
    local_player_team = str(payload.get("team", "white"))
    opening_player_id = str(payload.get("startingPlayerId", ""))
    online_match_id = str(payload.get("matchId", ""))
    online_session_token = str(payload.get("playerSessionToken", ""))
    if online_match_id.is_empty() or online_session_token.is_empty():
        if queue_status_label: queue_status_label.text = "Состав собран, но сервер не выдал игровой ключ."
        return
    online_active = true
    online_role = "server"
    if queue_cancel_button:
        queue_cancel_button.text = "СОСТАВ СОБРАН"
        queue_cancel_button.disabled = true
    if queue_status_label:
        queue_status_label.text = "СОСТАВ СОБРАН • ВЫ ЗА " + ("БЕЛЫХ" if local_player_team == "white" else "ЧЁРНЫХ")
    last_game_state_update = -1
    _start_game("Классика")
    status_label.text = "Команды собраны. Белые ходят первыми. Сервер синхронизирует партию для всех 16 игроков."
    _send_matchmaking_request("game_state", "/matches/" + online_match_id + "/state", HTTPClient.METHOD_GET)
    if game_state_poll_timer: game_state_poll_timer.start()
''' + s[end:]
# Authenticated players use the account ID; guests retain their local guest identity.
rep('''    online_player_id = _make_online_player_id()
    matchmaking_started_at = Time.get_ticks_msec()''','''    online_player_id = account_player_id if not account_token.is_empty() else _make_online_player_id()
    matchmaking_started_at = Time.get_ticks_msec()''','queue account identity')
# Send moves to authoritative server instead of ENet's old 2-player RPC.
rep('''    if online_active and not multiplayer.is_server():
        rpc_id(1, "_rpc_request_move", from_col, from_row, col, row)
        status_label.text = "Ход отправлен серверу. Ожидаем подтверждения…"
        selected_game_piece = null
        return''','''    if online_active and not online_match_id.is_empty():
        if str(selected_game_piece.get_meta("ownerPlayerId", "")) != online_player_id:
            status_label.text = "Эта фигура принадлежит союзнику. Выбери свою фигуру или передай ход."
            return
        _send_matchmaking_request("game_move", "/matches/" + online_match_id + "/move", HTTPClient.METHOD_POST, {"fromFile": from_col, "fromRow": from_row, "toFile": col, "toRow": row})
        status_label.text = "Ход отправлен. Ждём подтверждения сервера…"
        selected_game_piece = null
        return''','send online move')
# Use server team assignment and only allow active owned pieces.
rep('''    var local_team := _local_team()
    if current_team != local_team:''','''    var local_team := _local_team()
    if online_active and not online_match_id.is_empty() and online_active_player_id != online_player_id:
        status_label.text = "Сейчас ходит другой участник вашей команды. Можно передать очередь."
        return
    if online_active and not online_match_id.is_empty() and bool(_server_viewer_eliminated):
        status_label.text = "Ты выбыл. Доступны наблюдение, командный чат и выход в меню."
        return
    if current_team != local_team:''','active player gate')
rep('''        if target_piece != null and str(target_piece.get_meta("team")) == local_team:
            selected_game_piece = target_piece''','''        if target_piece != null and str(target_piece.get_meta("team")) == local_team and (not online_active or online_match_id.is_empty() or str(target_piece.get_meta("ownerPlayerId", "")) == online_player_id):
            selected_game_piece = target_piece''','piece ownership selection')
# Server-owned state variables and functions.
rep('var city_owned_pieces := ["Пешка"]\n', 'var city_owned_pieces := ["Пешка"]\nvar _server_viewer_eliminated := false\n', 'spectator state')
insert='''
func _poll_online_game_state() -> void:
    if online_match_id.is_empty() or online_session_token.is_empty():
        if game_state_poll_timer: game_state_poll_timer.stop()
        return
    _send_matchmaking_request("game_state", "/matches/" + online_match_id + "/state", HTTPClient.METHOD_GET)

func _apply_server_game_state(data: Dictionary) -> void:
    var stamp := int(data.get("updatedAt", 0))
    current_team = str(data.get("activeTeam", "white"))
    online_active_player_id = str(data.get("activePlayerId", ""))
    var viewer: Dictionary = data.get("viewer", {})
    _server_viewer_eliminated = bool(viewer.get("eliminated", false))
    if stamp != last_game_state_update:
        last_game_state_update = stamp
        for marker in turn_highlight_nodes:
            if is_instance_valid(marker): marker.queue_free()
        turn_highlight_nodes.clear()
        for old_piece in game_piece_nodes:
            if is_instance_valid(old_piece): old_piece.queue_free()
        game_piece_nodes.clear()
        for item in data.get("board", []):
            if not (item is Dictionary): continue
            var team := str(item.get("team", "white"))
            var kind := str(item.get("kind", "P"))
            var file := int(item.get("file", 0))
            var rank := int(item.get("row", 0))
            var tint := Color(0.12,0.095,0.07) if team == "black" else Color(0.88,0.80,0.66)
            _create_game_piece((file - 3.5) * 1.12, (rank - 3.5) * 1.0 - 0.4, kind, tint)
            var node := game_piece_nodes[game_piece_nodes.size() - 1]
            node.set_meta("col", file)
            node.set_meta("row", rank)
            node.set_meta("team", team)
            node.set_meta("kind", kind)
            node.set_meta("ownerPlayerId", str(item.get("ownerPlayerId", "")))
            node.set_meta("has_moved", bool(item.get("hasMoved", false)))
            node.set_meta("piece_id", str(item.get("id", "")))
        _update_turn_highlights()
    var active_name := "Игрок"
    for player in data.get("players", []):
        if str(player.get("playerId", "")) == online_active_player_id:
            active_name = str(player.get("name", "Игрок"))
            active_teammate = int(player.get("slot", 0)) + 1
            break
    _refresh_team_turn_label()
    if data.get("status", "active") == "finished":
        game_over = true
        if game_state_poll_timer: game_state_poll_timer.stop()
        var result := str(data.get("result", ""))
        status_label.text = "ПАРТИЯ ЗАВЕРШЕНА • " + ("ПОБЕДА БЕЛЫХ" if data.get("winnerTeam", "") == "white" else "ПОБЕДА ЧЁРНЫХ" if data.get("winnerTeam", "") == "black" else "НИЧЬЯ") + " • " + result
    elif _server_viewer_eliminated:
        status_label.text = "ТЫ ВЫБЫЛ • РЕЖИМ НАБЛЮДАТЕЛЯ. Можно писать в командный чат."
    elif online_active_player_id == online_player_id:
        status_label.text = "ТВОЯ ОЧЕРЕДЬ • выбери одну из своих фигур и сделай ход."
    else:
        status_label.text = "ХОД: " + ("БЕЛЫЕ" if current_team == "white" else "ЧЁРНЫЕ") + " • " + active_name
    var chat_lines := PackedStringArray()
    for message in data.get("chat", []):
        chat_lines.append(str(message.get("playerName", "Игрок")) + ": " + str(message.get("text", "")))
    if team_chat_label:
        team_chat_label.text = "КОМАНДНЫЙ ЧАТ\\n" + ("\\n".join(chat_lines) if not chat_lines.is_empty() else "Пока нет сообщений.")

func _send_team_chat() -> void:
    if online_match_id.is_empty() or team_chat_input == null: return
    var message := team_chat_input.text.strip_edges()
    if message.is_empty(): return
    _send_matchmaking_request("game_chat", "/matches/" + online_match_id + "/chat", HTTPClient.METHOD_POST, {"message": message})
    team_chat_input.text = ""

func _build_city_screen() -> void:
    city_panel = Control.new()
    city_panel.name = "ChessCityProgression"
    city_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    city_panel.visible = false
    ui.add_child(city_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.008,0.007,0.006,0.97)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    city_panel.add_child(shade)
    var frame := _panel(city_panel,0.035,0.045,0.965,0.955)
    _add_label(frame,"ШАХМАТНЫЙ ГОРОД • ПРОГРЕСС",Vector2(20,12),Vector2(680,40),25,PALE_GOLD)
    var back := _ornate_button(frame,"← НАЗАД",0.82,0.025,0.97,0.12,13,"nav")
    back.pressed.connect(_close_city_screen)
    _add_label(frame,"АККАУНТ",Vector2(22,62),Vector2(200,22),13,PALE_GOLD)
    city_username_input = LineEdit.new()
    city_username_input.placeholder_text = "Логин (3–20 символов)"
    city_username_input.position = Vector2(22,88)
    city_username_input.size = Vector2(230,38)
    frame.add_child(city_username_input)
    city_password_input = LineEdit.new()
    city_password_input.placeholder_text = "Пароль (от 8 символов)"
    city_password_input.secret = true
    city_password_input.position = Vector2(262,88)
    city_password_input.size = Vector2(230,38)
    frame.add_child(city_password_input)
    var login := _ornate_button(frame,"ВОЙТИ",0.405,0.125,0.56,0.205,12,"party")
    login.pressed.connect(_city_login)
    var register := _ornate_button(frame,"РЕГИСТРАЦИЯ",0.57,0.125,0.78,0.205,12,"nav")
    register.pressed.connect(_city_register)
    city_status_label=_add_label(frame,"Войди или зарегистрируй аккаунт, чтобы сохранять XP, фигуры и скины на сервере.",Vector2(22,142),Vector2(750,32),12,PALE_GOLD)
    _add_label(frame,"АДРЕС СЕРВЕРА",Vector2(22,176),Vector2(170,18),10,PALE_GOLD)
    var city_server_url_input := LineEdit.new()
    city_server_url_input.text=matchmaking_server_url
    city_server_url_input.placeholder_text="https://ваш-сервер.onrender.com"
    city_server_url_input.position=Vector2(22,193)
    city_server_url_input.size=Vector2(470,28)
    city_server_url_input.add_theme_font_size_override("font_size",12)
    city_server_url_input.text_changed.connect(func(value: String): matchmaking_server_url=value.strip_edges())
    frame.add_child(city_server_url_input)
    _add_label(frame,"ФИГУРЫ • СНАЧАЛА ОТКРЫТИЕ ЗА XP, ЗАТЕМ ПОСТОЯННАЯ ПОКУПКА ЗА ЗЛОТЫЕ",Vector2(22,228),Vector2(760,24),13,PALE_GOLD)
    var piece_names := ["Конь","Слон","Ладья","Ферзь","Король"]
    for i in range(piece_names.size()):
        var y := 0.37 + float(i)*0.105
        var btn := _ornate_button(frame,piece_names[i].to_upper(),0.025,y,0.47,y+0.09,13,"card")
        btn.pressed.connect(_city_piece_action.bind(piece_names[i]))
        city_piece_buttons.append(btn)
    _add_label(frame,"СКИНЫ • ЗАКРЫТЫ ДО ПОЛУЧЕНИЯ",Vector2(510,228),Vector2(430,24),13,PALE_GOLD)
    var skin_names := ["Мрамор","Обсидиан","Сталь","Аниме"]
    for i in range(skin_names.size()):
        var y := 0.37 + float(i)*0.13
        var btn := _ornate_button(frame,"🔒 " + skin_names[i],0.52,y,0.97,y+0.11,13,"card")
        btn.pressed.connect(_city_skin_action.bind(skin_names[i]))
        city_skin_buttons.append(btn)
    _refresh_city_catalog()

func _open_city_screen() -> void:
    if city_panel == null: _build_city_screen()
    menu_panel.visible = false
    city_panel.visible = true
    if not account_token.is_empty():
        _send_matchmaking_request("city_profile","/city/profile",HTTPClient.METHOD_GET)
    else:
        city_status_label.text="Войди или создай аккаунт. Прогресс будет храниться на сервере, а не только на телефоне."

func _close_city_screen() -> void:
    if city_panel: city_panel.visible=false
    menu_panel.visible=true

func _city_login() -> void:
    _save_economy()
    _send_matchmaking_request("account_login","/accounts/login",HTTPClient.METHOD_POST,{"username":city_username_input.text,"password":city_password_input.text})

func _city_register() -> void:
    _save_economy()
    _send_matchmaking_request("account_register","/accounts/register",HTTPClient.METHOD_POST,{"username":city_username_input.text,"password":city_password_input.text})

func _apply_city_profile(city: Dictionary) -> void:
    city_profile_data=city
    var wallet: Dictionary=city.get("wallet",{})
    balances["zloty"]=int(wallet.get("zloty",balances["zloty"]))
    balances["xp"]=int(wallet.get("xp",balances["xp"]))
    city_unlocked_pieces=city.get("unlockedPieces",["Пешка"])
    city_owned_pieces=city.get("ownedPieces",["Пешка"])
    owned_skins=city.get("ownedSkins",["Дерево"])
    _save_economy()
    _refresh_wallet_labels()
    _refresh_city_catalog()

func _refresh_city_catalog() -> void:
    if city_profile_data.is_empty():
        for button in city_piece_buttons: button.text = "🔒  " + button.text + " • ВОЙДИ В АККАУНТ"
        for button in city_skin_buttons: button.text = "🔒  " + button.text + " • ВОЙДИ В АККАУНТ"
        return
    var piece_catalog: Dictionary=city_profile_data.get("pieceCatalog",{})
    var piece_names := ["Конь","Слон","Ладья","Ферзь","Король"]
    for i in range(min(city_piece_buttons.size(),piece_names.size())):
        var name: String = piece_names[i]
        var item: Dictionary = piece_catalog.get(name,{})
        if bool(item.get("owned",false)):
            city_piece_buttons[i].text="✓  " + name.to_upper() + " • КУПЛЕНО"
        elif bool(item.get("unlocked",false)):
            city_piece_buttons[i].text=name.to_upper()+" • КУПИТЬ ЗА "+str(item.get("zloty",0))+" ЗЛОТЫХ"
        else:
            city_piece_buttons[i].text="🔒  "+name.to_upper()+" • ОТКРЫТЬ "+str(item.get("xp",0))+" XP"
    var skin_catalog: Dictionary=city_profile_data.get("skinCatalog",{})
    var skin_names := ["Мрамор","Обсидиан","Сталь","Аниме"]
    for i in range(min(city_skin_buttons.size(),skin_names.size())):
        var name: String = skin_names[i]
        var item: Dictionary = skin_catalog.get(name,{})
        city_skin_buttons[i].text=("✓  " if bool(item.get("owned",false)) else "🔒  ")+name.to_upper()+(" • ПОЛУЧЕН" if bool(item.get("owned",false)) else " • "+str(item.get("xp",0))+" XP + "+str(item.get("zloty",0))+" ЗЛОТЫХ")

func _city_piece_action(piece: String) -> void:
    if account_token.is_empty():
        if city_status_label: city_status_label.text="Сначала войди в аккаунт."
        return
    var item: Dictionary=city_profile_data.get("pieceCatalog",{}).get(piece,{})
    if not bool(item.get("unlocked",false)):
        _send_matchmaking_request("city_unlock_piece","/city/unlock-piece",HTTPClient.METHOD_POST,{"piece":piece})
    elif not bool(item.get("owned",false)):
        _send_matchmaking_request("city_purchase_piece","/city/purchase-piece",HTTPClient.METHOD_POST,{"piece":piece})

func _city_skin_action(skin: String) -> void:
    if account_token.is_empty():
        if city_status_label: city_status_label.text="Сначала войди в аккаунт."
        return
    var item: Dictionary=city_profile_data.get("skinCatalog",{}).get(skin,{})
    if not bool(item.get("owned",false)):
        _send_matchmaking_request("city_purchase_skin","/city/purchase-skin",HTTPClient.METHOD_POST,{"skin":skin})

'''
# Insert city/gameplay helpers before _change_queued_piece.
marker='func _change_queued_piece() -> void:'
if marker not in s: raise SystemExit('Missing insertion marker for gameplay/city helpers')
s=s.replace(marker,insert+'\n'+marker,1)
# Server match state is authoritative for team assignment and spectator status.
rep('''func _local_team() -> String:
    if not online_active:
        return current_team
    return "white" if multiplayer.is_server() else "black"''','''func _local_team() -> String:
    if not online_active:
        return current_team
    if not online_match_id.is_empty():
        return local_player_team
    return "white" if multiplayer.is_server() else "black"''','local team')
# Online pass now rotates through teammates on the server.
rep('''    if online_active:
        status_label.text = "В сетевой классике каждый игрок управляет своей стороной."
        return''','''    if online_active and not online_match_id.is_empty():
        if online_active_player_id == online_player_id and not _server_viewer_eliminated:
            _send_matchmaking_request("game_pass", "/matches/" + online_match_id + "/pass", HTTPClient.METHOD_POST)
        else:
            status_label.text = "Передать ход может только активный игрок."
        return
    if online_active:
        status_label.text = "Старая сетевая сессия недоступна."
        return''','online pass')
# Stop online state polling and clear credentials when leaving a match.
rep('''func _stop_online(return_peer: bool = true) -> void:
    if online_poll_timer:
        online_poll_timer.stop()
    online_ticket = ""''','''func _stop_online(return_peer: bool = true) -> void:
    if online_poll_timer: online_poll_timer.stop()
    if game_state_poll_timer: game_state_poll_timer.stop()
    online_ticket = ""
    online_match_id = ""
    online_session_token = ""
    online_active_player_id = ""
    _server_viewer_eliminated = false''','stop online state')
# Save server URL edits on every queue attempt and attach account identity to the matchmaking ticket.
rep('''    _send_matchmaking_request("queue_start", "/matchmaking/queue", HTTPClient.METHOD_POST, {
        "playerId": online_player_id,''','''    _save_economy()
    _send_matchmaking_request("queue_start", "/matchmaking/queue", HTTPClient.METHOD_POST, {
        "playerId": online_player_id,''','queue save server')
# Ensure a user can only move their owned piece during their exact server turn.
rep('''    if online_active and not online_match_id.is_empty() and online_active_player_id != online_player_id:
        status_label.text = "Сейчас ходит другой участник вашей команды. Можно передать очередь."
        return''','''    if online_active and not online_match_id.is_empty() and online_active_player_id != online_player_id:
        status_label.text = "Сейчас ходит другой участник вашей команды. Можно передать очередь."
        return''','confirm active player check')

p.write_text(s,encoding='utf-8')
print('CHECKMATE v36 online gameplay + Chess City client patch applied')
