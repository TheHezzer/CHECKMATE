extends Node3D

const GOLD := Color(0.72, 0.55, 0.30)
const PALE_GOLD := Color(0.92, 0.82, 0.63)
const DARK := Color(0.025, 0.020, 0.016, 0.94)
const PIECES := ["Пешка", "Ладья", "Конь", "Слон", "Ферзь", "Король"]
var UI_FONT: Font = ThemeDB.fallback_font
var UI_LABEL_FONT: Font = ThemeDB.fallback_font

var camera: Camera3D
var world_root: Node3D
var ui: CanvasLayer
var menu_panel: Control
var onboarding_panel: Control
var onboarding_title: Label
var onboarding_body: Label
var onboarding_progress: Label
var onboarding_next_button: Button
var onboarding_step := 0
var onboarding_completed := false
var game_panel: Control
var preview_container: SubViewportContainer
var preview_pawn: Node3D
var preview_camera_pivot: Node3D
var preview_camera: Camera3D
var preview_camera_pitch := 0.0
var selected_piece := 0
var selected_mode := "Классика"
var dragging_preview := false
var last_pointer_x := 0.0
var last_pointer_y := 0.0
var status_label: Label
var preparation_panel: Control
var mode_selection_panel: Control
var mode_choice_buttons: Array[Button] = []
var mode_description_label: Label
var game_piece_nodes: Array[Node3D] = []
var turn_highlight_nodes: Array[MeshInstance3D] = []
var selected_game_piece: Node3D
var current_team := "white"
var active_teammate := 1
var game_over := false
var last_move: Dictionary = {}
var halfmove_clock := 0
var position_counts: Dictionary = {}
var game_over_panel: Control
var game_over_title: Label
var game_over_detail: Label
var online_active := false
var online_game_started := false
var online_role := "offline"
var online_peer: ENetMultiplayerPeer
var online_panel: Control
var online_status_label: Label
var online_port := 24567
const DEFAULT_MATCHMAKING_RATING := 1000
var matchmaking_server_url := "https://YOUR-MATCHMAKING-SERVER"
const CLASSIC_TEAM_SIZE := 8
var online_http: HTTPRequest
var online_poll_timer: Timer
var online_http_action := ""
var online_ticket := ""
var matchmaking_info_label: Label
var matchmaking_started_at := 0
var queue_timer_label: Label
var queue_status_label: Label
var queue_rating_label: Label
var queue_white_roster_label: Label
var queue_black_roster_label: Label
var queue_cancel_button: Button
var queue_last_roster: Array = []
var online_player_id := ""
var online_match_id := ""
var online_session_token := ""
var online_active_player_id := ""
var game_state_poll_timer: Timer
var last_game_state_update := -1
var team_chat_label: Label
var team_chat_input: LineEdit
var account_token := ""
var account_player_id := ""
var account_username := ""
var account_panel: Control
var account_username_input: LineEdit
var account_password_input: LineEdit
var account_status_label: Label
var profile_name_label: Label
var profile_state_label: Label
var city_panel: Control
var city_username_input: LineEdit
var city_password_input: LineEdit
var city_status_label: Label
var city_piece_buttons: Array[Button] = []
var city_skin_buttons: Array[Button] = []
var city_profile_data: Dictionary = {}
var city_owned_pieces := ["Пешка"]
var _server_viewer_eliminated := false
var competitive_rating := 1000
var persistent_player_id := ""
var local_player_team := "white"
var opening_player_id := ""
var team_turn_label: Label
var first_move_vote_panel: Control
var first_move_vote_label: Label
var first_move_vote_done := false
var first_move_votes := {"white": 0, "black": 0}
var team_next_player := {"white": 1, "black": 1}
var first_move_voted := false
var queue_change_piece_button: Button
var prep_status: Label
var pass_turn_button: Button
var end_turn_button: Button
var vote_approve_button: Button
var vote_reject_button: Button
var match_result_panel: Control
var match_result_title: Label
var match_result_subtitle: Label
var match_result_stats: Label
var match_result_rewards: Label
var match_result_votes: Label
var match_history_panel: Control
var match_history_text: Label
var history_return_to_menu := false
var prep_piece_buttons: Array[Button] = []
var main_piece_buttons: Array[Button] = []
var selected_prep_piece := 2
var selected_match_piece := "Конь"
var pending_match_purchase := false
var pending_match_purchase_cost := 0
var pending_match_purchase_piece := ""
var developer_mode := false
var developer_login_panel: Control
var developer_user_input: LineEdit
var developer_pass_input: LineEdit
var developer_test_menu: Control
var developer_test_status: Label
var bot_match_timer: Timer
var bot_turn_timer: Timer
var local_bot_roster: Array = []
var local_user_team := "white"
var local_user_slot := 1
var startup_panel: Control
var startup_title: Label
var startup_detail: Label
var startup_progress: ProgressBar
var startup_timer: Timer
var startup_stage := 0
var balances := {"zloty": 12750, "xp": 850, "chessmatites": 620}
var unlocked_pieces := ["Пешка", "Ладья", "Конь", "Слон", "Ферзь", "Король"]
var city_unlocked_pieces := ["Пешка"]
var owned_skins := ["Дерево"]
var match_piece_costs := {"Пешка": 10, "Конь": 30, "Слон": 35, "Ладья": 40, "Ферзь": 55, "Король": 45}
var piece_unlock_xp := {"Пешка": 0, "Конь": 300, "Слон": 400, "Ладья": 500, "Ферзь": 1200, "Король": 0}

func _ready() -> void:
    var readable_font := SystemFont.new()
    readable_font.font_names = PackedStringArray(["Roboto", "Arial", "DejaVu Sans", "Liberation Sans"])
    readable_font.font_weight = 700
    UI_FONT = readable_font
    UI_LABEL_FONT = readable_font
    _load_economy()
    _build_world()
    _build_ui()
    _build_developer_login()
    _build_account_panel()
    _build_developer_test_menu()
    _build_startup_sequence()

func _build_world() -> void:
    world_root = Node3D.new()
    world_root.name = "ChessGameWorld"
    add_child(world_root)
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.035, 0.03, 0.025)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.58, 0.52, 0.43)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env_node.environment = env
    world_root.add_child(env_node)
    camera = Camera3D.new()
    camera.position = Vector3(0, 9.5, 13.0)
    camera.fov = 48
    world_root.add_child(camera)
    camera.look_at(Vector3(0, 1.0, 0), Vector3.UP)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -28, 0)
    sun.light_color = Color(1.0, 0.84, 0.66)
    sun.light_energy = 1.2
    sun.shadow_enabled = true
    world_root.add_child(sun)
    _add_game_box(Vector3(0, -0.45, 0), Vector3(24, 0.8, 24), Color(0.12, 0.105, 0.09))
    _add_game_box(Vector3(0, 5.5, -8.5), Vector3(24, 12, 0.8), Color(0.16, 0.145, 0.125))
    for x in [-9.0, -5.8, 5.8, 9.0]:
        for z in [-6.8, 1.0]:
            _add_game_cylinder(Vector3(x, 3.0, z), 0.62, 6.0, Color(0.25, 0.23, 0.20), 20)
    _add_game_box(Vector3(0, 0.05, -0.4), Vector3(10.15, 0.5, 9.15), Color(0.20, 0.13, 0.075))
    _add_game_box(Vector3(0, 0.31, -0.4), Vector3(9.95, 0.08, 9.0), GOLD)
    _add_game_box(Vector3(0, 0.43, -0.4), Vector3(9.55, 0.22, 8.6), Color(0.075, 0.055, 0.04))
    for row in range(8):
        for col in range(8):
            var square_color := Color(0.72, 0.60, 0.43) if (row + col) % 2 == 0 else Color(0.13, 0.095, 0.065)
            _add_game_box(Vector3((col - 3.5) * 1.12, 0.56, (row - 3.5) * 1.0 - 0.4), Vector3(1.10, 0.055, 0.98), square_color)
    _build_game_pieces()
    world_root.visible = false

func _build_game_pieces() -> void:
    game_piece_nodes.clear()
    var back_rank := ["R", "N", "B", "Q", "K", "B", "N", "R"]
    for col in range(8):
        var x := (col - 3.5) * 1.12
        _create_game_piece(x, (0 - 3.5) * 1.0 - 0.4, back_rank[col], Color(0.12, 0.095, 0.07))
        _create_game_piece(x, (1 - 3.5) * 1.0 - 0.4, "P", Color(0.12, 0.095, 0.07))
        _create_game_piece(x, (6 - 3.5) * 1.0 - 0.4, "P", Color(0.88, 0.80, 0.66))
        _create_game_piece(x, (7 - 3.5) * 1.0 - 0.4, back_rank[col], Color(0.88, 0.80, 0.66))

func _create_game_piece(x: float, z: float, kind: String, color: Color) -> void:
    var root := Node3D.new()
    root.position = Vector3(x, 0.64, z)
    root.scale = Vector3(1.12, 1.12, 1.12)
    var col: int = roundi(x / 1.12 + 3.5)
    var row: int = roundi((z + 0.4) / 1.0 + 3.5)
    root.set_meta("col", col)
    root.set_meta("row", row)
    root.set_meta("kind", kind)
    root.set_meta("has_moved", false)
    root.set_meta("team", "black" if color.r < 0.5 else "white")
    world_root.add_child(root)
    game_piece_nodes.append(root)
    var mat := _material(color, 0.34, 0.15)
    _add_piece_cylinder(root, 0.27, 0.12, 0.0, mat)
    _add_piece_cylinder(root, 0.18, 0.48, 0.18, mat)
    _add_piece_cylinder(root, 0.24, 0.10, 0.43, mat)
    match kind:
        "P": _add_piece_sphere(root, 0.17, 0.68, mat)
        "R":
            _add_piece_cylinder(root, 0.23, 0.28, 0.61, mat)
            _add_piece_cylinder(root, 0.28, 0.12, 0.79, mat)
        "N":
            _add_piece_sphere(root, 0.22, 0.70, mat)
            _add_piece_box(root, Vector3(0, 0.82, 0.04), Vector3(0.17, 0.32, 0.25), mat)
        "B":
            _add_piece_sphere(root, 0.18, 0.72, mat)
            _add_piece_cylinder(root, 0.06, 0.24, 0.91, mat)
        "Q":
            _add_piece_sphere(root, 0.22, 0.78, mat)
            _add_piece_cylinder(root, 0.27, 0.10, 0.98, mat)
        "K":
            _add_piece_sphere(root, 0.22, 0.78, mat)
            _add_piece_box(root, Vector3(0, 1.03, 0), Vector3(0.10, 0.35, 0.10), mat)

func _add_game_box(pos: Vector3, size: Vector3, color: Color) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position = pos
    node.material_override = _material(color, 0.78)
    world_root.add_child(node)

func _add_game_cylinder(pos: Vector3, radius: float, height: float, color: Color, sides: int) -> void:
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius * 1.08
    mesh.height = height
    mesh.radial_segments = sides
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position = pos
    node.material_override = _material(color, 0.72)
    world_root.add_child(node)

func _add_piece_cylinder(parent: Node3D, radius: float, height: float, y: float, mat: Material) -> void:
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius * 0.78
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = 32
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position.y = y + height * 0.5
    node.material_override = mat
    parent.add_child(node)

func _add_piece_sphere(parent: Node3D, radius: float, y: float, mat: Material) -> void:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 32
    mesh.rings = 16
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position.y = y
    node.material_override = mat
    parent.add_child(node)

func _add_piece_box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position = pos
    node.material_override = mat
    parent.add_child(node)

func _material(color: Color, roughness: float = 0.6, metallic: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    m.metallic = metallic
    return m

func _build_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    menu_panel = Control.new()
    menu_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(menu_panel)

    _build_menu_3d_environment()

    var shade := ColorRect.new()
    shade.color = Color(0.008, 0.006, 0.005, 0.12)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_panel.add_child(shade)

    # Player portrait and progress, matching the reference layout.
    var profile := _panel(menu_panel, 0.015, 0.025, 0.225, 0.155)
    var portrait := TextureRect.new()
    portrait.texture = load("res://assets/profile_portrait.png")
    portrait.position = Vector2(7, 5)
    portrait.size = Vector2(78, 92)
    portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
    portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
    profile.add_child(portrait)
    var profile_hit := Button.new()
    profile_hit.flat = true
    profile_hit.position = Vector2(3, 3)
    profile_hit.size = Vector2(245, 94)
    profile_hit.modulate = Color(1,1,1,0.01)
    profile_hit.pressed.connect(_open_account_panel)
    profile.add_child(profile_hit)
    profile_name_label = _add_label(profile, "ГОСТЬ", Vector2(92, 8), Vector2(180, 28), 21, PALE_GOLD)
    profile_state_label = _add_label(profile, "НАЖМИ НА АВАТАР • ВОЙТИ", Vector2(92, 38), Vector2(180, 23), 14, Color(0.82, 0.82, 0.82))
    _add_label(profile, "ПРОГРЕСС НА ЭТОМ УСТРОЙСТВЕ", Vector2(92, 61), Vector2(185, 18), 11, Color(0.76, 0.72, 0.66))
    var xp := ProgressBar.new()
    xp.position = Vector2(92, 65)
    xp.size = Vector2(150, 10)
    xp.max_value = 1000
    xp.value = int(balances["xp"])
    xp.show_percentage = false
    profile.add_child(xp)
    _add_label(profile, "850 / 2000", Vector2(92, 77), Vector2(145, 18), 10, PALE_GOLD)

    # Separate, button-like resource counters: gambits, premium currency and XP.
    var gambits := _ornate_button(menu_panel, "◈  ЗЛОТЫЕ\n%d" % int(balances["zloty"]), 0.275, 0.035, 0.425, 0.125, 17, "nav")
    gambits.name = "ZlotyCounter"
    gambits.pressed.connect(_show_notice.bind("Злотые — игровая валюта. Фигуры покупаются перед каждой партией."))
    var chessmatites := _ornate_button(menu_panel, "◆  ШАХМАТИТЫ\n%d   +" % int(balances["chessmatites"]), 0.432, 0.035, 0.575, 0.125, 17, "nav")
    chessmatites.name = "ChessmatitesCounter"
    chessmatites.pressed.connect(_show_notice.bind("Шахматиты — премиальная валюта"))
    var experience := _ornate_button(menu_panel, "★  XP\n%d" % int(balances["xp"]), 0.582, 0.035, 0.722, 0.125, 17, "nav")
    experience.name = "XPCounter"
    experience.pressed.connect(_show_notice.bind("XP — расходуемый ресурс для открытия фигур и покупки постоянных скинов."))

    # Top-right quick access buttons.
    var quick_names := ["История", "Рейтинг", "Кланы", "Настройки"]
    var quick_icons := ["◷", "🏆", "♟", "⚙"]
    for i in range(quick_names.size()):
        var x := 0.775 + float(i) * 0.052
        var q := _ornate_button(menu_panel, quick_icons[i] + "\n" + quick_names[i], x, 0.018, x + 0.050, 0.115, 12, "nav")
        if quick_names[i] == "Рейтинг":
            q.text = quick_icons[i] + "\nРейтинг\n%d • %s" % [competitive_rating, _rating_division()]
            q.pressed.connect(_show_rating_details)
        elif quick_names[i] == "История":
            q.pressed.connect(_open_match_history.bind(true))
        else:
            q.pressed.connect(_show_notice.bind(quick_names[i] + " — раздел в разработке"))

    # Left-side feature panels from the reference screen.
    var tasks := _panel(menu_panel, 0.015, 0.215, 0.185, 0.365)
    _add_label(tasks, "♜", Vector2(12, 12), Vector2(48, 54), 34, PALE_GOLD)
    _add_label(tasks, "Ежедневные\nзадачи", Vector2(67, 12), Vector2(175, 42), 19, PALE_GOLD)
    _add_label(tasks, "Награды за победы и испытания", Vector2(67, 57), Vector2(175, 32), 12, Color(0.88, 0.82, 0.73))
    var pass_panel := _panel(menu_panel, 0.015, 0.385, 0.185, 0.535)
    _add_label(pass_panel, "♜", Vector2(12, 12), Vector2(48, 54), 34, PALE_GOLD)
    _add_label(pass_panel, "Боевой\nпропуск", Vector2(67, 12), Vector2(175, 42), 19, PALE_GOLD)
    _add_label(pass_panel, "Уровень 12  •  Награды сезона", Vector2(67, 57), Vector2(175, 32), 12, Color(0.88, 0.82, 0.73))
    var event_panel := _panel(menu_panel, 0.015, 0.555, 0.185, 0.705)
    _add_label(event_panel, "⚜", Vector2(12, 12), Vector2(48, 54), 34, PALE_GOLD)
    _add_label(event_panel, "Событие\n«Осенний турнир»", Vector2(67, 10), Vector2(180, 44), 18, PALE_GOLD)
    _add_label(event_panel, "До конца: 7 д. 14 ч.", Vector2(67, 59), Vector2(170, 24), 12, Color(0.88, 0.82, 0.73))

    # Featured collectible card on the right.
    var featured := TextureRect.new()
    featured.texture = load("res://assets/featured_king.png")
    featured.anchor_left = 0.835
    featured.anchor_top = 0.205
    featured.anchor_right = 0.985
    featured.anchor_bottom = 0.525
    featured.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    featured.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
    featured.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_panel.add_child(featured)
    var featured_hit := Button.new()
    featured_hit.anchor_left = 0.835
    featured_hit.anchor_top = 0.205
    featured_hit.anchor_right = 0.985
    featured_hit.anchor_bottom = 0.525
    featured_hit.flat = true
    featured_hit.focus_mode = Control.FOCUS_NONE
    featured_hit.modulate = Color(1, 1, 1, 0.01)
    featured_hit.pressed.connect(_show_notice.bind("Королевский скин — скоро в магазине"))
    menu_panel.add_child(featured_hit)

    # Rotatable 3D collectible preview: pawn owned, other chess pieces locked.
    _build_piece_preview()
    var left_arrow := _ornate_button(menu_panel, "❮", 0.335, 0.445, 0.405, 0.565, 38, "arrow")
    left_arrow.pressed.connect(func(): _change_piece(-1))
    var right_arrow := _ornate_button(menu_panel, "❯", 0.595, 0.445, 0.665, 0.565, 38, "arrow")
    right_arrow.pressed.connect(func(): _change_piece(1))

    var piece_name := _add_label(menu_panel, "ПЕШКА  •  ДОСТУПНА", Vector2.ZERO, Vector2(360, 30), 17, PALE_GOLD)
    piece_name.name = "PieceName"
    piece_name.anchor_left = 0.5
    piece_name.anchor_right = 0.5
    piece_name.anchor_top = 0.665
    piece_name.anchor_bottom = 0.665
    piece_name.offset_left = -180
    piece_name.offset_right = 180
    piece_name.offset_top = 0
    piece_name.offset_bottom = 30
    piece_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var lock_hint := _add_label(menu_panel, "ПРОВЕДИ ВЛЕВО ИЛИ ВПРАВО, ЧТОБЫ СМЕНИТЬ ФИГУРУ", Vector2.ZERO, Vector2(500, 22), 10, Color(0.82, 0.75, 0.63))
    lock_hint.name = "PieceLockHint"
    lock_hint.anchor_left = 0.5
    lock_hint.anchor_right = 0.5
    lock_hint.anchor_top = 0.700
    lock_hint.anchor_bottom = 0.700
    lock_hint.offset_left = -250
    lock_hint.offset_right = 250
    lock_hint.offset_top = 0
    lock_hint.offset_bottom = 22
    lock_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    piece_name.anchor_top = 0.615
    piece_name.anchor_bottom = 0.615
    piece_name.offset_top = 0
    piece_name.offset_bottom = 28
    lock_hint.visible = false
    # Minimal silhouettes without cards, square backgrounds or bright fills.
    var silhouette_row := Control.new()
    silhouette_row.name = "MainPieceSilhouettes"
    silhouette_row.anchor_left = 0.295
    silhouette_row.anchor_right = 0.705
    silhouette_row.anchor_top = 0.665
    silhouette_row.anchor_bottom = 0.755
    menu_panel.add_child(silhouette_row)
    for i in range(PIECES.size()):
        var piece_title: String = PIECES[i]
        var b := Button.new()
        b.flat = true
        b.focus_mode = Control.FOCUS_NONE
        b.anchor_left = float(i) / 6.0
        b.anchor_right = float(i + 1) / 6.0
        b.anchor_top = 0.0
        b.anchor_bottom = 1.0
        b.text = ["♟", "♜", "♞", "♝", "♛", "♚"][i]
        b.add_theme_font_size_override("font_size", 58)
        b.add_theme_color_override("font_color", Color(0.68, 0.67, 0.63))
        b.add_theme_color_override("font_hover_color", Color(0.84, 0.82, 0.76))
        b.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("hover", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
        b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
        b.tooltip_text = piece_title + (" • доступна" if unlocked_pieces.has(piece_title) else " • закрыта")
        b.pressed.connect(_select_main_piece.bind(i))
        silhouette_row.add_child(b)
        main_piece_buttons.append(b)
    _refresh_main_piece_shelf()

    # Large ornamental "PARTY" plaque.
    var party := _ornate_button(menu_panel, "⚔   П А Р Т И Я", 0.365, 0.145, 0.635, 0.255, 23, "party")
    party.pressed.connect(_open_mode_selection)

    # Four large mode cards, each using the same ornate frame as the reference.
    var modes := ["Классика", "Командное голосование", "Несколько фигур"]
    var subtitles := ["Командная партия", "Голосование за ход", "Несколько фигур на игрока"]
    var symbols := ["♞", "♟", "♛"]
    for i in range(modes.size()):
        var x := 0.225 + float(i) * 0.190
        var b := _ornate_button(menu_panel, symbols[i] + "\n" + modes[i] + "\n" + subtitles[i], x, 0.755, x + 0.180, 0.895, 19, "card")
        b.pressed.connect(_on_mode_pressed.bind(modes[i]))

    # Bottom navigation: six engraved sections in one continuous row.
    var nav_names := ["Магазин", "Рейтинг", "Кланы", "Шахматный город", "Коллекция", "Пропуск"]
    var nav_icons := ["♜", "▥", "⚑", "♜", "♛", "▣"]
    for i in range(nav_names.size()):
        var x := 0.012 + float(i) * 0.163
        var b := _ornate_button(menu_panel, nav_icons[i] + "\n" + nav_names[i], x, 0.905, x + 0.158, 0.998, 16, "nav")
        if nav_names[i] == "Шахматный город":
            b.pressed.connect(_open_city_screen)
        elif nav_names[i] == "Рейтинг":
            b.text = nav_icons[i] + "\nРейтинг\n%d" % competitive_rating
            b.pressed.connect(_show_rating_details)
        else:
            b.disabled = true
            b.text = "🔒\n" + nav_names[i] + "\nСКОРО"

    # Gameplay screen and return button.
    game_panel = Control.new()
    game_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    game_panel.visible = false
    ui.add_child(game_panel)
    var header := _panel(game_panel, 0.02, 0.025, 0.43, 0.11)
    _add_label(header, "ПАРТИЯ  •  " + selected_mode, Vector2(12, 8), Vector2(480, 28), 18, PALE_GOLD)
    var back := _ornate_button(game_panel, "←  В МЕНЮ", 0.82, 0.025, 0.98, 0.11, 15, "card")
    back.pressed.connect(_return_to_menu)
    status_label = _add_label(game_panel, "Выберите фигуру на доске", Vector2.ZERO, Vector2(500, 34), 16, PALE_GOLD)
    status_label.anchor_left = 0.5
    status_label.anchor_right = 0.5
    status_label.anchor_top = 1.0
    status_label.anchor_bottom = 1.0
    status_label.offset_left = -250
    status_label.offset_right = 250
    status_label.offset_top = -48
    status_label.offset_bottom = -8
    team_turn_label = _add_label(game_panel, "ХОД: БЕЛЫЕ • ИГРОК 1/8", Vector2.ZERO, Vector2(420, 30), 16, PALE_GOLD)
    team_turn_label.anchor_left = 0.5
    team_turn_label.anchor_right = 0.5
    team_turn_label.anchor_top = 0.12
    team_turn_label.anchor_bottom = 0.12
    team_turn_label.offset_left = -210
    team_turn_label.offset_right = 210
    team_turn_label.offset_top = 0
    team_turn_label.offset_bottom = 30
    pass_turn_button = _ornate_button(game_panel, "ПЕРЕДАТЬ ХОД СОЮЗНИКУ", 0.27, 0.88, 0.49, 0.98, 13, "nav")
    pass_turn_button.pressed.connect(_pass_to_teammate)
    end_turn_button = _ornate_button(game_panel, "ЗАВЕРШИТЬ ХОД", 0.51, 0.88, 0.73, 0.98, 13, "party")
    end_turn_button.pressed.connect(_manual_end_turn)
    vote_approve_button = _ornate_button(game_panel, "ЗА  •  ПОДДЕРЖАТЬ", 0.27, 0.88, 0.49, 0.98, 13, "party")
    vote_approve_button.visible = false
    vote_approve_button.pressed.connect(_cast_team_vote.bind("approve"))
    vote_reject_button = _ornate_button(game_panel, "ПРОТИВ  •  ОТКЛОНИТЬ", 0.51, 0.88, 0.73, 0.98, 13, "nav")
    vote_reject_button.visible = false
    vote_reject_button.pressed.connect(_cast_team_vote.bind("reject"))
    team_chat_label = _add_label(game_panel, "КОМАНДНЫЙ ЧАТ\nСообщения появятся после подключения.", Vector2(18, 118), Vector2(250, 210), 12, Color(0.90,0.84,0.72))
    team_chat_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    team_chat_input = LineEdit.new()
    team_chat_input.placeholder_text = "Сообщение команде…"
    team_chat_input.position = Vector2(18, 330)
    team_chat_input.size = Vector2(205, 38)
    game_panel.add_child(team_chat_input)
    var chat_send := _ornate_button(game_panel, "ОТПРАВИТЬ", 0.015, 0.53, 0.19, 0.60, 11, "nav")
    chat_send.pressed.connect(_send_team_chat)
    _build_preparation_screen()
    _build_online_panel_screen()
    _build_city_screen()
    _build_onboarding_screen()
    _build_match_result_screen()
    _build_match_history_screen()
    if not onboarding_completed:
        _open_onboarding()

func _build_match_result_screen() -> void:
    match_result_panel = Control.new()
    match_result_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    match_result_panel.visible = false
    ui.add_child(match_result_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.008, 0.006, 0.005, 0.94)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    match_result_panel.add_child(shade)
    var frame := _panel(match_result_panel, 0.07, 0.055, 0.93, 0.945)
    match_result_title = _add_label(frame, "ПОБЕДА", Vector2(24, 14), Vector2(700, 52), 30, PALE_GOLD)
    match_result_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    match_result_subtitle = _add_label(frame, "КЛАССИЧЕСКАЯ КОМАНДНАЯ ПАРТИЯ", Vector2(24, 66), Vector2(700, 28), 14, Color(0.82, 0.75, 0.63))
    match_result_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    var stats_card := _panel(frame, 0.025, 0.19, 0.485, 0.69)
    _add_label(stats_card, "ЛИЧНАЯ СТАТИСТИКА", Vector2(16, 12), Vector2(360, 32), 18, PALE_GOLD)
    match_result_stats = _add_label(stats_card, "Ходы: 0", Vector2(18, 54), Vector2(360, 220), 14, Color(0.88, 0.83, 0.74))
    var rewards_card := _panel(frame, 0.515, 0.19, 0.975, 0.69)
    _add_label(rewards_card, "НАГРАДА ЗА ПАРТИЮ", Vector2(16, 12), Vector2(360, 32), 18, PALE_GOLD)
    match_result_rewards = _add_label(rewards_card, "Злотые: +0", Vector2(18, 54), Vector2(360, 220), 14, Color(0.88, 0.83, 0.74))
    var voting_card := _panel(frame, 0.025, 0.715, 0.975, 0.855)
    _add_label(voting_card, "КОМАНДНОЕ ГОЛОСОВАНИЕ", Vector2(16, 8), Vector2(360, 28), 16, PALE_GOLD)
    match_result_votes = _add_label(voting_card, "Голосов: 0 • Бонус: не получен", Vector2(18, 36), Vector2(680, 46), 12, Color(0.88, 0.83, 0.74))
    var replay := _ornate_button(frame, "ЕЩЁ ПАРТИЮ", 0.035, 0.88, 0.32, 0.98, 13, "party")
    replay.pressed.connect(_play_again_from_results)
    var history := _ornate_button(frame, "ИСТОРИЯ", 0.36, 0.88, 0.64, 0.98, 13, "nav")
    history.pressed.connect(_open_match_history.bind(false))
    var back := _ornate_button(frame, "В МЕНЮ", 0.68, 0.88, 0.965, 0.98, 13, "card")
    back.pressed.connect(_return_to_menu)

func _build_match_history_screen() -> void:
    match_history_panel = Control.new()
    match_history_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    match_history_panel.visible = false
    ui.add_child(match_history_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.008, 0.006, 0.005, 0.96)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    match_history_panel.add_child(shade)
    var frame := _panel(match_history_panel, 0.07, 0.06, 0.93, 0.94)
    _add_label(frame, "ИСТОРИЯ ПАРТИЙ", Vector2(24, 16), Vector2(620, 44), 27, PALE_GOLD)
    _add_label(frame, "ПОСЛЕДНИЕ 10 ЗАВЕРШЁННЫХ МАТЧЕЙ НА ЭТОМ УСТРОЙСТВЕ", Vector2(26, 62), Vector2(650, 26), 12, Color(0.82, 0.75, 0.63))
    match_history_text = _add_label(frame, "Здесь пока нет завершённых партий.", Vector2(28, 108), Vector2(700, 360), 15, Color(0.90, 0.85, 0.76))
    match_history_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    var close := _ornate_button(frame, "НАЗАД", 0.36, 0.88, 0.64, 0.98, 15, "party")
    close.pressed.connect(_close_match_history)

func _open_match_history(from_menu: bool = false) -> void:
    history_return_to_menu = from_menu
    if menu_panel:
        menu_panel.visible = false
    if match_result_panel:
        match_result_panel.visible = false
    match_history_panel.visible = true
    _refresh_match_history()

func _close_match_history() -> void:
    match_history_panel.visible = false
    if history_return_to_menu:
        menu_panel.visible = true
    elif match_result_panel:
        match_result_panel.visible = true

func _refresh_match_history() -> void:
    var cfg := ConfigFile.new()
    var entries: Array = []
    if cfg.load("user://checkmate_match_history.cfg") == OK:
        entries = cfg.get_value("history", "matches", [])
    if entries.is_empty():
        match_history_text.text = "Здесь пока нет завершённых партий.\nСыграй первую партию — её результат появится в этой истории."
        return
    var lines: Array[String] = []
    for i in range(entries.size()):
        var item: Dictionary = entries[i]
        var number := i + 1
        lines.append("%02d. %s  •  %s  •  %s\n     +%d злотых  |  +%d XP  |  %s" % [number, str(item.get("date", "")), str(item.get("mode", "Классика")), str(item.get("result", "ЗАВЕРШЕНА")), int(item.get("zloty", 0)), int(item.get("xp", 0)), str(item.get("finish", ""))])
    match_history_text.text = "\n\n".join(lines)

func _record_match_history(data: Dictionary, headline: String, reward: Dictionary) -> void:
    var cfg := ConfigFile.new()
    var entries: Array = []
    if cfg.load("user://checkmate_match_history.cfg") == OK:
        entries = cfg.get_value("history", "matches", [])
    var finish := str(data.get("result", "finished"))
    var item := {
        "date": Time.get_datetime_string_from_system(false, true),
        "mode": selected_mode,
        "result": headline,
        "finish": finish,
        "zloty": int(reward.get("zloty", 0)),
        "xp": int(reward.get("xp", 0))
    }
    entries.push_front(item)
    if entries.size() > 10:
        entries.resize(10)
    cfg.set_value("history", "matches", entries)
    cfg.save("user://checkmate_match_history.cfg")

func _play_again_from_results() -> void:
    match_result_panel.visible = false
    selected_mode = "Классика"
    _open_preparation()

func _show_match_result_screen(data: Dictionary) -> void:
    if match_result_panel == null:
        return
    var winner := str(data.get("winnerTeam", ""))
    var result := str(data.get("result", "finished"))
    var headline := "НИЧЬЯ" if winner == "draw" else "ПОБЕДА!" if winner == local_player_team else "ПОРАЖЕНИЕ"
    match_result_title.text = headline
    match_result_title.add_theme_color_override("font_color", Color(0.88, 0.76, 0.52) if headline != "ПОРАЖЕНИЕ" else Color(0.82, 0.62, 0.53))
    var team_name := "БЕЛЫЕ" if local_player_team == "white" else "ЧЁРНЫЕ"
    var finish_name := "МАТ" if result == "checkmate" else "ПАТ" if result == "stalemate" else "ЗАВЕРШЕНИЕ ПАРТИИ"
    match_result_subtitle.text = "КЛАССИЧЕСКИЙ РЕЖИМ • ТВОЯ КОМАНДА: %s • %s" % [team_name, finish_name]
    var personal: Dictionary = {}
    for player in data.get("players", []):
        if str(player.get("playerId", "")) == online_player_id:
            personal = player
            break
    var stats: Dictionary = personal.get("stats", {})
    var moves := int(stats.get("moves", 0))
    var captures := int(stats.get("captures", 0))
    var checks := int(stats.get("checks", 0))
    var mates := int(stats.get("checkmates", 0))
    var promotions := int(stats.get("promotions", 0))
    var castlings := int(stats.get("castlings", 0))
    var passes := int(stats.get("passes", 0))
    match_result_stats.text = "Ходы: %d\nВзятия: %d\nШахи: %d\nМатующие ходы: %d\nПревращения пешки: %d\nРокировки: %d\nПередачи хода: %d" % [moves, captures, checks, mates, promotions, castlings, passes]
    var reward: Dictionary = data.get("reward", {})
    var breakdown: Dictionary = reward.get("breakdown", {})
    var voting: Dictionary = breakdown.get("voting", {})
    var vote_count := int(stats.get("votes", 0))
    var correct_votes := int(stats.get("correctVotes", 0))
    var vote_accuracy := int(reward.get("voteAccuracy", 0))
    var bonus_xp := int(voting.get("xp", 0))
    var bonus_zloty := int(voting.get("zloty", 0))
    if not reward.is_empty():
        match_result_rewards.text = "ЗЛОТЫЕ\n+%d\n\nОПЫТ (XP)\n+%d\n\nКачество ходов: %d%%\nТактика и участие учтены в награде." % [int(reward.get("zloty", 0)), int(reward.get("xp", 0)), int(reward.get("accuracy", 0))]
        match_result_votes.text = "Отдано голосов: %d • Совпало с решением команды: %d • Точность: %d%%\nБонус за голосование: +%d XP и +%d злотых" % [vote_count, correct_votes, vote_accuracy, bonus_xp, bonus_zloty]
        var reward_city: Dictionary = reward.get("city", {})
        if not reward_city.is_empty():
            _apply_city_profile(reward_city)
    else:
        match_result_rewards.text = "Награда появится после авторизации.\nВойди в аккаунт, чтобы сохранять злотые и опыт."
        match_result_votes.text = "Отдано голосов: %d • Совпало с решением команды: %d • Точность: %d%%" % [vote_count, correct_votes, vote_accuracy]
    if selected_mode != "Командное голосование":
        match_result_votes.text = "Обычная классическая партия — голосование в этом матче не использовалось."
    elif vote_count < 3 or vote_accuracy < 75:
        match_result_votes.text += "\nУсловие бонуса: минимум 3 голоса и точность от 75%."
    _record_match_history(data, headline, reward)
    game_panel.visible = false
    match_result_panel.visible = true

func _build_preparation_screen() -> void:
    preparation_panel = Control.new()
    preparation_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    preparation_panel.visible = false
    ui.add_child(preparation_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.015, 0.012, 0.010, 0.96)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    preparation_panel.add_child(shade)
    var frame := _panel(preparation_panel, 0.06, 0.07, 0.94, 0.93)
    _add_label(frame, "ПОДГОТОВКА К ПАРТИИ", Vector2(24, 16), Vector2(650, 42), 27, PALE_GOLD)
    var mode_label := _add_label(frame, "РЕЖИМ: " + selected_mode.to_upper(), Vector2(26, 67), Vector2(500, 28), 16, Color(0.83, 0.77, 0.67))
    mode_label.name = "PrepModeLabel"
    var close := _ornate_button(frame, "← НАЗАД", 0.77, 0.035, 0.97, 0.14, 14, "nav")
    close.pressed.connect(_close_preparation)
    _add_label(frame, "ВЫБЕРИ ФИГУРУ ДЛЯ ЭТОЙ ПАРТИИ", Vector2(26, 112), Vector2(600, 28), 17, PALE_GOLD)
    var pieces := ["Конь", "Слон", "Ладья", "Ферзь", "Король"]
    var glyphs := ["♞", "♝", "♜", "♛", "♚"]
    for i in range(pieces.size()):
        var x := 0.025 + float(i) * 0.19
        var piece: String = pieces[i]
        var btn := _ornate_button(frame, glyphs[i], x, 0.245, x + 0.175, 0.43, 30, "card")
        btn.tooltip_text = piece
        btn.pressed.connect(_select_preparation_piece.bind(piece))
        prep_piece_buttons.append(btn)
    var info := _panel(frame, 0.035, 0.49, 0.965, 0.91)
    _add_label(info, "ТВОЙ КОМПЛЕКТ: ПЕШКА + ОДНА ФИГУРА", Vector2(18, 10), Vector2(620, 28), 18, PALE_GOLD)
    var selected_label := _add_label(info, "ВЫБРАНА: КОНЬ", Vector2(18, 48), Vector2(420, 30), 18, PALE_GOLD)
    selected_label.name = "PrepSelectedLabel"
    prep_status = _add_label(info, "Выбери дополнительную фигуру.", Vector2(18, 82), Vector2(570, 35), 15, Color(0.86, 0.81, 0.72))
    var action := _ornate_button(info, "КУПИТЬ КОМПЛЕКТ", 0.70, 0.70, 0.97, 0.95, 16, "party")
    action.name = "PrepActionButton"
    action.pressed.connect(_purchase_or_unlock_selected)
    _refresh_preparation_ui()

func _open_preparation() -> void:
    menu_panel.visible = false
    preparation_panel.visible = true
    var mode_label := preparation_panel.find_child("PrepModeLabel", true, false) as Label
    if mode_label:
        mode_label.text = "РЕЖИМ: " + selected_mode.to_upper()
    _refresh_preparation_ui()

func _close_preparation() -> void:
    _refund_pending_match_purchase()
    preparation_panel.visible = false
    menu_panel.visible = true

func _select_preparation_piece(piece_name: String) -> void:
    if pending_match_purchase and pending_match_purchase_piece != piece_name:
        _refund_pending_match_purchase()
    selected_prep_piece = PIECES.find(piece_name)
    _refresh_preparation_ui()

func _refresh_preparation_ui() -> void:
    if preparation_panel == null:
        return
    for i in range(prep_piece_buttons.size()):
        var piece: String = ["Конь", "Слон", "Ладья", "Ферзь", "Король"][i]
        var glyphs := ["♞", "♝", "♜", "♛", "♚"]
        prep_piece_buttons[i].text = glyphs[i] + ("  ✓" if piece == selected_match_piece else "")
        prep_piece_buttons[i].modulate = Color(1.0,0.88,0.56,1) if piece == selected_match_piece else Color(0.78,0.78,0.78,1)
    var piece_name: String = PIECES[selected_prep_piece]
    var info := preparation_panel.find_child("PrepSelectedLabel", true, false) as Label
    var action := preparation_panel.find_child("PrepActionButton", true, false) as Button
    var cost := int(match_piece_costs.get(piece_name, 0))
    if info:
        info.text = "КОМПЛЕКТ: ♟ + " + piece_name.to_upper() + "   •   %d ЗЛОТЫХ" % cost
    if action:
        if pending_match_purchase and pending_match_purchase_piece == piece_name:
            action.text = "ПОДТВЕРДИТЬ И НАЧАТЬ"
        else:
            action.text = "КУПИТЬ КОМПЛЕКТ — %d ЗЛОТЫХ" % cost
    if prep_status:
        var have := int(balances["zloty"])
        if piece_name == "Конь" and have < 30:
            prep_status.text = "СТАРТОВАЯ ЗАЩИТА: комплект пешка + конь стоит 30 злотых. Баланс будет восстановлен до 30."
        else:
            prep_status.text = "РАСХОДНИК НА ОДНУ ПАРТИЮ: %d злотых\nБаланс: %d • %s" % [cost, have, ("не хватает " + str(cost - have)) if have < cost else "средств достаточно"]
    _save_economy()

func _purchase_or_unlock_selected() -> void:
    var piece_name: String = PIECES[selected_prep_piece]
    if piece_name == "Пешка":
        prep_status.text = "Пешка обязательна. Выбери вторую фигуру для комплекта."
        return
    if pending_match_purchase and pending_match_purchase_piece == piece_name:
        selected_match_piece = piece_name
        _confirm_preparation()
        return
    var cost := int(match_piece_costs.get(piece_name, 0))
    if piece_name == "Конь" and int(balances["zloty"]) < 30:
        balances["zloty"] = 30
    if int(balances["zloty"]) < cost:
        prep_status.text = "НЕ ХВАТАЕТ ЗЛОТЫХ: нужно %d, есть %d. Комплект пешка + конь доступен за 30." % [cost, int(balances["zloty"])]
        _save_economy()
        return
    selected_match_piece = piece_name
    balances["zloty"] = int(balances["zloty"]) - cost
    pending_match_purchase = true
    pending_match_purchase_cost = cost
    pending_match_purchase_piece = piece_name
    _save_economy()
    prep_status.text = "Комплект пешка + " + piece_name.to_lower() + " куплен на одну партию за %d злотых. При отмене поиска деньги вернутся." % cost
    _refresh_preparation_ui()

func _confirm_preparation() -> void:
    if selected_mode not in ["Классика", "Командное голосование"]:
        prep_status.text = "Этот режим пока закрыт."
        return
    preparation_panel.visible = false
    menu_panel.visible = false
    _open_matchmaking_queue()
    if not developer_mode:
        _start_quick_match()

func _refund_pending_match_purchase() -> void:
    if not pending_match_purchase:
        return
    balances["zloty"] = int(balances["zloty"]) + pending_match_purchase_cost
    var refunded_cost := pending_match_purchase_cost
    pending_match_purchase = false
    pending_match_purchase_cost = 0
    pending_match_purchase_piece = ""
    _save_economy()
    if prep_status:
        prep_status.text = "Подготовка отменена. Возвращено %d злотых." % refunded_cost

func _load_economy() -> void:
    var cfg := ConfigFile.new()
    if cfg.load("user://checkmate_economy.cfg") == OK:
        balances["zloty"] = int(cfg.get_value("wallet", "zloty", balances["zloty"]))
        balances["xp"] = int(cfg.get_value("wallet", "xp", balances["xp"]))
        balances["chessmatites"] = int(cfg.get_value("wallet", "chessmatites", balances["chessmatites"]))
        city_unlocked_pieces = cfg.get_value("progress", "city_unlocked_pieces", city_unlocked_pieces)
        owned_skins = cfg.get_value("progress", "owned_skins", owned_skins)
        competitive_rating = clampi(int(cfg.get_value("ranked", "rating", 1000)), 0, 100000)
        persistent_player_id = str(cfg.get_value("identity", "player_id", ""))
        onboarding_completed = bool(cfg.get_value("onboarding", "completed", false))
        matchmaking_server_url = str(cfg.get_value("network", "server_url", matchmaking_server_url))
        account_token = str(cfg.get_value("account", "token", ""))
        account_player_id = str(cfg.get_value("account", "player_id", ""))
        account_username = str(cfg.get_value("account", "username", ""))
    unlocked_pieces = PIECES.duplicate()
    if persistent_player_id.is_empty():
        persistent_player_id = Crypto.new().generate_random_bytes(16).hex_encode()
        _save_economy()

func _save_economy() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("wallet", "zloty", balances["zloty"])
    cfg.set_value("wallet", "xp", balances["xp"])
    cfg.set_value("wallet", "chessmatites", balances["chessmatites"])
    cfg.set_value("progress", "unlocked_pieces", PIECES)
    cfg.set_value("progress", "city_unlocked_pieces", city_unlocked_pieces)
    cfg.set_value("progress", "owned_skins", owned_skins)
    cfg.set_value("ranked", "rating", competitive_rating)
    cfg.set_value("identity", "player_id", persistent_player_id)
    cfg.set_value("onboarding", "completed", onboarding_completed)
    cfg.set_value("network", "server_url", matchmaking_server_url)
    cfg.set_value("account", "token", account_token)
    cfg.set_value("account", "player_id", account_player_id)
    cfg.set_value("account", "username", account_username)
    cfg.save("user://checkmate_economy.cfg")

func _build_menu_3d_environment() -> void:
    # Full-screen 3D throne hall. UI is layered above this viewport.
    var container := SubViewportContainer.new()
    container.name = "MainMenu3DEnvironment"
    container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    container.mouse_filter = Control.MOUSE_FILTER_IGNORE
    container.stretch = true
    menu_panel.add_child(container)

    var viewport := SubViewport.new()
    viewport.name = "MainMenu3DViewport"
    viewport.size = Vector2i(1600, 900)
    viewport.own_world_3d = true
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    container.add_child(viewport)

    var hall := Node3D.new()
    hall.name = "ThroneHall3D"
    viewport.add_child(hall)

    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.018, 0.015, 0.014)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.50, 0.43, 0.34)
    env.ambient_light_energy = 0.72
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env_node.environment = env
    hall.add_child(env_node)

    var cam := Camera3D.new()
    cam.position = Vector3(0, 6.3, 17.8)
    cam.fov = 48
    hall.add_child(cam)
    cam.look_at(Vector3(0, 3.0, -3.8), Vector3.UP)

    var key := DirectionalLight3D.new()
    key.rotation_degrees = Vector3(-34, -22, 0)
    key.light_color = Color(1.0, 0.78, 0.52)
    key.light_energy = 1.05
    key.shadow_enabled = true
    hall.add_child(key)

    var floor_mat := _material(Color(0.075, 0.055, 0.043), 0.38, 0.12)
    var floor_alt := _material(Color(0.105, 0.078, 0.058), 0.42, 0.08)
    var wall_mat := _material(Color(0.095, 0.075, 0.064), 0.86, 0.02)
    var stone_mat := _material(Color(0.20, 0.17, 0.14), 0.78, 0.04)
    var trim_mat := _material(Color(0.31, 0.22, 0.13), 0.58, 0.18)
    var dark_mat := _material(Color(0.025, 0.021, 0.019), 0.9, 0.0)
    var glass_blue := _material(Color(0.055, 0.16, 0.22), 0.28, 0.22)
    var glass_red := _material(Color(0.25, 0.075, 0.045), 0.32, 0.16)
    var banner_mat := _material(Color(0.12, 0.025, 0.022), 0.94, 0.0)

    _menu_box(hall, Vector3(0, -0.35, -1.5), Vector3(32, 0.7, 34), floor_mat)
    # Large alternating stone floor slabs give the hall real depth and scale.
    for row in range(8):
        for col in range(12):
            var tile_mat: Material = floor_mat if (row + col) % 2 == 0 else floor_alt
            _menu_box(hall, Vector3((col - 5.5) * 2.55, 0.012, (row - 3.5) * 2.65 - 1.5), Vector3(2.48, 0.035, 2.58), tile_mat)

    _menu_box(hall, Vector3(0, 6.0, -11.8), Vector3(31, 13, 0.9), wall_mat)
    _menu_box(hall, Vector3(0, 12.4, -5.5), Vector3(31, 0.7, 13), dark_mat)
    # Rear stained-glass windows and their stone mullions.
    for x in [-9.0, -4.5, 0.0, 4.5, 9.0]:
        var glass := glass_blue if int(abs(x) * 10.0) % 2 == 0 else glass_red
        _menu_box(hall, Vector3(x, 7.1, -11.22), Vector3(3.15, 7.0, 0.10), glass)
        _menu_box(hall, Vector3(x - 1.72, 7.1, -11.05), Vector3(0.18, 7.6, 0.32), trim_mat)
        _menu_box(hall, Vector3(x + 1.72, 7.1, -11.05), Vector3(0.18, 7.6, 0.32), trim_mat)
        _menu_box(hall, Vector3(x, 3.52, -11.05), Vector3(3.55, 0.18, 0.32), trim_mat)
        _menu_box(hall, Vector3(x, 10.68, -11.05), Vector3(3.55, 0.18, 0.32), trim_mat)
        _menu_box(hall, Vector3(x, 7.1, -10.98), Vector3(0.12, 7.0, 0.30), trim_mat)
        _menu_box(hall, Vector3(x, 7.1, -10.97), Vector3(3.1, 0.12, 0.30), trim_mat)

    # Paired columns, stepped bases, capitals and dark hanging banners.
    for x in [-12.0, -8.0, 8.0, 12.0]:
        for z in [-8.8, -1.0, 6.2]:
            _menu_cylinder(hall, Vector3(x, 0.62, z), 0.95, 1.0, stone_mat)
            _menu_cylinder(hall, Vector3(x, 3.75, z), 0.54, 6.0, stone_mat)
            _menu_cylinder(hall, Vector3(x, 6.85, z), 0.82, 0.42, trim_mat)
            _menu_box(hall, Vector3(x, 7.18, z), Vector3(1.45, 0.28, 1.45), stone_mat)
            if z < 0:
                _menu_box(hall, Vector3(x, 5.0, z + 0.84), Vector3(1.25, 3.4, 0.10), banner_mat)
                _menu_box(hall, Vector3(x, 3.22, z + 0.84), Vector3(0.92, 0.12, 0.10), trim_mat)

    # Broad ceremonial stairs rising to the distant throne platform.
    for i in range(9):
        var depth := 0.62 + float(i) * 0.34
        var height := 0.20 + float(i) * 0.23
        _menu_box(hall, Vector3(0, height * 0.5, -7.2 - float(i) * 0.48), Vector3(9.0 + float(i) * 0.44, height, depth), stone_mat)
        _menu_box(hall, Vector3(0, height + 0.025, -7.2 - float(i) * 0.48), Vector3(9.0 + float(i) * 0.44, 0.05, depth), trim_mat)
    _menu_box(hall, Vector3(0, 2.65, -11.2), Vector3(8.2, 0.5, 2.2), dark_mat)
    _menu_box(hall, Vector3(0, 2.95, -11.2), Vector3(7.8, 0.12, 1.9), trim_mat)

    # Warm braziers and local light pools along the nave.
    for x in [-10.2, -5.6, 5.6, 10.2]:
        var brazier_mat := _material(Color(0.18, 0.105, 0.045), 0.48, 0.32)
        _menu_cylinder(hall, Vector3(x, 1.55, 1.4), 0.38, 2.6, brazier_mat)
        _menu_cylinder(hall, Vector3(x, 2.92, 1.4), 0.72, 0.18, trim_mat)
        var flame := OmniLight3D.new()
        flame.position = Vector3(x, 3.55, 1.4)
        flame.light_color = Color(1.0, 0.34, 0.08)
        flame.light_energy = 1.5
        flame.omni_range = 8.0
        hall.add_child(flame)
        _menu_sphere(hall, Vector3(x, 3.48, 1.4), 0.22, _material(Color(1.0, 0.25, 0.035), 0.25, 0.0))

    # Side arches are suggested with tall curved stone ribs.
    for x in [-14.0, -6.0, 6.0, 14.0]:
        _menu_box(hall, Vector3(x, 8.4, -4.0), Vector3(0.42, 8.0, 0.55), stone_mat)
        _menu_box(hall, Vector3(x, 12.35, -4.0), Vector3(4.4, 0.38, 0.55), stone_mat)

func _menu_box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position = pos
    node.material_override = mat
    parent.add_child(node)

func _menu_cylinder(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material) -> void:
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius * 1.12
    mesh.height = height
    mesh.radial_segments = 32
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position = pos
    node.material_override = mat
    parent.add_child(node)

func _menu_sphere(parent: Node3D, pos: Vector3, radius: float, mat: Material) -> void:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position = pos
    node.material_override = mat
    parent.add_child(node)

func _build_piece_preview() -> void:
    preview_container = SubViewportContainer.new()
    preview_container.anchor_left = 0.375
    preview_container.anchor_top = 0.275
    preview_container.anchor_right = 0.625
    preview_container.anchor_bottom = 0.705
    preview_container.mouse_filter = Control.MOUSE_FILTER_STOP
    preview_container.stretch = true
    menu_panel.add_child(preview_container)
    var sub := SubViewport.new()
    sub.size = Vector2i(640, 640)
    sub.transparent_bg = true
    sub.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    preview_container.add_child(sub)
    var scene := Node3D.new()
    sub.add_child(scene)
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0, 0, 0, 0)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.58, 0.52, 0.44)
    env.ambient_light_energy = 0.78
    env_node.environment = env
    scene.add_child(env_node)
    preview_camera_pivot = Node3D.new()
    preview_camera_pivot.name = "PreviewCameraOrbitPivot"
    preview_camera_pivot.position = Vector3(0, 1.05, 0)
    scene.add_child(preview_camera_pivot)
    preview_camera = Camera3D.new()
    preview_camera.name = "OrbitingPreviewCamera"
    preview_camera.position = Vector3(0, 0, 6.6)
    preview_camera.fov = 32
    preview_camera_pivot.add_child(preview_camera)
    preview_camera.look_at(Vector3(0, 1.05, 0), Vector3.UP)
    preview_camera_pitch = 0.0
    var key := DirectionalLight3D.new()
    key.rotation_degrees = Vector3(-35, -25, 0)
    key.light_color = Color(1.0, 0.88, 0.70)
    key.light_energy = 1.15
    key.shadow_enabled = true
    scene.add_child(key)
    var fill := OmniLight3D.new()
    fill.position = Vector3(-2.2, 2.8, 2.5)
    fill.light_color = Color(1.0, 0.72, 0.42)
    fill.light_energy = 0.85
    fill.omni_range = 9
    scene.add_child(fill)
    var rim_light := OmniLight3D.new()
    rim_light.position = Vector3(2.0, 2.0, -1.8)
    rim_light.light_color = Color(0.72, 0.82, 1.0)
    rim_light.light_energy = 0.45
    rim_light.omni_range = 7
    scene.add_child(rim_light)

    # A restrained, dark carved-stone plinth: no gold trim or bright metallic shine.
    var stone := _material(Color(0.035, 0.032, 0.030), 0.88, 0.02)
    var stone_edge := _material(Color(0.075, 0.067, 0.060), 0.82, 0.04)
    var pedestal := MeshInstance3D.new()
    var ped_mesh := CylinderMesh.new()
    ped_mesh.top_radius = 0.90
    ped_mesh.bottom_radius = 1.04
    ped_mesh.height = 0.28
    ped_mesh.radial_segments = 96
    pedestal.mesh = ped_mesh
    pedestal.position.y = 0.14
    pedestal.material_override = stone
    scene.add_child(pedestal)
    var lower_band := MeshInstance3D.new()
    var lower_mesh := CylinderMesh.new()
    lower_mesh.top_radius = 1.07
    lower_mesh.bottom_radius = 1.07
    lower_mesh.height = 0.065
    lower_mesh.radial_segments = 96
    lower_band.mesh = lower_mesh
    lower_band.position.y = 0.045
    lower_band.material_override = stone_edge
    scene.add_child(lower_band)
    var upper_band := MeshInstance3D.new()
    var upper_mesh := CylinderMesh.new()
    upper_mesh.top_radius = 0.94
    upper_mesh.bottom_radius = 0.94
    upper_mesh.height = 0.045
    upper_mesh.radial_segments = 96
    upper_band.mesh = upper_mesh
    upper_band.position.y = 0.285
    upper_band.material_override = stone_edge
    scene.add_child(upper_band)
    _add_preview_torus(scene, 0.99, 0.018, 0.315, stone_edge)
    _add_preview_torus(scene, 1.025, 0.012, 0.075, stone_edge)

    preview_pawn = Node3D.new()
    preview_pawn.position.y = 0.43
    preview_pawn.position.z = 0.0
    scene.add_child(preview_pawn)
    _build_preview_piece("Пешка")

func _build_preview_piece(piece_name: String) -> void:
    for child in preview_pawn.get_children():
        child.queue_free()
    var wood := StandardMaterial3D.new()
    wood.albedo_color = Color(0.62, 0.43, 0.27)
    wood.albedo_texture = load("res://assets/dark_walnut.jpg")
    wood.roughness = 0.84
    wood.metallic = 0.0
    wood.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR
    var ivory := wood
    var gold := _material(Color(0.12, 0.085, 0.055), 0.88, 0.0)
    var dark_gold := _material(Color(0.075, 0.055, 0.04), 0.92, 0.0)

    # Shared sculpted base and tapered body, with a classic Staunton silhouette.
    var profile := [
        Vector2(0.02, 0.00), Vector2(0.37, 0.00), Vector2(0.44, 0.045),
        Vector2(0.46, 0.10), Vector2(0.43, 0.16), Vector2(0.35, 0.205),
        Vector2(0.29, 0.25), Vector2(0.25, 0.31), Vector2(0.22, 0.39),
        Vector2(0.19, 0.48), Vector2(0.155, 0.58), Vector2(0.145, 0.68),
        Vector2(0.17, 0.75), Vector2(0.25, 0.79), Vector2(0.28, 0.84),
        Vector2(0.24, 0.89), Vector2(0.16, 0.92)
    ]
    _add_preview_lathe(preview_pawn, profile, ivory, 64)
    _add_preview_torus(preview_pawn, 0.395, 0.026, 0.145, gold)
    _add_preview_torus(preview_pawn, 0.205, 0.018, 0.535, dark_gold)
    _add_preview_torus(preview_pawn, 0.255, 0.022, 0.825, gold)

    match piece_name:
        "Пешка":
            _add_preview_sphere(0.205, 1.12, ivory)
        "Ладья":
            _add_preview_cylinder(0.205, 0.30, 0.90, ivory)
            _add_preview_cylinder(0.275, 0.10, 1.17, gold)
            for j in range(6):
                var angle := TAU * float(j) / 6.0
                _add_preview_box(Vector3(cos(angle) * 0.19, 1.31, sin(angle) * 0.19), Vector3(0.105, 0.20, 0.105), ivory)
        "Конь":
            _add_preview_sphere(0.20, 1.10, ivory)
            _add_preview_box(Vector3(0, 1.30, -0.02), Vector3(0.29, 0.43, 0.22), ivory)
            _add_preview_box(Vector3(0.0, 1.49, 0.015), Vector3(0.23, 0.10, 0.20), gold)
        "Слон":
            _add_preview_sphere(0.19, 1.12, ivory)
            _add_preview_cylinder(0.055, 0.34, 1.23, gold)
            _add_preview_sphere(0.075, 1.58, gold)
        "Ферзь":
            _add_preview_sphere(0.19, 1.12, ivory)
            _add_preview_cylinder(0.26, 0.10, 1.22, gold)
            for j in range(5):
                var angle := TAU * float(j) / 5.0
                var crown_point := _add_preview_sphere(0.055, 1.39, gold)
                crown_point.position.x = cos(angle) * 0.19
                crown_point.position.z = sin(angle) * 0.19
        "Король":
            _add_preview_sphere(0.19, 1.12, ivory)
            _add_preview_cylinder(0.25, 0.10, 1.22, gold)
            _add_preview_box(Vector3(0, 1.48, 0), Vector3(0.10, 0.43, 0.10), gold)
            _add_preview_box(Vector3(0, 1.54, 0), Vector3(0.32, 0.10, 0.10), gold)

func _add_preview_lathe(parent: Node3D, profile: Array, mat: Material, segments: int = 48) -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for ring in range(profile.size() - 1):
        var a: Vector2 = profile[ring]
        var b: Vector2 = profile[ring + 1]
        for i in range(segments):
            var a0 := TAU * float(i) / float(segments)
            var a1 := TAU * float(i + 1) / float(segments)
            var p00 := Vector3(cos(a0) * a.x, a.y, sin(a0) * a.x)
            var p01 := Vector3(cos(a1) * a.x, a.y, sin(a1) * a.x)
            var p10 := Vector3(cos(a0) * b.x, b.y, sin(a0) * b.x)
            var p11 := Vector3(cos(a1) * b.x, b.y, sin(a1) * b.x)
            var u0 := float(i) / float(segments)
            var u1 := float(i + 1) / float(segments)
            var v0 := float(ring) / float(profile.size() - 1)
            var v1 := float(ring + 1) / float(profile.size() - 1)
            st.set_uv(Vector2(u0, v0))
            st.add_vertex(p00)
            st.set_uv(Vector2(u0, v1))
            st.add_vertex(p10)
            st.set_uv(Vector2(u1, v1))
            st.add_vertex(p11)
            st.set_uv(Vector2(u0, v0))
            st.add_vertex(p00)
            st.set_uv(Vector2(u1, v1))
            st.add_vertex(p11)
            st.set_uv(Vector2(u1, v0))
            st.add_vertex(p01)
    st.generate_normals()
    var mesh := st.commit()
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.material_override = mat
    parent.add_child(node)

func _add_preview_torus(parent: Node3D, radius: float, tube_radius: float, y: float, mat: Material) -> void:
    var mesh := TorusMesh.new()
    mesh.inner_radius = maxf(0.01, radius - tube_radius)
    mesh.outer_radius = radius + tube_radius
    mesh.rings = 64
    mesh.ring_segments = 12
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position.y = y
    node.material_override = mat
    parent.add_child(node)

func _add_preview_cylinder(radius: float, height: float, y: float, mat: Material) -> void:
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius * 0.78
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = 48
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position.y = y + height * 0.5
    node.material_override = mat
    preview_pawn.add_child(node)

func _add_preview_sphere(radius: float, y: float, mat: Material) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 48
    mesh.rings = 24
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position.y = y
    node.material_override = mat
    preview_pawn.add_child(node)
    return node

func _add_preview_box(pos: Vector3, size: Vector3, mat: Material) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.position = pos
    node.material_override = mat
    preview_pawn.add_child(node)

func _input(event: InputEvent) -> void:
    if game_panel != null and game_panel.visible and world_root.visible:
        if event is InputEventScreenTouch and event.pressed:
            _handle_game_board_click(event.position)
            return
        if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
            _handle_game_board_click(event.position)
            return
    if menu_panel == null or not menu_panel.visible or preview_container == null:
        return
    if event is InputEventScreenTouch:
        if event.pressed and preview_container.get_global_rect().has_point(event.position):
            dragging_preview = true
            last_pointer_x = event.position.x
            last_pointer_y = event.position.y
        elif not event.pressed:
            dragging_preview = false
    elif event is InputEventScreenDrag and dragging_preview:
        _rotate_preview_from_drag(event.position.x, event.position.y)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed and preview_container.get_global_rect().has_point(event.position):
            dragging_preview = true
            last_pointer_x = event.position.x
            last_pointer_y = event.position.y
        else:
            dragging_preview = false
    elif event is InputEventMouseMotion and dragging_preview:
        _rotate_preview_from_drag(event.position.x, event.position.y)

func _rotate_preview_from_drag(pointer_x: float, pointer_y: float) -> void:
    var delta_x := pointer_x - last_pointer_x
    var delta_y := pointer_y - last_pointer_y
    # Orbit the camera around a stationary piece and pedestal.
    if is_instance_valid(preview_camera_pivot):
        preview_camera_pivot.rotate_y(deg_to_rad(delta_x * 0.55))
        preview_camera_pitch = clampf(preview_camera_pitch + deg_to_rad(delta_y * 0.35), deg_to_rad(-24.0), deg_to_rad(24.0))
        preview_camera_pivot.rotation.x = preview_camera_pitch
    last_pointer_x = pointer_x
    last_pointer_y = pointer_y

func _change_piece(direction: int) -> void:
    selected_piece = posmod(selected_piece + direction, PIECES.size())
    var piece_name: String = PIECES[selected_piece]
    _build_preview_piece(piece_name)
    var label := menu_panel.find_child("PieceName", true, false) as Label
    if label:
        label.text = piece_name.to_upper() + ("   •   ДОСТУПНА" if selected_piece == 0 else "   •   🔒 ЗАБЛОКИРОВАНА")
    var hint := menu_panel.find_child("PieceLockHint", true, false) as Label
    if hint:
        hint.text = "🔒 ОТКРОЙ ФИГУРУ В КОЛЛЕКЦИИ" if selected_piece != 0 else "ПРОВЕДИ ПАЛЬЦЕМ — КАМЕРА ОБОЙДЁТ ФИГУРУ"
    if selected_piece != 0 and unlocked_pieces.has(piece_name):
        selected_match_piece = piece_name
        _show_notice(piece_name + " выбрана. Нажми «ПАРТИЯ», чтобы продолжить.")
    elif selected_piece != 0:
        _show_notice("🔒 " + piece_name + " пока заблокирована. Открой её в магазине.")
    _refresh_main_piece_shelf()

func _panel(parent: Control, l: float, t: float, r: float, b: float) -> Panel:
    var p := Panel.new()
    p.anchor_left = l
    p.anchor_top = t
    p.anchor_right = r
    p.anchor_bottom = b
    var style := StyleBoxFlat.new()
    style.bg_color = DARK
    style.border_color = Color(0.62, 0.47, 0.27, 0.98)
    style.set_border_width_all(2)
    style.set_corner_radius_all(2)
    style.shadow_color = Color(0, 0, 0, 0.7)
    style.shadow_size = 10
    style.shadow_offset = Vector2(0, 4)
    p.add_theme_stylebox_override("panel", style)
    parent.add_child(p)
    return p

func _ornate_button(parent: Control, text_value: String, l: float, t: float, r: float, b: float, font_size: int, style_kind: String = "card") -> Button:
    var button := Button.new()
    button.text = text_value
    button.anchor_left = l
    button.anchor_top = t
    button.anchor_right = r
    button.anchor_bottom = b
    button.add_theme_font_size_override("font_size", font_size + 4)
    button.add_theme_font_override("font", UI_FONT)
    button.add_theme_color_override("font_color", Color(0.91, 0.83, 0.70))
    button.add_theme_color_override("font_hover_color", Color(1.0, 0.95, 0.82))
    button.add_theme_color_override("font_pressed_color", Color(0.78, 0.60, 0.36))
    button.add_theme_color_override("font_disabled_color", Color(0.48, 0.42, 0.34))
    button.add_theme_color_override("font_outline_color", Color(0.02, 0.015, 0.01, 0.98))
    button.add_theme_constant_override("outline_size", 4)
    button.alignment = HORIZONTAL_ALIGNMENT_CENTER
    button.focus_mode = Control.FOCUS_NONE
    button.clip_text = true

    var texture_path := "res://assets/ornate_button.png"
    var ml := 42.0
    var mt := 34.0
    if style_kind == "party":
        texture_path = "res://assets/ornate_party_button.png"
        ml = 58.0
        mt = 24.0
    elif style_kind == "nav":
        texture_path = "res://assets/ornate_nav_button.png"
        ml = 30.0
        mt = 25.0
    elif style_kind == "arrow":
        texture_path = "res://assets/ornate_button.png"
        ml = 18.0
        mt = 16.0

    var normal := StyleBoxTexture.new()
    normal.texture = load(texture_path)
    normal.texture_margin_left = ml
    normal.texture_margin_right = ml
    normal.texture_margin_top = mt
    normal.texture_margin_bottom = mt
    normal.draw_center = true
    normal.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
    normal.axis_stretch_vertical = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
    normal.content_margin_left = 28
    normal.content_margin_right = 28
    normal.content_margin_top = 17
    normal.content_margin_bottom = 17

    var hover := normal.duplicate()
    hover.modulate_color = Color(1.42, 1.29, 1.06, 1.0)
    var pressed := normal.duplicate()
    pressed.modulate_color = Color(0.78, 0.62, 0.39, 1.0)
    var disabled := normal.duplicate()
    disabled.modulate_color = Color(0.48, 0.43, 0.35, 0.8)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("hover", hover)
    button.add_theme_stylebox_override("pressed", pressed)
    button.add_theme_stylebox_override("disabled", disabled)
    button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    parent.add_child(button)
    return button

func _add_label(parent: Control, text_value: String, pos: Vector2, size: Vector2, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.position = pos
    label.size = size
    label.add_theme_font_size_override("font_size", font_size + 3)
    label.add_theme_font_override("font", UI_FONT)
    label.add_theme_constant_override("line_spacing", 6)
    label.add_theme_color_override("font_color", color)
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    parent.add_child(label)
    return label

func _show_notice(message: String) -> void:
    if status_label != null:
        status_label.text = message

func _on_mode_pressed(mode_name: String) -> void:
    selected_mode = mode_name
    _show_notice("Выбран режим: " + selected_mode + ". Нажми ПАРТИЯ для подготовки.")

func _start_game(mode_name: String) -> void:
    game_over = false
    last_move.clear()
    halfmove_clock = 0
    position_counts.clear()
    selected_game_piece = null
    current_team = "white"
    active_teammate = randi_range(1, CLASSIC_TEAM_SIZE)
    first_move_vote_done = true
    first_move_voted = false
    first_move_votes = {"white": 0, "black": 0}
    team_next_player = {"white": (active_teammate % CLASSIC_TEAM_SIZE) + 1, "black": randi_range(1, CLASSIC_TEAM_SIZE)}
    for marker in turn_highlight_nodes:
        if is_instance_valid(marker):
            marker.queue_free()
    turn_highlight_nodes.clear()
    for old_piece in game_piece_nodes:
        if is_instance_valid(old_piece):
            old_piece.queue_free()
    game_piece_nodes.clear()
    _build_game_pieces()
    if game_over_panel:
        game_over_panel.visible = false
    if match_result_panel:
        match_result_panel.visible = false
    _refresh_team_turn_label()
    menu_panel.visible = false
    if online_panel:
        online_panel.visible = false
    game_panel.visible = true
    world_root.visible = true
    for child in game_panel.get_children():
        if child is Panel:
            for sub in child.get_children():
                if sub is Label and sub.text.begins_with("ПАРТИЯ"):
                    sub.text = "ПАРТИЯ  •  " + mode_name
    status_label.text = "ЛОКАЛЬНЫЙ ТЕСТ • " + mode_name + " • ВЫБРАНАЯ ФИГУРА: " + selected_match_piece + " • ОНЛАЙН ПОДКЛЮЧЕНИЕ ЕЩЁ НЕ НАСТРОЕНО"
    # Wider, higher view keeps all 64 squares and every piece visible on phone screens.
    camera.fov = 54.0
    camera.position = Vector3(0, 15.5, 13.8)
    camera.look_at(Vector3(0, 0.45, -0.4), Vector3.UP)
    _update_turn_highlights()
    status_label.text = "Первыми ходят БЕЛЫЕ. Команда белых решает, какой ход сделать."
    _remember_position()

func _return_to_menu() -> void:
    selected_game_piece = null
    if online_active:
        _stop_online()
    game_panel.visible = false
    if match_result_panel:
        match_result_panel.visible = false
    if match_history_panel:
        match_history_panel.visible = false
    menu_panel.visible = true
    _refresh_wallet_labels()
    world_root.visible = false
    camera.position = Vector3(0, 9.5, 13.0)
    camera.look_at(Vector3(0, 1.0, 0), Vector3.UP)

func _refresh_wallet_labels() -> void:
    var zloty := menu_panel.find_child("ZlotyCounter", true, false) as Button
    var chessmatites := menu_panel.find_child("ChessmatitesCounter", true, false) as Button
    var xp := menu_panel.find_child("XPCounter", true, false) as Button
    if zloty:
        zloty.text = "◈  ЗЛОТЫЕ\n%d" % int(balances["zloty"])
    if chessmatites:
        chessmatites.text = "◆  ШАХМАТИТЫ\n%d   +" % int(balances["chessmatites"])
    if xp:
        xp.text = "★  XP\n%d" % int(balances["xp"])



func _open_mode_selection() -> void:
    if not unlocked_pieces.has(selected_match_piece):
        _show_notice("Сначала выбери открытую фигуру на полке.")
        return
    if mode_selection_panel == null:
        _build_mode_selection_screen()
    menu_panel.visible = false
    preparation_panel.visible = false
    mode_selection_panel.visible = true
    _refresh_mode_selection()

func _build_mode_selection_screen() -> void:
    mode_selection_panel = Control.new()
    mode_selection_panel.name = "ModeSelectionScreen"
    mode_selection_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mode_selection_panel.visible = false
    ui.add_child(mode_selection_panel)

    var shade := ColorRect.new()
    shade.color = Color(0.012, 0.010, 0.009, 0.97)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    mode_selection_panel.add_child(shade)

    var frame := _panel(mode_selection_panel, 0.045, 0.055, 0.955, 0.945)
    _add_label(frame, "ВЫБОР ИГРОВОГО РЕЖИМА", Vector2(24, 18), Vector2(680, 42), 27, PALE_GOLD)
    _add_label(frame, "Выбери правила командной партии", Vector2(26, 62), Vector2(580, 26), 15, Color(0.78, 0.72, 0.63))

    var back := _ornate_button(frame, "← НАЗАД", 0.80, 0.035, 0.97, 0.135, 14, "nav")
    back.pressed.connect(_close_mode_selection)

    var names := ["Классика", "Командное голосование", "Несколько фигур"]
    var symbols := ["01", "02", "03"]
    var captions := [
        "Свободная командная игра",
        "Решение всей команды",
        "Несколько фигур у игрока"
    ]
    for i in range(names.size()):
        var left := 0.035 + float(i) * 0.315
        var card_text: String = symbols[i] + "  |  " + names[i] + "  |  " + captions[i]
        var card := _ornate_button(frame, card_text, left, 0.235, left + 0.285, 0.57, 16, "card")
        card.pressed.connect(_select_mode_card.bind(names[i]))
        mode_choice_buttons.append(card)

    var details := _panel(frame, 0.035, 0.625, 0.965, 0.835)
    _add_label(details, "КАК ПРОХОДИТ РЕЖИМ", Vector2(18, 12), Vector2(500, 26), 16, PALE_GOLD)
    mode_description_label = _add_label(details, "", Vector2(18, 47), Vector2(760, 66), 14, Color(0.86, 0.81, 0.72))
    _add_label(frame, "НАЖМИ НА РЕЖИМ, ЧТОБЫ СРАЗУ ПЕРЕЙТИ К ПОДГОТОВКЕ", Vector2(24, 505), Vector2(760, 28), 15, PALE_GOLD)

    _refresh_mode_selection()

func _select_mode_card(mode_name: String) -> void:
    if mode_name == "Несколько фигур":
        return
    selected_mode = mode_name
    if mode_selection_panel:
        mode_selection_panel.visible = false
    _open_preparation()

func _refresh_mode_selection() -> void:
    var names := ["Классика", "Командное голосование", "Несколько фигур"]
    var captions := [
        "Каждый участник управляет своей фигурой. В свой ход игрок может сделать допустимый ход или передать очередь союзнику. Команда играет против другой команды.",
        "Игрок предлагает ход, а союзники обсуждают и голосуют. Большинство принимает решение; точные голоса влияют на бонус к награде.",
        "У каждого участника может быть несколько фигур. Игрок выбирает, какой фигурой ходить, или передаёт очередь союзнику. Система подсказывает, кому лучше передать ход."
    ]
    for i in range(min(mode_choice_buttons.size(), names.size())):
        var marker := "◆  " if selected_mode == names[i] else ""
        mode_choice_buttons[i].disabled = i > 1
        var availability := "ДОСТУПНО" if i <= 1 else "СКОРО"
        mode_choice_buttons[i].text = marker + "%02d" % (i + 1) + "  |  " + names[i] + "  |  " + availability
    if mode_description_label:
        var index := names.find(selected_mode)
        if index < 0 or index > 1:
            index = 0
            selected_mode = names[0]
        mode_description_label.text = captions[index] + ("\n\nОстальные режимы подключим после завершения классики." if index == 0 else "")

func _continue_to_preparation() -> void:
    mode_selection_panel.visible = false
    _open_preparation()

func _close_mode_selection() -> void:
    if mode_selection_panel:
        mode_selection_panel.visible = false
    menu_panel.visible = true

func _handle_game_board_click(screen_position: Vector2) -> void:
    if game_over:
        return
    if selected_mode == "Несколько фигур":
        status_label.text = "Режим нескольких фигур подключим следующим этапом."
        return
    if team_turn_label and team_turn_label.get_global_rect().has_point(screen_position):
        return
    var ray_origin: Vector3 = camera.project_ray_origin(screen_position)
    var ray_direction: Vector3 = camera.project_ray_normal(screen_position)
    var hit = Plane(Vector3.UP, 0.59).intersects_ray(ray_origin, ray_direction)
    if hit == null:
        return
    var col: int = roundi(hit.x / 1.12 + 3.5)
    var row: int = roundi((hit.z + 0.4) / 1.0 + 3.5)
    if col < 0 or col > 7 or row < 0 or row > 7:
        return
    var local_team := _local_team()
    if online_active and not online_match_id.is_empty() and online_active_player_id != online_player_id:
        status_label.text = "Сейчас ходит другой участник вашей команды. Можно передать очередь."
        return
    if online_active and not online_match_id.is_empty() and bool(_server_viewer_eliminated):
        status_label.text = "Ты выбыл. Доступны наблюдение, командный чат и выход в меню."
        return
    if current_team != local_team:
        status_label.text = "Сейчас ход соперника."
        return
    var target_piece: Node3D = _get_game_piece_at(col, row)
    if selected_game_piece == null:
        if target_piece != null and str(target_piece.get_meta("team")) == local_team and (not online_active or online_match_id.is_empty() or str(target_piece.get_meta("ownerPlayerId", "")) == online_player_id):
            selected_game_piece = target_piece
            _update_turn_highlights()
            status_label.text = "Выбрана фигура: " + str(target_piece.get_meta("kind")) + ". Выбери клетку."
        else:
            status_label.text = "Выбери свою фигуру."
        return
    if target_piece == selected_game_piece:
        selected_game_piece = null
        _update_turn_highlights()
        status_label.text = "Выбор отменён."
        return
    if target_piece != null and str(target_piece.get_meta("team")) == local_team:
        selected_game_piece = target_piece
        _update_turn_highlights()
        status_label.text = "Выбрана фигура: " + str(target_piece.get_meta("kind")) + "."
        return
    var from_col := int(selected_game_piece.get_meta("col"))
    var from_row := int(selected_game_piece.get_meta("row"))
    if online_active and not online_match_id.is_empty():
        if str(selected_game_piece.get_meta("ownerPlayerId", "")) != online_player_id:
            status_label.text = "Эта фигура принадлежит союзнику. Выбери свою фигуру или передай ход."
            return
        var move_payload := {"fromFile": from_col, "fromRow": from_row, "toFile": col, "toRow": row}
        if selected_mode == "Командное голосование":
            _send_matchmaking_request("game_propose", "/matches/" + online_match_id + "/propose", HTTPClient.METHOD_POST, move_payload)
            status_label.text = "Предложение отправлено команде. Ждём голосов…"
        else:
            _send_matchmaking_request("game_move", "/matches/" + online_match_id + "/move", HTTPClient.METHOD_POST, move_payload)
            status_label.text = "Ход отправлен. Ждём подтверждения сервера…"
        selected_game_piece = null
        return
    _process_classic_move(from_col, from_row, col, row)

func _process_classic_move(from_col: int, from_row: int, to_col: int, to_row: int) -> void:
    if game_over or current_team != _local_team() and not multiplayer.is_server():
        return
    var piece := _get_game_piece_at(from_col, from_row)
    if piece == null or str(piece.get_meta("team")) != current_team:
        return
    var target_piece := _get_game_piece_at(to_col, to_row)
    selected_game_piece = piece
    var kind := str(piece.get_meta("kind"))
    if not _is_valid_classic_move(kind, current_team, from_col, from_row, to_col, to_row, target_piece):
        status_label.text = "Недопустимый ход."
        return
    if not _move_keeps_king_safe(piece, to_col, to_row, target_piece):
        status_label.text = "Нельзя оставлять своего короля под шахом."
        return
    if selected_mode == "Командное голосование" and developer_mode:
        status_label.text = "ТЕСТОВОЕ ГОЛОСОВАНИЕ: Bot-команда проверяет предложенный ход…"
    _apply_classic_move(from_col, from_row, to_col, to_row, true)

func _apply_classic_move(from_col: int, from_row: int, col: int, row: int, broadcast: bool) -> void:
    var piece := _get_game_piece_at(from_col, from_row)
    if piece == null:
        return
    var target_piece := _get_game_piece_at(col, row)
    var moving_team := current_team
    var kind := str(piece.get_meta("kind"))
    var is_castle: bool = kind == "K" and abs(col - from_col) == 2
    var is_en_passant: bool = kind == "P" and abs(col - from_col) == 1 and target_piece == null
    var ep_victim: Node3D = _en_passant_victim(piece, col, row) if is_en_passant else null
    var captured := target_piece != null or ep_victim != null
    if target_piece != null:
        game_piece_nodes.erase(target_piece)
        target_piece.queue_free()
    if ep_victim != null:
        game_piece_nodes.erase(ep_victim)
        ep_victim.queue_free()
    piece.position = Vector3((col - 3.5) * 1.12, 0.64, (row - 3.5) * 1.0 - 0.4)
    piece.set_meta("col", col)
    piece.set_meta("row", row)
    piece.set_meta("has_moved", true)
    if is_castle:
        var rook_from_col := 7 if col > from_col else 0
        var rook_to_col := col - 1 if col > from_col else col + 1
        var rook := _get_game_piece_at(rook_from_col, from_row)
        if rook != null:
            rook.position = Vector3((rook_to_col - 3.5) * 1.12, 0.64, (from_row - 3.5) * 1.0 - 0.4)
            rook.set_meta("col", rook_to_col)
            rook.set_meta("has_moved", true)
    var promoted := kind == "P" and ((moving_team == "white" and row == 0) or (moving_team == "black" and row == 7))
    if promoted:
        piece.set_meta("kind", "Q")
        _rebuild_promoted_piece(piece)
    last_move = {
        "team": moving_team,
        "kind": kind,
        "from_col": from_col,
        "from_row": from_row,
        "to_col": col,
        "to_row": row,
        "double_pawn": kind == "P" and abs(row - from_row) == 2
    }
    if kind == "P" or captured:
        halfmove_clock = 0
    else:
        halfmove_clock += 1
    selected_game_piece = null
    _update_turn_highlights()
    _advance_team_turn()
    _remember_position()
    _evaluate_classic_position(moving_team, promoted, is_castle, is_en_passant)
    if broadcast and online_active and multiplayer.is_server():
        for peer_id in multiplayer.get_peers():
            rpc_id(peer_id, "_rpc_sync_move", from_col, from_row, col, row)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_request_move(from_col: int, from_row: int, to_col: int, to_row: int) -> void:
    if not online_active or not multiplayer.is_server() or game_over:
        return
    var sender_id := multiplayer.get_remote_sender_id()
    if sender_id != 2 or current_team != "black":
        return
    var piece := _get_game_piece_at(from_col, from_row)
    if piece == null or str(piece.get_meta("team")) != "black":
        return
    _process_classic_move(from_col, from_row, to_col, to_row)

@rpc("authority", "call_remote", "reliable")
func _rpc_sync_move(from_col: int, from_row: int, to_col: int, to_row: int) -> void:
    if not online_active or multiplayer.is_server() or game_over:
        return
    _apply_classic_move(from_col, from_row, to_col, to_row, false)

func _local_team() -> String:
    if not online_active:
        return current_team
    if not online_match_id.is_empty():
        return local_player_team
    return "white" if multiplayer.is_server() else "black"

func _update_turn_highlights() -> void:
    for marker in turn_highlight_nodes:
        if is_instance_valid(marker):
            marker.queue_free()
    turn_highlight_nodes.clear()
    if not is_instance_valid(world_root):
        return
    for piece in game_piece_nodes:
        if not is_instance_valid(piece) or str(piece.get_meta("team")) != current_team:
            continue
        var ring := MeshInstance3D.new()
        var ring_mesh := TorusMesh.new()
        ring_mesh.inner_radius = 0.30
        ring_mesh.outer_radius = 0.39
        ring_mesh.rings = 4
        ring_mesh.ring_segments = 32
        ring.mesh = ring_mesh
        ring.position = piece.position + Vector3(0, -0.035, 0)
        var ring_material := StandardMaterial3D.new()
        ring_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        ring_material.albedo_color = Color(0.95, 0.72, 0.28, 0.82)
        ring_material.emission_enabled = true
        ring_material.emission = Color(0.62, 0.32, 0.08)
        ring.material_override = ring_material
        world_root.add_child(ring)
        turn_highlight_nodes.append(ring)
    if is_instance_valid(selected_game_piece):
        var selected_ring := MeshInstance3D.new()
        var selected_mesh := TorusMesh.new()
        selected_mesh.inner_radius = 0.40
        selected_mesh.outer_radius = 0.49
        selected_mesh.rings = 4
        selected_mesh.ring_segments = 36
        selected_ring.mesh = selected_mesh
        selected_ring.position = selected_game_piece.position + Vector3(0, -0.015, 0)
        var selected_material := StandardMaterial3D.new()
        selected_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        selected_material.albedo_color = Color(0.35, 0.95, 0.55, 0.95)
        selected_material.emission_enabled = true
        selected_material.emission = Color(0.10, 0.55, 0.20)
        selected_ring.material_override = selected_material
        world_root.add_child(selected_ring)
        turn_highlight_nodes.append(selected_ring)

func _manual_end_turn() -> void:
    if online_active:
        status_label.text = "В онлайн-партии ход меняется только после допустимого хода."
        return
    _advance_team_turn()

func _get_game_piece_at(col: int, row: int) -> Node3D:
    for piece in game_piece_nodes:
        if is_instance_valid(piece) and int(piece.get_meta("col")) == col and int(piece.get_meta("row")) == row:
            return piece
    return null

func _is_valid_classic_move(kind: String, team: String, from_col: int, from_row: int, to_col: int, to_row: int, target_piece: Node3D = null) -> bool:
    var dc: int = to_col - from_col
    var dr: int = to_row - from_row
    if dc == 0 and dr == 0:
        return false
    if target_piece != null and str(target_piece.get_meta("team")) == team:
        return false
    if target_piece != null and str(target_piece.get_meta("kind")) == "K":
        return false
    if kind == "P":
        var forward: int = -1 if team == "white" else 1
        var start_row: int = 6 if team == "white" else 1
        if dc == 0:
            if target_piece != null:
                return false
            if dr == forward:
                return true
            if dr == forward * 2 and from_row == start_row and not bool(selected_game_piece.get_meta("has_moved", false)):
                return _get_game_piece_at(from_col, from_row + forward) == null
            return false
        if abs(dc) == 1 and dr == forward:
            if target_piece != null:
                return str(target_piece.get_meta("team")) != team
            return _en_passant_victim(selected_game_piece, to_col, to_row) != null
        return false
    if kind == "K" and abs(dc) == 2 and dr == 0:
        if bool(selected_game_piece.get_meta("has_moved", false)) or _is_in_check(team):
            return false
        var rook_col := 7 if dc > 0 else 0
        var rook := _get_game_piece_at(rook_col, from_row)
        if rook == null or str(rook.get_meta("kind")) != "R" or str(rook.get_meta("team")) != team or bool(rook.get_meta("has_moved", false)):
            return false
        var step := 1 if dc > 0 else -1
        var scan := from_col + step
        while scan != rook_col:
            if _get_game_piece_at(scan, from_row) != null:
                return false
            scan += step
        var enemy := "black" if team == "white" else "white"
        if _is_square_attacked(from_col + step, from_row, enemy) or _is_square_attacked(from_col + step * 2, from_row, enemy):
            return false
        return true
    var valid_shape := false
    match kind:
        "N":
            valid_shape = (abs(dc) == 1 and abs(dr) == 2) or (abs(dc) == 2 and abs(dr) == 1)
        "R":
            valid_shape = dc == 0 or dr == 0
        "B":
            valid_shape = abs(dc) == abs(dr)
        "Q":
            valid_shape = dc == 0 or dr == 0 or abs(dc) == abs(dr)
        "K":
            valid_shape = max(abs(dc), abs(dr)) == 1
    if not valid_shape:
        return false
    if kind in ["R", "B", "Q"]:
        return _is_classic_path_clear(from_col, from_row, to_col, to_row)
    return true

func _is_classic_path_clear(from_col: int, from_row: int, to_col: int, to_row: int) -> bool:
    var step_col: int = int(sign(to_col - from_col))
    var step_row: int = int(sign(to_row - from_row))
    var col: int = from_col + step_col
    var row: int = from_row + step_row
    while col != to_col or row != to_row:
        if _get_game_piece_at(col, row) != null:
            return false
        col += step_col
        row += step_row
    return true

func _find_king(team: String) -> Node3D:
    for piece in game_piece_nodes:
        if is_instance_valid(piece) and str(piece.get_meta("team")) == team and str(piece.get_meta("kind")) == "K":
            return piece
    return null

func _is_square_attacked(col: int, row: int, by_team: String) -> bool:
    for piece in game_piece_nodes:
        if not is_instance_valid(piece) or str(piece.get_meta("team")) != by_team:
            continue
        var pc := int(piece.get_meta("col"))
        var pr := int(piece.get_meta("row"))
        var dc := col - pc
        var dr := row - pr
        var kind := str(piece.get_meta("kind"))
        match kind:
            "P":
                var forward := -1 if by_team == "white" else 1
                if abs(dc) == 1 and dr == forward:
                    return true
            "N":
                if (abs(dc) == 1 and abs(dr) == 2) or (abs(dc) == 2 and abs(dr) == 1):
                    return true
            "K":
                if max(abs(dc), abs(dr)) == 1:
                    return true
            "R":
                if (dc == 0 or dr == 0) and (dc != 0 or dr != 0) and _is_classic_path_clear(pc, pr, col, row):
                    return true
            "B":
                if abs(dc) == abs(dr) and dc != 0 and _is_classic_path_clear(pc, pr, col, row):
                    return true
            "Q":
                if (dc == 0 or dr == 0 or abs(dc) == abs(dr)) and (dc != 0 or dr != 0) and _is_classic_path_clear(pc, pr, col, row):
                    return true
    return false

func _is_in_check(team: String) -> bool:
    var king := _find_king(team)
    if king == null:
        return true
    var enemy := "black" if team == "white" else "white"
    return _is_square_attacked(int(king.get_meta("col")), int(king.get_meta("row")), enemy)

func _move_keeps_king_safe(piece: Node3D, to_col: int, to_row: int, captured: Node3D) -> bool:
    var old_col := int(piece.get_meta("col"))
    var old_row := int(piece.get_meta("row"))
    var old_position := piece.position
    var extra_capture: Node3D = null
    if str(piece.get_meta("kind")) == "P" and captured == null and abs(to_col - old_col) == 1:
        extra_capture = _en_passant_victim(piece, to_col, to_row)
    if captured != null:
        game_piece_nodes.erase(captured)
    if extra_capture != null:
        game_piece_nodes.erase(extra_capture)
    piece.set_meta("col", to_col)
    piece.set_meta("row", to_row)
    piece.position = Vector3((to_col - 3.5) * 1.12, 0.64, (to_row - 3.5) * 1.0 - 0.4)
    var safe := not _is_in_check(current_team)
    piece.set_meta("col", old_col)
    piece.set_meta("row", old_row)
    piece.position = old_position
    if captured != null:
        game_piece_nodes.append(captured)
    if extra_capture != null:
        game_piece_nodes.append(extra_capture)
    return safe

func _has_any_legal_move(team: String) -> bool:
    var old_team := current_team
    var old_selected := selected_game_piece
    current_team = team
    for piece in game_piece_nodes:
        if not is_instance_valid(piece) or str(piece.get_meta("team")) != team:
            continue
        selected_game_piece = piece
        var fc := int(piece.get_meta("col"))
        var fr := int(piece.get_meta("row"))
        var kind := str(piece.get_meta("kind"))
        for tc in range(8):
            for tr in range(8):
                var target := _get_game_piece_at(tc, tr)
                if target == piece:
                    continue
                if _is_valid_classic_move(kind, team, fc, fr, tc, tr, target) and _move_keeps_king_safe(piece, tc, tr, target):
                    current_team = old_team
                    selected_game_piece = old_selected
                    return true
    current_team = old_team
    selected_game_piece = old_selected
    return false

func _rebuild_promoted_piece(piece: Node3D) -> void:
    for child in piece.get_children():
        piece.remove_child(child)
        child.queue_free()
    var color := Color(0.88, 0.80, 0.66) if str(piece.get_meta("team")) == "white" else Color(0.12, 0.095, 0.07)
    var mat := _material(color, 0.34, 0.15)
    _add_piece_cylinder(piece, 0.27, 0.12, 0.0, mat)
    _add_piece_cylinder(piece, 0.18, 0.48, 0.18, mat)
    _add_piece_cylinder(piece, 0.24, 0.10, 0.43, mat)
    _add_piece_sphere(piece, 0.22, 0.78, mat)
    _add_piece_cylinder(piece, 0.27, 0.10, 0.98, mat)

func _en_passant_victim(piece: Node3D, to_col: int, to_row: int) -> Node3D:
    if last_move.is_empty() or not bool(last_move.get("double_pawn", false)):
        return null
    var team := str(piece.get_meta("team"))
    var enemy := "black" if team == "white" else "white"
    if str(last_move.get("team", "")) != enemy or str(last_move.get("kind", "")) != "P":
        return null
    var from_row := int(piece.get_meta("row"))
    var from_col := int(piece.get_meta("col"))
    var forward := -1 if team == "white" else 1
    if abs(to_col - from_col) != 1 or to_row - from_row != forward:
        return null
    if int(last_move.get("to_col", -1)) != to_col or int(last_move.get("to_row", -1)) != from_row:
        return null
    var victim := _get_game_piece_at(to_col, from_row)
    if victim == null or str(victim.get_meta("team")) != enemy or str(victim.get_meta("kind")) != "P":
        return null
    return victim

func _remember_position() -> void:
    var cells: Array[String] = []
    for piece in game_piece_nodes:
        if not is_instance_valid(piece):
            continue
        var moved_flag := "1" if bool(piece.get_meta("has_moved", false)) and str(piece.get_meta("kind")) in ["K", "R"] else "0"
        cells.append("%s%s%d%d%s" % [str(piece.get_meta("team")).substr(0, 1), str(piece.get_meta("kind")), int(piece.get_meta("col")), int(piece.get_meta("row")), moved_flag])
    cells.sort()
    var ep_flag := "none"
    if bool(last_move.get("double_pawn", false)) and str(last_move.get("team", "")) != current_team:
        ep_flag = "%d:%d" % [int(last_move.get("to_col", -1)), int(last_move.get("to_row", -1))]
    var key := current_team + "|" + ep_flag + "|" + "|".join(cells)
    position_counts[key] = int(position_counts.get(key, 0)) + 1

func _is_insufficient_material() -> bool:
    var minors: Array[Node3D] = []
    for piece in game_piece_nodes:
        if not is_instance_valid(piece):
            continue
        var kind := str(piece.get_meta("kind"))
        if kind == "P" or kind == "R" or kind == "Q":
            return false
        if kind == "B" or kind == "N":
            minors.append(piece)
    if minors.is_empty():
        return true
    if minors.size() == 1:
        return true
    if minors.size() == 2:
        var first := minors[0]
        var second := minors[1]
        if str(first.get_meta("kind")) == "B" and str(second.get_meta("kind")) == "B":
            var first_square := (int(first.get_meta("col")) + int(first.get_meta("row"))) % 2
            var second_square := (int(second.get_meta("col")) + int(second.get_meta("row"))) % 2
            return first_square == second_square
    return false

func _evaluate_classic_position(moving_team: String, promoted: bool, is_castle: bool, is_en_passant: bool) -> void:
    var in_check := _is_in_check(current_team)
    var has_moves := _has_any_legal_move(current_team)
    if in_check and not has_moves:
        _finish_game("ШАХ И МАТ", "Победа " + ("БЕЛЫХ" if moving_team == "white" else "ЧЁРНЫХ"))
        return
    if not in_check and not has_moves:
        _finish_game("ПАТ", "Ничья — у игрока нет допустимых ходов")
        return
    if halfmove_clock >= 100:
        _finish_game("НИЧЬЯ", "Правило 50 ходов — 100 полуходов без взятия и движения пешки")
        return
    for count in position_counts.values():
        if int(count) >= 3:
            _finish_game("НИЧЬЯ", "Троекратное повторение позиции")
            return
    if _is_insufficient_material():
        _finish_game("НИЧЬЯ", "Недостаточно материала для мата")
        return
    if in_check:
        status_label.text = "ШАХ! Король под угрозой."
    elif promoted:
        status_label.text = "Пешка превратилась в ферзя."
    elif is_castle:
        status_label.text = "Рокировка выполнена."
    elif is_en_passant:
        status_label.text = "Взятие на проходе выполнено."
    else:
        status_label.text = "Ход выполнен."

func _finish_game(title_text: String, detail_text: String) -> void:
    game_over = true
    selected_game_piece = null
    status_label.text = title_text + " — " + detail_text
    _show_game_over(title_text, detail_text)

func _show_game_over(title_text: String, detail_text: String) -> void:
    if game_over_panel == null:
        game_over_panel = Control.new()
        game_over_panel.name = "GameOverOverlay"
        game_over_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
        game_over_panel.mouse_filter = Control.MOUSE_FILTER_STOP
        game_panel.add_child(game_over_panel)
        var shade := ColorRect.new()
        shade.color = Color(0.01, 0.009, 0.008, 0.82)
        shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
        game_over_panel.add_child(shade)
        var frame := _panel(game_over_panel, 0.22, 0.27, 0.78, 0.73)
        game_over_title = _add_label(frame, "", Vector2(18, 24), Vector2(620, 52), 30, PALE_GOLD)
        game_over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        game_over_detail = _add_label(frame, "", Vector2(24, 92), Vector2(590, 58), 16, Color(0.86, 0.81, 0.72))
        game_over_detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        var rematch := _ornate_button(frame, "НОВАЯ ПАРТИЯ", 0.08, 0.68, 0.48, 0.91, 16, "party")
        rematch.pressed.connect(_restart_game)
        var menu := _ornate_button(frame, "В МЕНЮ", 0.52, 0.68, 0.92, 0.91, 16, "card")
        menu.pressed.connect(_return_to_menu)
    game_over_title.text = title_text
    game_over_detail.text = detail_text
    game_over_panel.visible = true

func _restart_game() -> void:
    _start_game(selected_mode)

func _build_online_panel_screen() -> void:
    online_panel = Control.new()
    online_panel.name = "MatchmakingWaitingRoom"
    online_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    online_panel.visible = false
    ui.add_child(online_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.008, 0.007, 0.006, 0.97)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    online_panel.add_child(shade)
    var frame := _panel(online_panel, 0.025, 0.035, 0.975, 0.965)
    _add_label(frame, "ПОИСК СОПЕРНИКОВ", Vector2(20, 10), Vector2(620, 42), 28, PALE_GOLD)
    _add_label(frame, "КЛАССИКА  •  8 НА 8  •  ПОДБОР ПО РЕЙТИНГУ", Vector2(22, 52), Vector2(850, 28), 14, Color(0.82, 0.76, 0.66))
    queue_rating_label = _add_label(frame, "ВАШ РЕЙТИНГ: %d  •  %s" % [competitive_rating, _rating_division()], Vector2(22, 92), Vector2(420, 30), 17, PALE_GOLD)
    queue_timer_label = _add_label(frame, "ВРЕМЯ ПОИСКА  00:00", Vector2(500, 92), Vector2(300, 30), 19, PALE_GOLD)
    var server_url_label := _add_label(frame, "АДРЕС ОНЛАЙН-СЕРВЕРА", Vector2(22, 132), Vector2(260, 20), 11, PALE_GOLD)
    var server_url_input := LineEdit.new()
    server_url_input.text = matchmaking_server_url
    server_url_input.placeholder_text = "https://ваш-сервер.onrender.com"
    server_url_input.position = Vector2(22, 154)
    server_url_input.size = Vector2(540, 34)
    server_url_input.add_theme_font_size_override("font_size", 13)
    server_url_input.text_changed.connect(func(value: String): matchmaking_server_url = value.strip_edges())
    frame.add_child(server_url_input)
    queue_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    var white_panel := _panel(frame, 0.025, 0.235, 0.485, 0.835)
    var black_panel := _panel(frame, 0.515, 0.235, 0.975, 0.835)
    _add_label(white_panel, "БЕЛАЯ КОМАНДА", Vector2(12, 8), Vector2(330, 30), 18, PALE_GOLD)
    _add_label(black_panel, "ЧЁРНАЯ КОМАНДА", Vector2(12, 8), Vector2(330, 30), 18, PALE_GOLD)
    queue_white_roster_label = _add_label(white_panel, "Ожидаем игроков…", Vector2(14, 46), Vector2(350, 430), 15, Color(0.88, 0.85, 0.78))
    queue_black_roster_label = _add_label(black_panel, "Ожидаем игроков…", Vector2(14, 46), Vector2(350, 430), 15, Color(0.88, 0.85, 0.78))
    queue_status_label = _add_label(frame, "Подключаемся к рейтинговой очереди…", Vector2(24, 520), Vector2(650, 42), 15, PALE_GOLD)
    online_status_label = queue_status_label
    queue_cancel_button = _ornate_button(frame, "ОТМЕНИТЬ ПОИСК", 0.73, 0.855, 0.97, 0.975, 14, "nav")
    queue_cancel_button.pressed.connect(_close_online_panel)
    queue_change_piece_button = _ornate_button(frame, "СМЕНИТЬ ФИГУРУ", 0.48, 0.855, 0.72, 0.975, 13, "card")
    queue_change_piece_button.pressed.connect(_change_queued_piece)
    if online_http == null:
        online_http = HTTPRequest.new()
        online_http.timeout = 12.0
        add_child(online_http)
        online_http.request_completed.connect(_on_online_http_completed)
    if online_poll_timer == null:
        online_poll_timer = Timer.new()
        online_poll_timer.wait_time = 1.5
        online_poll_timer.one_shot = false
        add_child(online_poll_timer)
        online_poll_timer.timeout.connect(_poll_matchmaking_ticket)
    if game_state_poll_timer == null:
        game_state_poll_timer = Timer.new()
        game_state_poll_timer.wait_time = 1.0
        game_state_poll_timer.one_shot = false
        add_child(game_state_poll_timer)
        game_state_poll_timer.timeout.connect(_poll_online_game_state)

func _update_queue_roster(players: Array) -> void:
    queue_last_roster = players
    var white := PackedStringArray()
    var black := PackedStringArray()
    for i in range(CLASSIC_TEAM_SIZE):
        white.append("%02d  — свободно" % (i + 1))
        black.append("%02d  — свободно" % (i + 1))
    for player in players:
        if not (player is Dictionary):
            continue
        var slot := int(player.get("slot", -1))
        var team := str(player.get("team", ""))
        var line := "%s   •   Пешка + %s   •   %d" % [str(player.get("name", "Игрок")), str(player.get("secondPiece", player.get("piece", "Конь"))), int(player.get("rating", 1000))]
        if team == "white" and slot >= 0 and slot < CLASSIC_TEAM_SIZE:
            white[slot] = "%02d  %s" % [slot + 1, line]
        elif team == "black" and slot >= 0 and slot < CLASSIC_TEAM_SIZE:
            black[slot] = "%02d  %s" % [slot + 1, line]
    if queue_white_roster_label:
        queue_white_roster_label.text = "\n".join(white)
    if queue_black_roster_label:
        queue_black_roster_label.text = "\n".join(black)

func _open_matchmaking_queue() -> void:
    if online_panel == null:
        _build_online_panel_screen()
    online_panel.visible = true
    if queue_rating_label:
        queue_rating_label.text = "ВАШ РЕЙТИНГ: %d  •  %s" % [competitive_rating, _rating_division()]
    if queue_status_label:
        queue_status_label.text = "Входим в рейтинговую очередь…"
    if queue_timer_label:
        queue_timer_label.text = "ВРЕМЯ ПОИСКА  00:00"
    if developer_mode:
        _start_local_bot_queue()
    else:
        _update_queue_roster([])

func _close_online_panel() -> void:
    if online_poll_timer:
        online_poll_timer.stop()
    if not online_ticket.is_empty() and online_http and online_http.get_http_client_status() == HTTPClient.STATUS_DISCONNECTED:
        _send_matchmaking_request("queue_cancel", "/matchmaking/queue/" + online_ticket + "/cancel", HTTPClient.METHOD_POST)
    online_ticket = ""
    _refund_pending_match_purchase()
    if online_active:
        _stop_online()
    if online_panel:
        online_panel.visible = false
    if menu_panel:
        menu_panel.visible = true

func _connect_to_online_host(address: String, port: int) -> void:
    _stop_online(false)
    online_peer = ENetMultiplayerPeer.new()
    var result := online_peer.create_client(address, port)
    if result != OK:
        online_status_label.text = "Не удалось подключиться. Код: " + str(result)
        return
    multiplayer.multiplayer_peer = online_peer
    online_active = true
    online_role = "client"
    online_game_started = false
    if not multiplayer.connected_to_server.is_connected(_on_online_connected):
        multiplayer.connected_to_server.connect(_on_online_connected)
    if not multiplayer.connection_failed.is_connected(_on_online_connection_failed):
        multiplayer.connection_failed.connect(_on_online_connection_failed)
    if not multiplayer.server_disconnected.is_connected(_on_online_server_disconnected):
        multiplayer.server_disconnected.connect(_on_online_server_disconnected)
    online_status_label.text = "Подключаемся к " + address + ":" + str(port) + "…"

func _make_online_player_id() -> String:
    if persistent_player_id.is_empty():
        persistent_player_id = Crypto.new().generate_random_bytes(16).hex_encode()
        _save_economy()
    return persistent_player_id

func _rating_division() -> String:
    if competitive_rating >= 1800:
        return "АЛМАЗ"
    if competitive_rating >= 1600:
        return "ПЛАТИНА"
    if competitive_rating >= 1400:
        return "ЗОЛОТО"
    if competitive_rating >= 1200:
        return "СЕРЕБРО"
    return "БРОНЗА"

func _show_rating_details() -> void:
    _show_notice("ТВОЙ РЕЙТИНГ: %d\nДИВИЗИОН: %s\nНачальный рейтинг — 1000. Очки будут изменяться после подтверждённых результатов рейтинговых матчей." % [competitive_rating, _rating_division()])

func _send_matchmaking_request(action: String, path: String, method: int, payload: Dictionary = {}) -> void:
    if online_http == null:
        if queue_status_label: queue_status_label.text = "HTTP-клиент не создан."
        if city_status_label: city_status_label.text = "HTTP-клиент не создан."
        return
    var base_url := matchmaking_server_url.strip_edges().trim_suffix("/")
    if base_url.contains("YOUR-MATCHMAKING-SERVER") or (not base_url.begins_with("https://") and not base_url.begins_with("http://")):
        var message := "Укажи адрес опубликованного сервера (https://...)."
        if action.begins_with("city_") or action.begins_with("account_"):
            _set_account_status(message)
            if city_status_label: city_status_label.text = message
        elif queue_status_label: queue_status_label.text = message
        return
    if online_http.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
        return
    online_http_action = action
    var headers := PackedStringArray(["Content-Type: application/json"])
    if not account_token.is_empty(): headers.append("Authorization: Bearer " + account_token)
    if not online_session_token.is_empty(): headers.append("X-Player-Session: " + online_session_token)
    var result := online_http.request(base_url + path, headers, method, JSON.stringify(payload))
    if result != OK:
        if action.begins_with("city_") or action.begins_with("account_"):
            _set_account_status("Не удалось отправить запрос: " + str(result))
            if city_status_label: city_status_label.text = "Не удалось отправить запрос: " + str(result)
        elif queue_status_label: queue_status_label.text = "Не удалось отправить запрос: " + str(result)

func _on_online_http_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
    var payload: Variant = JSON.parse_string(body.get_string_from_utf8())
    var action := online_http_action
    online_http_action = ""
    if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300 or not (payload is Dictionary):
        var error_text := "Ошибка сервера: " + str(response_code)
        if payload is Dictionary and payload.has("error"): error_text += " • " + str(payload["error"])
        if action in ["queue_start", "queue_poll"] and (response_code == 404 or (payload is Dictionary and str(payload.get("error", "")) == "NOT_ENOUGH_ZLOTY")):
            _refund_pending_match_purchase()
        if action.begins_with("city_") or action.begins_with("account_"):
            _set_account_status(error_text)
            if city_status_label: city_status_label.text = error_text
        else:
            if status_label and action.begins_with("game_"): status_label.text = error_text
            elif queue_status_label: queue_status_label.text = error_text
        if action == "game_state" and game_state_poll_timer: game_state_poll_timer.start()
        return
    match action:
        "queue_start":
            online_ticket = str(payload.get("ticket", ""))
            _update_queue_roster(payload.get("players", []))
            if str(payload.get("status", "")) == "matched":
                online_poll_timer.stop()
                _handle_matchmaking_result(payload)
            elif not online_ticket.is_empty():
                if queue_status_label: queue_status_label.text = "Ищем 16 игроков. Не закрывай экран."
                online_poll_timer.start()
        "queue_poll":
            _update_queue_roster(payload.get("players", []))
            if str(payload.get("status", "")) == "matched":
                online_poll_timer.stop()
                _handle_matchmaking_result(payload)
            elif str(payload.get("status", "")) == "waiting_piece_slot":
                if queue_status_label: queue_status_label.text = "МЕСТО ДЛЯ ФИГУРЫ ЗАНЯТО. Подожди или смени фигуру."
            elif str(payload.get("status", "")) == "cancelled":
                online_poll_timer.stop()
                if queue_status_label: queue_status_label.text = "Поиск отменён."
        "queue_cancel":
            if queue_status_label: queue_status_label.text = "Поиск отменён."
        "queue_change_piece":
            _refund_pending_match_purchase()
            online_ticket = ""
            if online_poll_timer: online_poll_timer.stop()
            online_panel.visible = false
            preparation_panel.visible = true
            _refresh_preparation_ui()
        "game_state", "game_move", "game_pass", "game_propose", "game_vote":
            _apply_server_game_state(payload)
            if game_state_poll_timer and online_match_id: game_state_poll_timer.start()
        "game_chat":
            if status_label: status_label.text = "Сообщение отправлено команде."
        "account_register", "account_login":
            account_token = str(payload.get("token", ""))
            var account: Dictionary = payload.get("account", {})
            account_player_id = str(account.get("playerId", ""))
            account_username = str(account.get("username", "Игрок"))
            if account_token.is_empty() or account_player_id.is_empty():
                _set_account_status("Сервер не вернул профиль.")
            else:
                _save_economy()
                _refresh_profile_card()
                var welcome := "Добро пожаловать, " + account_username + "!"
                _set_account_status(welcome + " Загружаем твой прогресс…")
                _show_notice(welcome)
                _close_account_panel()
                _send_matchmaking_request("city_profile", "/city/profile", HTTPClient.METHOD_GET)
        "city_profile", "city_unlock_piece", "city_purchase_piece", "city_purchase_skin":
            _apply_city_profile(payload.get("city", {}))
            if not account_token.is_empty():
                _set_account_status("Аккаунт подключён. Прогресс синхронизирован с сервером.")
                _refresh_profile_card()
            if city_status_label: city_status_label.text = "Прогресс Шахматного города сохранён на сервере."
        _:
            if queue_status_label: queue_status_label.text = "Ответ сервера получен."

func _poll_matchmaking_ticket() -> void:
    if online_ticket.is_empty():
        online_poll_timer.stop()
        return
    var waited_ms := maxi(0, Time.get_ticks_msec() - matchmaking_started_at)
    var total_seconds := int(waited_ms / 1000)
    if queue_timer_label:
        queue_timer_label.text = "ВРЕМЯ ПОИСКА  %02d:%02d" % [int(total_seconds / 60), total_seconds % 60]
    var allowed_gap := mini(500, 100 + int(waited_ms / 15000) * 50)
    if queue_status_label:
        queue_status_label.text = "Поиск игроков • диапазон ±%d • найдено %d из 16" % [allowed_gap, queue_last_roster.size()]
    _send_matchmaking_request("queue_poll", "/matchmaking/queue/" + online_ticket, HTTPClient.METHOD_GET)

func _handle_matchmaking_result(payload: Dictionary) -> void:
    _update_queue_roster(payload.get("players", []))
    pending_match_purchase = false
    pending_match_purchase_cost = 0
    pending_match_purchase_piece = ""
    _save_economy()
    local_player_team = str(payload.get("team", "white"))
    opening_player_id = str(payload.get("startingPlayerId", ""))
    online_match_id = str(payload.get("matchId", ""))
    online_session_token = str(payload.get("playerSessionToken", ""))
    if online_match_id.is_empty() or online_session_token.is_empty():
        if queue_status_label: queue_status_label.text = "Состав собран, но сервер не выдал игровой ключ."
        return
    online_active = true
    online_role = "server"
    if queue_cancel_button:
        queue_cancel_button.text = "СОСТАВ СОБРАН"
        queue_cancel_button.disabled = true
    if queue_status_label:
        queue_status_label.text = "СОСТАВ СОБРАН • ВЫ ЗА " + ("БЕЛЫХ" if local_player_team == "white" else "ЧЁРНЫХ")
    last_game_state_update = -1
    _start_game(selected_mode)
    status_label.text = "Команды собраны. Белые ходят первыми. Сервер синхронизирует партию для всех 16 игроков."
    _send_matchmaking_request("game_state", "/matches/" + online_match_id + "/state", HTTPClient.METHOD_GET)
    if game_state_poll_timer: game_state_poll_timer.start()


func _poll_online_game_state() -> void:
    if online_match_id.is_empty() or online_session_token.is_empty():
        if game_state_poll_timer: game_state_poll_timer.stop()
        return
    _send_matchmaking_request("game_state", "/matches/" + online_match_id + "/state", HTTPClient.METHOD_GET)

func _apply_server_game_state(data: Dictionary) -> void:
    var stamp := int(data.get("updatedAt", 0))
    current_team = str(data.get("activeTeam", "white"))
    online_active_player_id = str(data.get("activePlayerId", ""))
    var viewer: Dictionary = data.get("viewer", {})
    _server_viewer_eliminated = bool(viewer.get("eliminated", false))
    if stamp != last_game_state_update:
        last_game_state_update = stamp
        for marker in turn_highlight_nodes:
            if is_instance_valid(marker): marker.queue_free()
        turn_highlight_nodes.clear()
        for old_piece in game_piece_nodes:
            if is_instance_valid(old_piece): old_piece.queue_free()
        game_piece_nodes.clear()
        for item in data.get("board", []):
            if not (item is Dictionary): continue
            var team := str(item.get("team", "white"))
            var kind := str(item.get("kind", "P"))
            var file := int(item.get("file", 0))
            var rank := int(item.get("row", 0))
            var tint := Color(0.12,0.095,0.07) if team == "black" else Color(0.88,0.80,0.66)
            _create_game_piece((file - 3.5) * 1.12, (rank - 3.5) * 1.0 - 0.4, kind, tint)
            var node := game_piece_nodes[game_piece_nodes.size() - 1]
            node.set_meta("col", file)
            node.set_meta("row", rank)
            node.set_meta("team", team)
            node.set_meta("kind", kind)
            node.set_meta("ownerPlayerId", str(item.get("ownerPlayerId", "")))
            node.set_meta("has_moved", bool(item.get("hasMoved", false)))
            node.set_meta("piece_id", str(item.get("id", "")))
        _update_turn_highlights()
    var active_name := "Игрок"
    for player in data.get("players", []):
        if str(player.get("playerId", "")) == online_active_player_id:
            active_name = str(player.get("name", "Игрок"))
            active_teammate = int(player.get("slot", 0)) + 1
            break
    _refresh_team_turn_label()
    if data.get("status", "active") == "finished":
        game_over = true
        if game_state_poll_timer: game_state_poll_timer.stop()
        _show_match_result_screen(data)

    elif _server_viewer_eliminated:
        status_label.text = "ТЫ ВЫБЫЛ • РЕЖИМ НАБЛЮДАТЕЛЯ. Можно писать в командный чат."
    elif online_active_player_id == online_player_id:
        status_label.text = "ТВОЯ ОЧЕРЕДЬ • выбери одну из своих фигур и сделай ход."
    else:
        status_label.text = "ХОД: " + ("БЕЛЫЕ" if current_team == "white" else "ЧЁРНЫЕ") + " • " + active_name
    var pending_vote: Dictionary = data.get("pendingVote", {})
    var voting_active := selected_mode == "Командное голосование" and not pending_vote.is_empty()
    if vote_approve_button:
        var already_voted := not str(pending_vote.get("viewerVote", "")).is_empty()
        var now_ms := int(Time.get_unix_time_from_system() * 1000.0)
        var discussion_ends_ms := int(pending_vote.get("discussionEndsAt", 0))
        var discussion_over := now_ms >= discussion_ends_ms
        var can_vote := voting_active and discussion_over and not _server_viewer_eliminated and not already_voted
        vote_approve_button.visible = can_vote
        vote_reject_button.visible = can_vote
        if voting_active:
            vote_approve_button.text = "ЗА  •  %d" % int(pending_vote.get("approveCount", 0))
            vote_reject_button.text = "ПРОТИВ  •  %d" % int(pending_vote.get("rejectCount", 0))
        if pass_turn_button: pass_turn_button.visible = not voting_active
        if end_turn_button: end_turn_button.visible = not voting_active
    if voting_active:
        var vote_text := "ГОЛОСОВАНИЕ • ЗА %d / ПРОТИВ %d • нужно %d" % [int(pending_vote.get("approveCount", 0)), int(pending_vote.get("rejectCount", 0)), int(pending_vote.get("requiredVotes", 5))]
        if not str(pending_vote.get("viewerVote", "")).is_empty():
            vote_text += "
ТВОЙ ГОЛОС: " + ("ЗА" if str(pending_vote.get("viewerVote")) == "approve" else "ПРОТИВ")
        var now_ms := int(Time.get_unix_time_from_system() * 1000.0)
        var discussion_ends_ms := int(pending_vote.get("discussionEndsAt", 0))
        var expires_at_ms := int(pending_vote.get("expiresAt", 0))
        var in_discussion := now_ms < discussion_ends_ms
        var phase_end_ms := discussion_ends_ms if in_discussion else expires_at_ms
        var remaining_ms := maxi(0, phase_end_ms - now_ms)
        var seconds_left := int(ceil(float(remaining_ms) / 1000.0))
        if in_discussion:
            vote_text = "ОБСУЖДЕНИЕ ХОДА • %d СЕК." % seconds_left
        else:
            vote_text += "\nГОЛОСОВАНИЕ: %d СЕК." % seconds_left
        status_label.text = vote_text
    var chat_lines := PackedStringArray()
    for message in data.get("chat", []):
        chat_lines.append(str(message.get("playerName", "Игрок")) + ": " + str(message.get("text", "")))
    if team_chat_label:
        team_chat_label.text = "КОМАНДНЫЙ ЧАТ\n" + ("\n".join(chat_lines) if not chat_lines.is_empty() else "Пока нет сообщений.")

func _cast_team_vote(choice: String) -> void:
    if online_match_id.is_empty() or not online_active:
        return
    if _server_viewer_eliminated:
        status_label.text = "Выбывшие игроки не голосуют."
        return
    _send_matchmaking_request("game_vote", "/matches/" + online_match_id + "/vote", HTTPClient.METHOD_POST, {"vote": choice})

func _send_team_chat() -> void:
    if online_match_id.is_empty() or team_chat_input == null: return
    var message := team_chat_input.text.strip_edges()
    if message.is_empty(): return
    _send_matchmaking_request("game_chat", "/matches/" + online_match_id + "/chat", HTTPClient.METHOD_POST, {"message": message})
    team_chat_input.text = ""

func _build_city_screen() -> void:
    city_panel = Control.new()
    city_panel.name = "ChessCityProgression"
    city_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    city_panel.visible = false
    ui.add_child(city_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.008,0.007,0.006,0.97)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    city_panel.add_child(shade)
    var frame := _panel(city_panel,0.035,0.045,0.965,0.955)
    _add_label(frame,"ШАХМАТНЫЙ ГОРОД • ПРОГРЕСС",Vector2(20,12),Vector2(680,40),25,PALE_GOLD)
    var back := _ornate_button(frame,"← НАЗАД",0.82,0.025,0.97,0.12,13,"nav")
    back.pressed.connect(_close_city_screen)
    _add_label(frame,"АККАУНТ",Vector2(22,62),Vector2(200,22),13,PALE_GOLD)
    city_username_input = LineEdit.new()
    city_username_input.placeholder_text = "Логин (3–20 символов)"
    city_username_input.position = Vector2(22,88)
    city_username_input.size = Vector2(230,38)
    frame.add_child(city_username_input)
    city_password_input = LineEdit.new()
    city_password_input.placeholder_text = "Пароль (от 8 символов)"
    city_password_input.secret = true
    city_password_input.position = Vector2(262,88)
    city_password_input.size = Vector2(230,38)
    frame.add_child(city_password_input)
    var login := _ornate_button(frame,"ВОЙТИ",0.405,0.125,0.56,0.205,12,"party")
    login.pressed.connect(_city_login)
    var register := _ornate_button(frame,"РЕГИСТРАЦИЯ",0.57,0.125,0.78,0.205,12,"nav")
    register.pressed.connect(_city_register)
    city_status_label=_add_label(frame,"Войди или зарегистрируй аккаунт, чтобы сохранять XP, фигуры и скины на сервере.",Vector2(22,142),Vector2(750,32),12,PALE_GOLD)
    _add_label(frame,"АДРЕС СЕРВЕРА",Vector2(22,176),Vector2(170,18),10,PALE_GOLD)
    var city_server_url_input := LineEdit.new()
    city_server_url_input.text=matchmaking_server_url
    city_server_url_input.placeholder_text="https://ваш-сервер.onrender.com"
    city_server_url_input.position=Vector2(22,193)
    city_server_url_input.size=Vector2(470,28)
    city_server_url_input.add_theme_font_size_override("font_size",12)
    city_server_url_input.text_changed.connect(func(value: String): matchmaking_server_url=value.strip_edges())
    frame.add_child(city_server_url_input)
    _add_label(frame,"ФИГУРЫ • СНАЧАЛА ОТКРЫТИЕ ЗА XP, ЗАТЕМ ПОСТОЯННАЯ ПОКУПКА ЗА ЗЛОТЫЕ",Vector2(22,228),Vector2(760,24),13,PALE_GOLD)
    var piece_names := ["Конь","Слон","Ладья","Ферзь","Король"]
    for i in range(piece_names.size()):
        var y := 0.37 + float(i)*0.105
        var btn := _ornate_button(frame,piece_names[i].to_upper(),0.025,y,0.47,y+0.09,13,"card")
        btn.pressed.connect(_city_piece_action.bind(piece_names[i]))
        city_piece_buttons.append(btn)
    _add_label(frame,"СКИНЫ • ЗАКРЫТЫ ДО ПОЛУЧЕНИЯ",Vector2(510,228),Vector2(430,24),13,PALE_GOLD)
    var skin_names := ["Мрамор","Обсидиан","Сталь","Аниме"]
    for i in range(skin_names.size()):
        var y := 0.37 + float(i)*0.13
        var btn := _ornate_button(frame,"🔒 " + skin_names[i],0.52,y,0.97,y+0.11,13,"card")
        btn.pressed.connect(_city_skin_action.bind(skin_names[i]))
        city_skin_buttons.append(btn)
    _refresh_city_catalog()

func _open_city_screen() -> void:
    if city_panel == null: _build_city_screen()
    menu_panel.visible = false
    city_panel.visible = true
    if not account_token.is_empty():
        _send_matchmaking_request("city_profile","/city/profile",HTTPClient.METHOD_GET)
    else:
        city_status_label.text="Войди или создай аккаунт. Прогресс будет храниться на сервере, а не только на телефоне."

func _close_city_screen() -> void:
    if city_panel: city_panel.visible=false
    menu_panel.visible=true

func _city_login() -> void:
    _save_economy()
    _send_matchmaking_request("account_login","/accounts/login",HTTPClient.METHOD_POST,{"username":city_username_input.text,"password":city_password_input.text})

func _city_register() -> void:
    _save_economy()
    _send_matchmaking_request("account_register","/accounts/register",HTTPClient.METHOD_POST,{"username":city_username_input.text,"password":city_password_input.text})

func _apply_city_profile(city: Dictionary) -> void:
    city_profile_data=city
    var wallet: Dictionary=city.get("wallet",{})
    balances["zloty"]=int(wallet.get("zloty",balances["zloty"]))
    balances["xp"]=int(wallet.get("xp",balances["xp"]))
    city_unlocked_pieces=city.get("unlockedPieces",["Пешка"])
    city_owned_pieces=city.get("ownedPieces",["Пешка"])
    owned_skins=city.get("ownedSkins",["Дерево"])
    _save_economy()
    _refresh_wallet_labels()
    _refresh_city_catalog()

func _refresh_city_catalog() -> void:
    if city_profile_data.is_empty():
        for button in city_piece_buttons: button.text = "🔒  " + button.text + " • ВОЙДИ В АККАУНТ"
        for button in city_skin_buttons: button.text = "🔒  " + button.text + " • ВОЙДИ В АККАУНТ"
        return
    var piece_catalog: Dictionary=city_profile_data.get("pieceCatalog",{})
    var piece_names := ["Конь","Слон","Ладья","Ферзь","Король"]
    for i in range(min(city_piece_buttons.size(),piece_names.size())):
        var name: String = piece_names[i]
        var item: Dictionary = piece_catalog.get(name,{})
        if bool(item.get("owned",false)):
            city_piece_buttons[i].text="✓  " + name.to_upper() + " • КУПЛЕНО"
        elif bool(item.get("unlocked",false)):
            city_piece_buttons[i].text=name.to_upper()+" • КУПИТЬ ЗА "+str(item.get("zloty",0))+" ЗЛОТЫХ"
        else:
            city_piece_buttons[i].text="🔒  "+name.to_upper()+" • ОТКРЫТЬ "+str(item.get("xp",0))+" XP"
    var skin_catalog: Dictionary=city_profile_data.get("skinCatalog",{})
    var skin_names := ["Мрамор","Обсидиан","Сталь","Аниме"]
    for i in range(min(city_skin_buttons.size(),skin_names.size())):
        var name: String = skin_names[i]
        var item: Dictionary = skin_catalog.get(name,{})
        city_skin_buttons[i].text=("✓  " if bool(item.get("owned",false)) else "🔒  ")+name.to_upper()+(" • ПОЛУЧЕН" if bool(item.get("owned",false)) else " • "+str(item.get("xp",0))+" XP + "+str(item.get("zloty",0))+" ЗЛОТЫХ")

func _city_piece_action(piece: String) -> void:
    if account_token.is_empty():
        if city_status_label: city_status_label.text="Сначала войди в аккаунт."
        return
    var item: Dictionary=city_profile_data.get("pieceCatalog",{}).get(piece,{})
    if not bool(item.get("unlocked",false)):
        _send_matchmaking_request("city_unlock_piece","/city/unlock-piece",HTTPClient.METHOD_POST,{"piece":piece})
    elif not bool(item.get("owned",false)):
        _send_matchmaking_request("city_purchase_piece","/city/purchase-piece",HTTPClient.METHOD_POST,{"piece":piece})

func _city_skin_action(skin: String) -> void:
    if account_token.is_empty():
        if city_status_label: city_status_label.text="Сначала войди в аккаунт."
        return
    var item: Dictionary=city_profile_data.get("skinCatalog",{}).get(skin,{})
    if not bool(item.get("owned",false)):
        _send_matchmaking_request("city_purchase_skin","/city/purchase-skin",HTTPClient.METHOD_POST,{"skin":skin})


func _change_queued_piece() -> void:
    if online_ticket.is_empty():
        online_panel.visible = false
        preparation_panel.visible = true
        _refresh_preparation_ui()
        return
    _send_matchmaking_request("queue_change_piece", "/matchmaking/queue/" + online_ticket + "/cancel", HTTPClient.METHOD_POST)

func _start_quick_match() -> void:
    if not online_ticket.is_empty():
        return
    if queue_cancel_button:
        queue_cancel_button.disabled = false
        queue_cancel_button.text = "ОТМЕНИТЬ ПОИСК"
    online_player_id = account_player_id if not account_token.is_empty() else _make_online_player_id()
    matchmaking_started_at = Time.get_ticks_msec()
    _update_queue_roster([])
    if queue_status_label:
        queue_status_label.text = "Входим в очередь: " + selected_mode + "…"
    if queue_timer_label:
        queue_timer_label.text = "ВРЕМЯ ПОИСКА  00:00"
    _save_economy()
    _send_matchmaking_request("queue_start", "/matchmaking/queue", HTTPClient.METHOD_POST, {
        "playerId": online_player_id,
        "playerName": account_username if not account_token.is_empty() and not account_username.is_empty() else "Игрок-" + online_player_id.substr(0, 5).to_upper(),
        "mode": "team_vote" if selected_mode == "Командное голосование" else "classic",
        "piece": selected_match_piece,
        "rating": competitive_rating
    })

func _on_online_peer_connected(peer_id: int) -> void:
    if peer_id != 2:
        return
    online_status_label.text = "Соперник подключён. Запускаем партию…"
    if not online_game_started:
        online_game_started = true
        selected_mode = "Классика"
        _start_game("Классика")
        status_label.text = "Онлайн-партия началась. Вы играете белыми."

func _on_online_connected() -> void:
    online_status_label.text = "Подключено. Запускаем партию…"
    online_game_started = true
    selected_mode = "Классика"
    _start_game("Классика")
    status_label.text = "Онлайн-партия началась. Вы играете чёрными."

func _on_online_connection_failed() -> void:
    online_status_label.text = "Подключение не удалось. Проверь IP, порт и сеть."
    _stop_online(false)

func _on_online_server_disconnected() -> void:
    online_status_label.text = "Соединение с хостом потеряно."
    _stop_online(false)
    if game_panel:
        status_label.text = "Связь с соперником потеряна."

func _on_online_peer_disconnected(peer_id: int) -> void:
    if peer_id == 2:
        online_status_label.text = "Соперник отключился."
        if game_panel and game_panel.visible:
            status_label.text = "Соперник отключился. Вернись в меню онлайн-комнаты."

func _stop_online(return_peer: bool = true) -> void:
    if online_poll_timer: online_poll_timer.stop()
    if game_state_poll_timer: game_state_poll_timer.stop()
    online_ticket = ""
    online_match_id = ""
    online_session_token = ""
    online_active_player_id = ""
    _server_viewer_eliminated = false
    online_active = false
    online_game_started = false
    online_role = "offline"
    if return_peer:
        multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
    elif online_peer != null:
        online_peer.close()
        multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
    online_peer = null

func _pass_to_teammate() -> void:
    if game_over:
        return
    if online_active and not online_match_id.is_empty():
        if online_active_player_id == online_player_id and not _server_viewer_eliminated:
            _send_matchmaking_request("game_pass", "/matches/" + online_match_id + "/pass", HTTPClient.METHOD_POST)
        else:
            status_label.text = "Передать ход может только активный игрок."
        return
    if online_active:
        status_label.text = "Старая сетевая сессия недоступна."
        return
    if selected_mode != "Классика":
        status_label.text = "Передача хода будет доступна после подключения правил этого режима."
        return
    active_teammate = (active_teammate % 8) + 1
    team_next_player[current_team] = (active_teammate % CLASSIC_TEAM_SIZE) + 1
    selected_game_piece = null
    _refresh_team_turn_label()
    status_label.text = "Очередь передана союзнику. Ход всё ещё за вашей командой."

func _advance_team_turn() -> void:
    if game_over:
        return
    current_team = "black" if current_team == "white" else "white"
    active_teammate = int(team_next_player[current_team])
    team_next_player[current_team] = (active_teammate % CLASSIC_TEAM_SIZE) + 1
    selected_game_piece = null
    _refresh_team_turn_label()
    if developer_mode and current_team != local_user_team and not game_over:
        if bot_turn_timer == null:
            bot_turn_timer = Timer.new()
            bot_turn_timer.one_shot = true
            add_child(bot_turn_timer)
            bot_turn_timer.timeout.connect(_make_bot_move)
        bot_turn_timer.start(1.15)

func _refresh_team_turn_label() -> void:
    if team_turn_label:
        var team_name := "БЕЛЫЕ" if current_team == "white" else "ЧЁРНЫЕ"
        team_turn_label.text = "ХОД: " + team_name + " • ИГРОК " + str(active_teammate) + "/8"
        if online_active:
            team_turn_label.text += "  |  " + ("ВЫ БЕЛЫЕ" if _local_team() == "white" else "ВЫ ЧЁРНЫЕ")

func _select_main_piece(index: int) -> void:
    if index < 0 or index >= PIECES.size(): return
    selected_piece = index
    var name: String = PIECES[index]
    if name == "Пешка":
        _show_notice("Пешка всегда входит в комплект. Выбери дополнительную фигуру.")
        return
    _build_preview_piece(name)
    var unlocked: bool = unlocked_pieces.has(name)
    if unlocked:
        selected_match_piece = name
        _show_notice(name + " выбрана. Нажми «ПАРТИЯ», чтобы продолжить.")
    else:
        _show_notice("🔒 " + name + " закрыта. Пока доступна только пешка.")
    var title := menu_panel.find_child("PieceName", true, false) as Label
    if title: title.text = name.to_upper() + ("  •  ВЫБРАНА" if unlocked else "  •  🔒 ЗАКРЫТА")
    var hint := menu_panel.find_child("PieceLockHint", true, false) as Label
    if hint:
        hint.visible = true
        hint.text = ("СТОИМОСТЬ НА ПАРТИЮ: %d ЗЛОТЫХ" % int(match_piece_costs.get(name, 0))) if unlocked else "🔒 ФИГУРА ЗАКРЫТА"
    _refresh_main_piece_shelf()

func _refresh_main_piece_shelf() -> void:
    for i in range(main_piece_buttons.size()):
        var name: String = PIECES[i]
        var unlocked: bool = unlocked_pieces.has(name)
        var shade := Color(0.82, 0.81, 0.77) if i == selected_piece else Color(0.57, 0.57, 0.54)
        if not unlocked:
            shade = Color(0.37, 0.37, 0.35)
        main_piece_buttons[i].add_theme_color_override("font_color", shade)
        main_piece_buttons[i].tooltip_text = name + (" • доступна" if unlocked else " • закрыта")


func _build_onboarding_screen() -> void:
    onboarding_panel = Control.new()
    onboarding_panel.name = "FirstLaunchTutorial"
    onboarding_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    onboarding_panel.visible = false
    ui.add_child(onboarding_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.008, 0.007, 0.006, 0.62)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    onboarding_panel.add_child(shade)
    var frame := _panel(onboarding_panel, 0.17, 0.13, 0.83, 0.87)
    _add_label(frame, "CHECKMATE • ПЕРВОЕ ОБУЧЕНИЕ", Vector2(28,22), Vector2(700,42), 27, PALE_GOLD)
    onboarding_progress = _add_label(frame, "ШАГ 1 ИЗ 5", Vector2(30,78), Vector2(300,28), 15, Color(0.80,0.73,0.62))
    onboarding_title = _add_label(frame, "ДОБРО ПОЖАЛОВАТЬ", Vector2(30,145), Vector2(820,52), 28, PALE_GOLD)
    onboarding_body = _add_label(frame, "", Vector2(34,220), Vector2(720,210), 21, Color(0.96,0.93,0.86))
    onboarding_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _add_label(frame, "Обучение проходит один раз. Его можно будет повторить в разделе помощи.", Vector2(32,455), Vector2(800,35), 13, Color(0.70,0.65,0.57))
    onboarding_next_button = _ornate_button(frame, "ПРОДОЛЖИТЬ →", 0.63,0.82,0.96,0.96,17,"party")
    onboarding_next_button.pressed.connect(_advance_onboarding)
    _refresh_onboarding_step()

func _open_onboarding() -> void:
    onboarding_step = 0
    menu_panel.visible = true
    if preparation_panel: preparation_panel.visible = false
    if mode_selection_panel: mode_selection_panel.visible = false
    if online_panel: online_panel.visible = false
    onboarding_panel.visible = true
    _refresh_onboarding_step()

func _refresh_onboarding_step() -> void:
    var titles := ["ГЛАВНОЕ МЕНЮ", "КНОПКА ПАРТИЯ", "ВЫБОР ФИГУР", "ПОИСК СОПЕРНИКОВ", "КОМАНДНОЕ ГОЛОСОВАНИЕ"]
    var bodies := [
        "Перед тобой главное меню CHECKMATE. В центре можно вращать камеру вокруг неподвижной фигуры, стрелками переключать коллекцию. Снизу — разделы игры. Серые кнопки с замком пока недоступны.",
        "Нажми большую кнопку ПАРТИЯ. Откроется выбор режима. Нажатие на карточку режима сразу ведёт к подготовке, отдельной кнопки «Продолжить» больше нет.",
        "В первом режиме твой комплект состоит из пешки и одной дополнительной фигуры. Нажми на модель фигуры, чтобы выбрать её. Подсветка показывает активный выбор, цена указана рядом.",
        "После подтверждения откроется поиск. Слева отображаются белые, справа чёрные. В тестовом режиме разработчика места заполняются Bot_1, Bot_2 и другими ботами.",
        "В режиме командного голосования партия ищет такой же состав 8 на 8. Игрок предлагает ход, команда обсуждает его и голосует «За» или «Против». Обе команды имеют отдельный чат."
    ]
    onboarding_progress.text = "ШАГ %d ИЗ %d" % [onboarding_step+1,titles.size()]
    onboarding_title.text = titles[onboarding_step]
    onboarding_body.text = bodies[onboarding_step]
    onboarding_next_button.text = "ЗАВЕРШИТЬ ОБУЧЕНИЕ ✓" if onboarding_step == 4 else "ПРОДОЛЖИТЬ →"

func _advance_onboarding() -> void:
    if onboarding_step < 4:
        onboarding_step += 1
        _refresh_onboarding_step()
        return
    onboarding_completed = true
    if not unlocked_pieces.has("Пешка"): unlocked_pieces.append("Пешка")
    unlocked_pieces = PIECES.duplicate()
    balances["zloty"] = int(balances["zloty"]) + 500
    balances["xp"] = int(balances["xp"]) + 100
    _save_economy()
    _refresh_wallet_labels()
    _refresh_main_piece_shelf()
    onboarding_panel.visible = false
    menu_panel.visible = true
    _show_notice("Обучение завершено! Все типы фигур доступны в классике. Награда: 500 злотых и 100 XP.")


func _build_account_panel() -> void:
    account_panel = Control.new()
    account_panel.name = "AccountDialog"
    account_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    account_panel.visible = false
    ui.add_child(account_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.0, 0.0, 0.0, 0.84)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    account_panel.add_child(shade)
    var frame := _panel(account_panel, 0.24, 0.16, 0.76, 0.84)
    _add_label(frame, "АККАУНТ CHECKMATE", Vector2(28, 18), Vector2(590, 44), 26, PALE_GOLD)
    _add_label(frame, "Играй гостем или войди, чтобы сохранить прогресс в аккаунте.", Vector2(30, 66), Vector2(640, 30), 14, Color(0.84, 0.82, 0.77))
    account_username_input = LineEdit.new()
    account_username_input.position = Vector2(32, 116)
    account_username_input.size = Vector2(540, 46)
    account_username_input.placeholder_text = "Логин (3–20 символов)"
    account_username_input.add_theme_font_size_override("font_size", 18)
    frame.add_child(account_username_input)
    account_password_input = LineEdit.new()
    account_password_input.position = Vector2(32, 176)
    account_password_input.size = Vector2(540, 46)
    account_password_input.placeholder_text = "Пароль (от 8 символов)"
    account_password_input.secret = true
    account_password_input.add_theme_font_size_override("font_size", 18)
    frame.add_child(account_password_input)
    var login := _ornate_button(frame, "ВОЙТИ", 0.045, 0.49, 0.48, 0.61, 15, "party")
    login.pressed.connect(_account_login)
    var register := _ornate_button(frame, "СОЗДАТЬ АККАУНТ", 0.52, 0.49, 0.955, 0.61, 14, "nav")
    register.pressed.connect(_account_register)
    account_status_label = _add_label(frame, "Гостевой режим активен. Прогресс хранится на этом устройстве.", Vector2(32, 278), Vector2(650, 44), 13, PALE_GOLD)
    var guest := _ornate_button(frame, "ПРОДОЛЖИТЬ КАК ГОСТЬ", 0.045, 0.70, 0.955, 0.83, 16, "nav")
    guest.pressed.connect(_account_guest)
    var developer := _ornate_button(frame, "ТЕСТ РАЗРАБОТЧИКА", 0.045, 0.86, 0.48, 0.96, 11, "nav")
    developer.pressed.connect(_open_developer_login_from_account)
    var close := _ornate_button(frame, "ЗАКРЫТЬ", 0.52, 0.86, 0.955, 0.96, 11, "nav")
    close.pressed.connect(_close_account_panel)
    _refresh_profile_card()

func _open_account_panel() -> void:
    if account_panel == null:
        _build_account_panel()
    account_panel.visible = true
    if account_token.is_empty():
        _set_account_status("Гостевой режим: сохранение только на этом устройстве. После удаления игры данные могут пропасть.")
    else:
        _set_account_status("Аккаунт подключён: " + (account_username if not account_username.is_empty() else "Игрок") + ".")

func _close_account_panel() -> void:
    if account_panel:
        account_panel.visible = false

func _account_guest() -> void:
    if account_token.is_empty():
        _set_account_status("Ты играешь гостем. Прогресс хранится локально и не восстановится после удаления данных игры.")
    _close_account_panel()

func _account_login() -> void:
    var username := account_username_input.text.strip_edges()
    var password := account_password_input.text
    if username.is_empty() or password.is_empty():
        _set_account_status("Введи логин и пароль.")
        return
    _set_account_status("Подключаем аккаунт…")
    _send_matchmaking_request("account_login", "/accounts/login", HTTPClient.METHOD_POST, {"username": username, "password": password})

func _account_register() -> void:
    var username := account_username_input.text.strip_edges()
    var password := account_password_input.text
    if username.length() < 3 or username.length() > 20:
        _set_account_status("Логин должен содержать от 3 до 20 символов.")
        return
    if password.length() < 8:
        _set_account_status("Пароль должен содержать минимум 8 символов.")
        return
    _set_account_status("Создаём аккаунт…")
    _send_matchmaking_request("account_register", "/accounts/register", HTTPClient.METHOD_POST, {"username": username, "password": password})

func _set_account_status(message: String) -> void:
    if account_status_label:
        account_status_label.text = message

func _refresh_profile_card() -> void:
    if profile_name_label:
        profile_name_label.text = account_username if not account_token.is_empty() and not account_username.is_empty() else ("АККАУНТ" if not account_token.is_empty() else "ГОСТЬ")
    if profile_state_label:
        profile_state_label.text = "ПРОГРЕСС СОХРАНЯЕТСЯ" if not account_token.is_empty() else "НАЖМИ НА АВАТАР • ВОЙТИ"

func _build_developer_login() -> void:
    developer_login_panel = Control.new()
    developer_login_panel.name = "DeveloperTestLogin"
    developer_login_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    developer_login_panel.visible = false
    ui.add_child(developer_login_panel)
    var shade := ColorRect.new()
    shade.color = Color(0.0, 0.0, 0.0, 0.82)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    developer_login_panel.add_child(shade)
    var frame := _panel(developer_login_panel, 0.30, 0.22, 0.70, 0.78)
    _add_label(frame, "ТЕСТОВЫЙ ДОСТУП РАЗРАБОТЧИКА", Vector2(18, 18), Vector2(520, 42), 22, PALE_GOLD)
    _add_label(frame, "ЛОГИН", Vector2(22, 90), Vector2(300, 24), 15, PALE_GOLD)
    developer_user_input = LineEdit.new()
    developer_user_input.position = Vector2(22, 118)
    developer_user_input.size = Vector2(470, 46)
    developer_user_input.placeholder_text = "Логин"
    developer_user_input.add_theme_font_size_override("font_size", 20)
    frame.add_child(developer_user_input)
    _add_label(frame, "ПАРОЛЬ", Vector2(22, 184), Vector2(300, 24), 15, PALE_GOLD)
    developer_pass_input = LineEdit.new()
    developer_pass_input.position = Vector2(22, 212)
    developer_pass_input.size = Vector2(470, 46)
    developer_pass_input.placeholder_text = "Пароль"
    developer_pass_input.secret = true
    developer_pass_input.add_theme_font_size_override("font_size", 20)
    frame.add_child(developer_pass_input)
    var login := _ornate_button(frame, "ВОЙТИ В РЕЖИМ ТЕСТИРОВАНИЯ", 0.04, 0.66, 0.96, 0.82, 15, "party")
    login.pressed.connect(_submit_developer_login)
    var cancel := _ornate_button(frame, "ОТМЕНА", 0.32, 0.85, 0.68, 0.96, 13, "nav")
    cancel.pressed.connect(func(): developer_login_panel.visible = false)

func _open_developer_login_from_account() -> void:
    if account_panel:
        account_panel.visible = false
    _open_developer_login()

func _open_developer_login() -> void:
    if developer_login_panel:
        developer_login_panel.visible = true
        developer_user_input.text = ""
        developer_pass_input.text = ""

func _submit_developer_login() -> void:
    var login_name := developer_user_input.text.strip_edges()
    var login_password := developer_pass_input.text
    if login_name == "TheHezzer" and login_password == "admin":
        developer_mode = true
        developer_login_panel.visible = false
        if developer_test_menu:
            developer_test_menu.visible = true
        if menu_panel:
            menu_panel.visible = false
        _show_notice("Вы вошли в тестовый режим, TheHezzer!")
    else:
        developer_pass_input.text = ""
        _show_notice("Неверный тестовый логин или пароль.")

func _build_developer_test_menu() -> void:
    developer_test_menu = Control.new()
    developer_test_menu.name = "DeveloperOnlyTestMenu"
    developer_test_menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    developer_test_menu.visible = false
    ui.add_child(developer_test_menu)
    var shade := ColorRect.new()
    shade.color = Color(0.012, 0.010, 0.009, 0.97)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    developer_test_menu.add_child(shade)
    var frame := _panel(developer_test_menu, 0.18, 0.12, 0.82, 0.88)
    _add_label(frame, "ПАНЕЛЬ ТЕСТИРОВАНИЯ", Vector2(24, 18), Vector2(620, 48), 28, PALE_GOLD)
    _add_label(frame, "ДОСТУП РАЗРАБОТЧИКА • TheHezzer", Vector2(26, 68), Vector2(620, 28), 15, Color(0.82, 0.76, 0.66))
    developer_test_status = _add_label(frame, "Тестовый режим активен. Эти инструменты видны только тестовому аккаунту.", Vector2(26, 112), Vector2(650, 44), 14, PALE_GOLD)
    var classic := _ornate_button(frame, "ТЕСТ КЛАССИКИ С БОТАМИ", 0.06, 0.29, 0.94, 0.43, 17, "party")
    classic.pressed.connect(_developer_test_classic)
    var voting := _ornate_button(frame, "ТЕСТ КОМАНДНОГО ГОЛОСОВАНИЯ", 0.06, 0.48, 0.94, 0.62, 16, "card")
    voting.pressed.connect(_developer_test_voting)
    var local_game := _ornate_button(frame, "ЗАПУСТИТЬ ЛОКАЛЬНУЮ ПАРТИЮ", 0.06, 0.67, 0.94, 0.81, 16, "card")
    local_game.pressed.connect(_developer_test_local_game)
    var exit := _ornate_button(frame, "ВЫЙТИ ИЗ ТЕСТОВОГО РЕЖИМА", 0.20, 0.85, 0.80, 0.96, 14, "nav")
    exit.pressed.connect(_developer_test_logout)

func _developer_test_classic() -> void:
    if not developer_mode:
        return
    selected_mode = "Классика"
    developer_test_menu.visible = false
    _open_matchmaking_queue()

func _developer_test_voting() -> void:
    if not developer_mode:
        return
    selected_mode = "Командное голосование"
    developer_test_menu.visible = false
    _open_matchmaking_queue()

func _developer_test_local_game() -> void:
    if not developer_mode:
        return
    selected_mode = "Классика"
    developer_test_menu.visible = false
    _start_game(selected_mode)
    status_label.text = "ТЕСТОВЫЙ РЕЖИМ • ЛОКАЛЬНАЯ ПАРТИЯ"

func _developer_test_logout() -> void:
    developer_mode = false
    if developer_test_menu:
        developer_test_menu.visible = false
    if menu_panel:
        menu_panel.visible = true
    _show_notice("Вы вышли из тестового режима.")

func _start_local_bot_queue() -> void:
    local_bot_roster.clear()
    var white := PackedStringArray()
    var black := PackedStringArray()
    local_user_team = "white"
    local_user_slot = randi_range(1, CLASSIC_TEAM_SIZE)
    for slot in range(CLASSIC_TEAM_SIZE):
        var white_name := "TheHezzer" if slot + 1 == local_user_slot else "Bot_%d" % (slot + 1 if slot + 1 < local_user_slot else slot)
        var black_name := "Bot_%d" % (slot + 8)
        white.append("%02d  %s  •  Пешка + %s" % [slot + 1, white_name, selected_match_piece])
        black.append("%02d  %s  •  Пешка + %s" % [slot + 1, black_name, selected_match_piece])
        local_bot_roster.append({"name": white_name, "team": "white", "slot": slot, "bot": white_name != "TheHezzer"})
        local_bot_roster.append({"name": black_name, "team": "black", "slot": slot, "bot": true})
    if queue_white_roster_label:
        queue_white_roster_label.text = "\n".join(white)
    if queue_black_roster_label:
        queue_black_roster_label.text = "\n".join(black)
    if queue_status_label:
        queue_status_label.text = "ТЕСТОВЫЙ СОСТАВ 16/16 • Bot-команды собраны. Запуск через 2 секунды…"
    if bot_match_timer == null:
        bot_match_timer = Timer.new()
        bot_match_timer.one_shot = true
        add_child(bot_match_timer)
        bot_match_timer.timeout.connect(_launch_local_bot_match)
    bot_match_timer.start(2.0)

func _launch_local_bot_match() -> void:
    if not developer_mode or not online_panel or not online_panel.visible:
        return
    online_panel.visible = false
    online_active = false
    online_match_id = ""
    online_session_token = ""
    _start_game(selected_mode)
    local_user_team = "white"
    status_label.text = "ТЕСТ С БОТАМИ • Вы за белых. Чёрные и союзники — Bot_1…Bot_16."

func _make_bot_move() -> void:
    if not developer_mode or game_over or current_team == local_user_team or not game_panel.visible:
        return
    var candidates: Array[Dictionary] = []
    for piece in game_piece_nodes:
        if not is_instance_valid(piece) or str(piece.get_meta("team")) != current_team:
            continue
        var fc := int(piece.get_meta("col"))
        var fr := int(piece.get_meta("row"))
        var kind := str(piece.get_meta("kind"))
        for tc in range(8):
            for tr in range(8):
                if fc == tc and fr == tr:
                    continue
                var target := _get_game_piece_at(tc, tr)
                if target != null and str(target.get_meta("team")) == current_team:
                    continue
                if _is_valid_classic_move(kind, current_team, fc, fr, tc, tr, target) and _move_keeps_king_safe(piece, tc, tr, target):
                    candidates.append({"fc":fc,"fr":fr,"tc":tc,"tr":tr})
    if candidates.is_empty():
        _evaluate_classic_position(current_team, false, false, false)
        return
    var move: Dictionary = candidates[randi_range(0, candidates.size()-1)]
    status_label.text = "Ходит " + ("Bot_9" if current_team == "black" else "Bot_1") + "…"
    _apply_classic_move(int(move.fc), int(move.fr), int(move.tc), int(move.tr), false)


func _build_startup_sequence() -> void:
    startup_panel = Control.new()
    startup_panel.name = "CampaignIntroAndLoading"
    startup_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(startup_panel)
    var background := TextureRect.new()
    background.texture = load("res://assets/castle_hall.png")
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    startup_panel.add_child(background)
    var shade := ColorRect.new()
    shade.color = Color(0.005,0.008,0.012,0.58)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    startup_panel.add_child(shade)
    startup_title = _add_label(startup_panel, "CHECKMATE • ПРЕВЬЮ КАМПАНИИ", Vector2.ZERO, Vector2(1000,70), 34, PALE_GOLD)
    startup_title.anchor_left = 0.12
    startup_title.anchor_right = 0.88
    startup_title.anchor_top = 0.30
    startup_title.anchor_bottom = 0.40
    startup_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    startup_detail = _add_label(startup_panel, "Здесь будет вступительная сцена. Ждём твои 3D-модели.", Vector2.ZERO, Vector2(1000,60), 20, Color(0.95,0.92,0.85))
    startup_detail.anchor_left = 0.14
    startup_detail.anchor_right = 0.86
    startup_detail.anchor_top = 0.43
    startup_detail.anchor_bottom = 0.54
    startup_detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    startup_progress = ProgressBar.new()
    startup_progress.anchor_left = 0.25
    startup_progress.anchor_right = 0.75
    startup_progress.anchor_top = 0.72
    startup_progress.anchor_bottom = 0.76
    startup_progress.max_value = 100
    startup_panel.add_child(startup_progress)
    var continue_button := _ornate_button(startup_panel, "ПРОДОЛЖИТЬ →", 0.38, 0.82, 0.62, 0.92, 18, "party")
    continue_button.visible = false
    continue_button.pressed.connect(_finish_startup_sequence)
    startup_timer = Timer.new()
    startup_timer.wait_time = 0.08
    add_child(startup_timer)
    startup_timer.timeout.connect(_advance_startup_progress)
    menu_panel.visible = false
    if onboarding_panel:
        onboarding_panel.visible = false
    startup_timer.start()

func _advance_startup_progress() -> void:
    startup_progress.value += 2.0
    if startup_progress.value >= 100.0:
        startup_timer.stop()
        startup_title.text = "ВСТУПИТЕЛЬНЫЙ РОЛИК"
        startup_detail.text = "Видеосцена будет добавлена после загрузки твоих материалов."
        startup_progress.visible = false
        for child in startup_panel.get_children():
            if child is Button:
                child.visible = true

func _finish_startup_sequence() -> void:
    if startup_timer:
        startup_timer.stop()
    startup_panel.visible = false
    menu_panel.visible = true
    if not onboarding_completed and onboarding_panel:
        _open_onboarding()
